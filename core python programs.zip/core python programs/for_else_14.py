# Author=Rohan
# Date=29-12-23
# Accept marks of 5 sub from user and print their average 
# if negative marks enterd then do not process


total_marks=0
for x in range(5):
    marks=int(input("Enter marks: "))
    if marks<0:
        print("Invalid marks enterd.can't process the average.")
        break
    total_marks+=marks

else:
    avg=total_marks/5
    print("Average is: ",avg)



                                   #or
    
    # for x in range(10):
    #     if x==5:
    #         break
    #     print(x,end=",")
    
    # else:
    #     print("Loop is completed.")

    # print("Thank you!")   