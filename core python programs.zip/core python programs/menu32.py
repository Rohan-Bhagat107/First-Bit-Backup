# Author=Rohan
# Date=26-12-23

print('''welcome to our application
      1. Add 2 numbers
      2. max of 2 no.
      3. Find if no.is even/odd
      4. Print square of a no.
      5. Exit''')

choice=int(input("Please enter your choice from given menu (1-5): "))
if choice==1:
    first_no=int(input("enter first no.: "))
    second_no=int(input("Enter second no.: "))
    addition=first_no+second_no
    print("Addition of your no. is: ",(addition))
elif choice==2:
    first_no=int(input("enter first no.: "))
    second_no=int(input("Enter second no.: "))
    if (first_no>second_no):
        print("First no.is maximum. ",first_no)
    else:
        print("second no.is maximum.",second_no)
elif choice==3:
    no=int(input("Please enter your no. : "))
    if no%2==0:
        print("No. is even")
    else:
        print("No. is odd")
elif choice==4:
    no=int(input("Enter your no. "))
    print("Square of your no. is: ",(no*no))
elif choice==5:
    print("Exit")
else:
    print("Invalid choice")
