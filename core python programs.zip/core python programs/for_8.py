# Author=Rohan
# Date=28-12-23

# Task-
# Print the table of any number that user enters

no=int(input("Enter any table number that you have to print:  "))

# for x in range(1,11,1):
#     print(no*x)



for a in range(1,11,1):
    print(no,"x",a,"=",no*a)