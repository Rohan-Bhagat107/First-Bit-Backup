x=100           #Global variables(accesed anywhere in the code)
def global_var(a,b):           #local varibles(accesed only inside the fun/loop)
    print(a+b)
    print(x)

global_var(10,20)
