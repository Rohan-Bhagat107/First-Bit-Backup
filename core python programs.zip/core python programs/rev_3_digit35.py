# Author= Rohan
# Date=26-12-23
# Reverse 3 digit no by taking user input for number

no=int(input("Please enter 3 digit no."))     #suppose no=235

rev=0
rev=rev*10+no%10    #it gives last digit    #5
no=no//10           #it saves first two digits  #23

rev=rev*10+no%10       #it gives last digit of last saved two digits   #3
no=no//10               #it saves last digit     #2

rev=rev*10+no%10
no=no//10               #it saves 0

print(rev)