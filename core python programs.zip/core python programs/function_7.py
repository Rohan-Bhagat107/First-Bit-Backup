#write a function max3(a,b,c) which finds max of 3 numbers and return it


def max3(a,b,c):
    if a>b and a>c:
        return a
    elif b>a and b>c:
        return b
    else:
        return c

result=max3(8,9,6)
print("Max of three numbers is: ",result)