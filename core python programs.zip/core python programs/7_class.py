# class Student:
#     def set_data(self):
#         self.roll=1
#         self.name="Tushar"
#         self.marks=97
#     def display(self):
#         print("Roll No: ",self.roll)
#         print("Name: ",self.name)
#         print("Marks: ",self.marks)

# s=Student()         #create object
# s.set_data()       #set values for the attributes
# s.display()         #display attribute values
 



