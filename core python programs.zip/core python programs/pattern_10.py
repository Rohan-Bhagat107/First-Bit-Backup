for i in range(5,0,-1):
    for j in range(1,6):
        print(i,end=" ")
    print( )