#WAP to find sum of factorials

n=int(input("Enter a number: "))
sum=0
while n>=1:
    fact=1
    m=n
    while m>1:
        fact*=m
        m=m-1
    sum+=fact
    n-=1
print("Sum of factorials is : ",sum)