#menu driven using while loop


choice=1
while choice!=3 :
    print('''welcome to our application
      press-
      1. Add 2 numbers
      2. max of 2 no.
      3. Exit''')
    
    choice=int(input("Please enter your choice from given menu (1-5): "))
    if choice==1:
     first_no=int(input("enter first no.: "))
     second_no=int(input("Enter second no.: "))
     addition=first_no+second_no
     print("Addition of your no. is: ",(addition))
    elif choice==2:
     first_no=int(input("enter first no.: "))
     second_no=int(input("Enter second no.: "))
     if (first_no>second_no):
        print("First no.is maximum. ",first_no)
     else:
        print("second no.is maximum.",second_no)

    elif choice==3:
       print("Thank You!")
else:
   print("Invalid choice")



   #HW 
   #Implement menu driven program for 1 to 5 choice and also for operators