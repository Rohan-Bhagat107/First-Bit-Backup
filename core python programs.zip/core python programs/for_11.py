# Author=Rohan
# DAte=28-12-23
# task-
# WAP to accept n numbers from user and print their sum


n=int(input("Enter how many numbers you have to enter: "))
sum=0
for x in range(n):
    sum+=int(input("Enter a no."))
    
    
print("sum is : ",sum)    
             