#Author=Rohan
#date=3-01-24
#H W
    #accept a number from user
    # add it to sum
    #confirm if user wants to continue
    #if user enters"y" ,then ask for another number and keep on doing it till user says"n"
    #in the end print the sum

#no=int(input("Enter a number."))            #5

sum=0
#sum=sum+no

reply="Y" #input("Do you want to continue (Y/N)?: ")
    
while reply=="Y":
    no=int(input("Enter a number."))
    sum=sum+no
    reply=input("Do you want to continue (Y/N)?: ")
    
print("Sum of your numbers is: ",sum) 


