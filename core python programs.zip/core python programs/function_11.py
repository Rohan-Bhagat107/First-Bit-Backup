#write a function print_pattern(n)
#print pattern as follow
# A
# A B
# A B C
# A B C D
# A B C D E

def print_pattern(n):
    for i in range(1,n+1):
        ch=65
        for j in range(1,i+1):
            print(chr(ch),end=" ")
            ch+=1
        print()
print_pattern(5)