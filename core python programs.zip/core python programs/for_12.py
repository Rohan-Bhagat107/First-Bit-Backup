# Author=Rohan
# Date=28-12-23

# task-
# Accept numbers from user that he/she wants to enter
# and print how many of them are positive ,negative and zeros


count_positive=0
count_negative=0
count_zero=0
no=int(input("Enter how many numbers you have to enter?: "))
for a in range(no):
    
    no=int(input("Enter number: " ))
    if no>0:

        count_positive+=1

    elif no<0:
     
     count_negative+=1

    else:
     
     count_zero+=1


print("Total positive numbers are: ",count_positive)
print("Total number of negative numbers are: ",count_negative)
print("Total Number of zeros is: ",count_zero)



    