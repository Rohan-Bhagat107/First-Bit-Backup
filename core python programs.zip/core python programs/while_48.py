#WAP to find sum of factorials using for loop

n=int(input("Enter a number: "))
sum=0
for i in range(n,0,-1):
    fact=1
    m=i
    for j in range(m,1,-1):
       fact*=j
    
    sum+=fact
print("sum of factorials is: ",sum)



