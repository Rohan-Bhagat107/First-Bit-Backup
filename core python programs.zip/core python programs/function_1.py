# Author=Rohan
# Date=10-01-24

              #function starts today


# Function are typically used in 4 ways as follows-
# 1) Function with no parameter and no return Value
# 2) Function with parameter and no return Value
# 3) Function with no parameter and return Value
# 4)Function with  parameter and  return Value



#1) Function with no parameter and no return Value
#function declaration
def display():                       #function name(display)
    print("Hello world !")

#function calling
display()

# 2) Function with parameter and no return Value
def display2(msg):                         #parameter=msg
    print(msg)
display2("Learning functions....")                   

# 3) Function with no parameter and return Value
def get_message():
    return "Functions are fun!"          #return 
res=get_message()
print(res)

# 4)Function with  parameter and  return Value
def square(no):
    return(no**2)           #return =no*no
sq=square(7)               #parameter =7
print(sq)