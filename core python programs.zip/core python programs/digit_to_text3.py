# Author=Rohan
# Date=26-12-23


no=int(input("please enter single digit no. : "))
if no==0:
    print("Zero")
else:
    if no==1:
        print("One")
    else:
     if no==2:
        print("Two")
     else:
        if no==3:
         print("Three")
        else:
         if no==4:
          print("Four")
         else:
           if no==5:
            print("five")
           else:
                if no==6:
                  print("Six")
                else:
                  if no==7:
                   print("seven")
                  else:
                   if no==8:
                     print("Eight")
                   else:
                     if no==9:
                        print("Nine")

    