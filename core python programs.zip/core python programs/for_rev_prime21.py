#print all prime numbers from 1 to 50 in reverse order.

for no in range(50,1,-1):
    for x in range(2,no,1):
        if no%x==0:
            break
    else:
        print(no,end=" ")
