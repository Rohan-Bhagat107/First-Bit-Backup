# Author=Rohan
# Date=21-12-23

print(10>7)#true
print(13==19)#false
print(12==12)#True
print(39!=93)#true
print(89<98)#True
print(56<=28)#false
print(69>=26)#true
