# Author=Rohan
# Date=29-12-23
# task-

#Accept 5 numbers (3 digit) from user .& print how many of them are palindrome
# 

count=0
for x in range(5):
  
   no=int(input("Enter a number: "))
   a=no%10
   b=no//10
   c=b%10
   d=b//10
   rev_no=a*100+c*10+d*1
   rev_no2=rev_no
   if no==rev_no2:
     count+=1
print("Total number of palindrome is: ",count)  
        