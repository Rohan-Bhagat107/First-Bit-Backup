class laptop():
    def __init__(self,x,y,z):
        self.brand=x
        self.colour=y
        self.size=z
    def display(self):
        print("Brand: ",self.brand,", Colour: ",self.colour,", size: ",self.size)
    
a=laptop("Dell","Black",14)
a.display()

b=laptop("HP","Silver", 15.6)
b.display()

c=laptop("ASUS"," Silver", 16)
c.display()