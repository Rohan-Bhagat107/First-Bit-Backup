#print first N numbers from user 
              
              #  but accept N from user
#      find if no. is prime
# if it is prime print it and increment count
# if count matches with user input n then stop
    #  if count==n 
    #  break

count=0
n=int(input("Enter number upto which you have to print: "))
for no in range(2,500,1):
    #find if no. is prime
    for i in range(2,no):
        if no%i==0:
           break
    else:
        #if it is prime print it and increment count
        print(no,end=" ")
        count+=1
    if count==n:
        break


    