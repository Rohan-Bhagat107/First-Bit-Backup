# Author=Rohan
# Date=25-12-23

#Task-
#calculate discount that a student or non-student person can have on its purchase
# Ask user that he/she is a student
#     if yes then ask him for billing amount
#          if bill>2000
#            then discount should be 40% otherwise 25%
#     if No then ask him for billing amount
#         if bill >4000
#             then discount should be  15% otherwise 10%      


# choice=input("Are you a student (Y/N)")

# amount=int(input("Enter the total amount: "))
# if choice=="Y" or choice=="y":
#     if(amount>=2000):
#         discount=40
#     else:
#         discount=25
# else:
#     if choice =="N" or choice=="n":
#      if(amount>=4000):
#         discount=15
#      else:
#         discount=10
#     else:
#      print("Invalid Choice")
#      print("To get discount on your purchase select appropriate choice otherwise discount will be 0%")
#      discount=0

# #print(discount)
# final_amount=int(amount-amount*discount/100)

# print   ("Your total amount is: ",final_amount)         



choice=input("Are you student (Y/N):")
discount=0
amount=0
if choice=="Y" or choice=="y":
    amount=int(input("Please enter your billing amount here: "))
    if (amount>=2000):
        discount=40
    else:
        discount=25
else:
         if choice=="N" or choice=="n":
          amount = int(input("Please enter your billing amount here: "))
          if(amount>=4000):
           discount=15
          else:
           discount=10
                
         #if(choice!="N") or (choice!="n"):
         else:  
          print("Invalid choice")
    #
            #yprint("To get discount on your purchase select appropriate choice otherwise discount will be 0 %")
          
              
final_amount = amount-(amount*discount/100)
print("Your total amount is: ",final_amount)                 
