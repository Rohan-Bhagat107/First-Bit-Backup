#print all prime numbers from 300 to 400 using while loop
n=300
while n<=400:
    for i in range(2,n//2,1):
       if n%i==0:
        break
       
    else:
     print(n)
    n=n+1