#a function is-prime(no)
#it will accept a number as parameter 
#it will return true if it is prime else return false

def is_prime(no):
    for i in range(2,no):
        if no%i==0:
         return False
    else:
        return True
        
res=is_prime(15)
print(res)
if res==True:
   print("It is a prime number.")
else:
   print("It not a prime number.")