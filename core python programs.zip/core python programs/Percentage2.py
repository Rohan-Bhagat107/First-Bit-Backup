# Author =Rohan
# date=20-12-23

# Task)- 
# Accept the prices of three products from user (book,pen,notebook)
# apply discount as follows
# book=20%
# pen=10%
# notebook=5%

book_price=int(input("Enter price of book: "))
book_discount=20 #it is in %
pen_price=int(input("Enter price of pen: "))
pen_discount=10 #it is in %
notebook_price=int(input("Enter price of notebook: "))
notebook_discount=5 #it is in %
book_amount=book_price*( book_discount/100)
pen_amount=pen_price*(pen_discount/100)
notebook_amount=notebook_price*(notebook_discount/100)
total_price=int(book_amount+pen_amount+notebook_amount)
print("Total amount that a customer has to pay after discount is: " ,(total_price),"/-")

