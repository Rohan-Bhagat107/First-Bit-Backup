for i in range (1,7):
    for j in range(1,6):
        if j%2==0:
         print("*",end=" ")
        else:
         print(j,end=" ")
    print()
        