# Author=Rohan
# Date=23-12-23

# print the maximum no.out of three

first_no=int(input("Please enter 1st no.: "))
second_no=int(input("Please enter 2nd no.: "))
third_no=int(input("Please enter 3rd no.: "))

if first_no > second_no and first_no>third_no:
    print("Max of",first_no,second_no,third_no,"is: ",first_no)
else:
    if second_no > first_no and second_no>third_no:
        print("Max of",first_no,second_no,third_no,"is: ",second_no)
    else:
        if third_no >first_no and third_no>second_no: 
            print("Max of",first_no,second_no,third_no,"is: ",third_no)
        else:
            if first_no==second_no and first_no== third_no:
                print("All no. are same")
            else:
                if first_no==second_no:
                    print("Max of",first_no,second_no,third_no ,"is: ",second_no,"as first & second both are same")
                else:
                    if first_no== third_no:
                        print("Max of",first_no,second_no,third_no,"is: ",first_no,"as first & third both ar same") 
                    else:
                        print("Max of",first_no,second_no,third_no,"is: ",second_no,"as second & third both ar same")
                    
           


