class Employee():
    def set_data(self):
        self.name=input("Enter name of an employee: ")
        self.department=input("Enter employee department: ")
        self.designation=input("Enter designation of an employee:")

    def display(self):
        print("Employee Name: ",self.name)
        print("Employee department: ",self.department)
        print("Employee designation: ",self.designation)
    
e1=Employee()
e1.set_data()
e1.display()
