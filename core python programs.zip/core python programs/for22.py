# Author=Rohan
# DAte=27-12-23

#  print numbers from 10 to 50

for x in range(10,51,1):
    print(x, end=" ")
      
    