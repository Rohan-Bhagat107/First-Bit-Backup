def add(a,b=0,*args):
     print(args,end=" | ")
     sum=0
     for i in args:
          sum+=i
     print("Sum is: ",sum)


add(5)
add(10,11)
add(10,20,30)
add(10,25,46,89,95,92)
add(10,25,46,89,95,100,20,30,65)
add(10,45,46,89,95,20,80,961,589,789,256,852)