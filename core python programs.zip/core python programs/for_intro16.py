# Author =Rohan
# Date=27-12-23

# loops=Used to iterate/repeat statements
# python provides 2 loops---> foor loop & while loops

# print "Hello 5 times"

for x in range(1,6,1):
    print("Hello")

    #print "hey!" 6 times (0 to 5),default starts from 0

for a in range(6):
     print("hey!")

     #print"Hi" once:
for x in range(4,5,1):
        print("Hi")
    
    #print first 15 numbers
for no in range(1,16,1):
           print(no, end=" ")


#Practice problem
#  print numbers from 10 to 50
# print numbers 0,5,10,15........50
# print addition of first 5 numbers