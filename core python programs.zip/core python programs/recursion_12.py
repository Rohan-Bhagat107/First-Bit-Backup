b=100           #Global variables(accesed anywhere in the code)
def global_var(a):           #local varibles(accesed only inside the fun/loop)
    global b 

    print(b)
    b+=1
    print(b)
global_var(10)
