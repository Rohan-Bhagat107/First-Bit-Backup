def display(**kwargs):
    print("---------------")
    for k, v in kwargs.items():
        print(k,"-",v)
    

display(roll_no=121,name="Rohan")
display(name="Rohan",age=23,location="Pune")