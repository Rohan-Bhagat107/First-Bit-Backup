i=10
j=20
print("i=",i,"has id: ",id(i))
print("j=",j,"has id: ",id(j))
print()
j=10
print("j=",j,"has id: ",id(j))
i=20
print("i=",i,"has id: ",id(i))