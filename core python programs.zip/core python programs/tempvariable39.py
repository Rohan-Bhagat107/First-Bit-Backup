a=10
b=10
print(a)
print(b)
print(a+b)
#here (at line 7)we are just understanding type of a
print(type(a))
print(id(a))
print(id(b))
b=20
print(id(b))

