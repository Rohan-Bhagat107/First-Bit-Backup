#accept number from user and print the count of digits
#ex= number=539->3 digit
#ex=number=58961->5 digit
count=0
n=int(input("Enter a number: "))
if n>=0:
    sum=0
    while n!=0:
        d=n%10
        n=n//10
        count+=1
        sum+=d
print("Number of digits is: ",count)
print("sum of digits is: ",sum)
