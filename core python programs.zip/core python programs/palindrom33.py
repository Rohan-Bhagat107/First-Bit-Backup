no=int(input("Please enter 3 digit no."))
org_no=no  # save the copy of original no. for comapring at the last

rev=0
rev=rev*10+no%10   
no=no//10

rev=rev*10+no%10
no=no//10

rev=rev*10+no%10
no=no//10

print(rev)

if rev==org_no:
        print("It is palindrome")
else:
    print("It is not palindrome")