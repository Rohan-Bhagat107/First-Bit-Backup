# Author=Rohan
# Date=25-12-23

#Task-
#Accept username and password from user 
    # If the user name matches with "admin" and the password with "admin1234"
    #then generate 4 digit OTP(& print it on screen)
    #ask the user to enter OTP
     #if OTP matches 
    # then print "Login is succesfull"
    #else print "Invalid OTP"
# else print "Invalid credentials"

import random

username=input("Please enter your username: ")
password=input("Please enter your password: ")
if (username=="admin") and (password=="admin1234"):
   #generate 4 digit OTP(And print it on screen)
   otp=random.randint(1000,9999)
   print("OTP for your login is:",otp)
   #ask user for OTP
   user_otp=int(input("Please enter OTP that we have sent :"))
   #match the otp
   if(otp==user_otp):
      print("OTP matched ")
      print("Login is succesfull")
   else:
      print("Invalid OTP please re-enter")
else:
     print("Invalid Credentials")


