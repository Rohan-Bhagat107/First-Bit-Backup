#WAP to check if given number is armstrong number or not

num=int(input("Enter a number."))   #153
org_no=num
#count number of digits
count=0
while num!=0:
    d=num%10    #3
    num=num//10   #15
    count+=1

#Do the sum of all digits(power of count)
sum=0
num=org_no
while num!=0:    
    x=num%10    #3
    num=num//10   #15
    power=x**count     
    sum+=power

if sum==org_no:
    print(org_no,"is an armstrong number.")
else:
    print(org_no,"is not an armstrong number")

                

                #H W
    #accept a number from user
    # add it to sum
    #confirm if user wants to continue
    #if user enters"y" ,then ask for another number and keep on doing it till user says"n"
    #in the end print the sum