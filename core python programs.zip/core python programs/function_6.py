#fun to accept 2 numbers from user and print max of them.

def max():
    a=int(input("Enter 1st no.: "))
    b=int(input("Enter 2nd no.: "))
    if a>b:
        print("Max of your number is: ",a)
    elif a==b:
        print("Both are same: ",b)
    else:
        print("Max of your number is: ",b)

max()



#fun to find max of two number 
# def max(a,b):
#     if a>b:
#         print(a)
#     else:
#         print(b)

# a=int(input("Enter 1st number: "))
# b=int(input("Enter 2nd number: "))
# max(a,b)


#fun to find max of two number 
# def max(a,b):
#     if a>b:
#         return a
#     else:
#         return b 

# x=max(5,9)
# print(x)
