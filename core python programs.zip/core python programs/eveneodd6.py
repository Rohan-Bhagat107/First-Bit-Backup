x=int(input("Please enter a no.: "))
if x%2==0:
     print("is an even no.")
else:
     print("is an odd no.")