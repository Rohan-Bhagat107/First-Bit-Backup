# Author=Rohan
# Date=25-12-23

#Task-
#Accept username and password from user 
# If the user name matches with "admin" and the password with "admin1234"
# then print "Login is succesfull"
# else print "Invalid credential"

username=input("Please enter your username: ")
password=input("Please enter your password: ")
if (username=="admin") and (password=="admin1234"):
    print("login is Succesfull")
else:
    print("Invalid Credential")

    