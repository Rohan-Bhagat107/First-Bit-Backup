# Author=Rohan
# date=19-12-23
a=10
b=20
c=a+b
# print("sum="+str(c))
print("sum of",a, "and",b,"is",c)

#here o/p is in two lines
# print("Hello")
# print("World")
#here o/p is in single line
# print("Hello",end='&')
# print("World")
