a=input("Enter 1st no.")
b=input("Enter 2nd no.")
print(a-b)