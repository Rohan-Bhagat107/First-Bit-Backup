#armstrong number or not using recursion

def num(n):

    if n>0:
        sum=((n%10)**3)+num(n//10)

        return sum 
    else:
        return 0

no=int(input("Enter a number that you want to check:"))
res=num(no)
print(res)