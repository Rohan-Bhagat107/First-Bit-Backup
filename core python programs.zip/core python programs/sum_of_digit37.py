# accept a two digit no.from user and print sum of their digits
a=68
b=68%10
c=68//10
print(b+c)


a=35
b=35%10
c=35//10
print(b+c)
