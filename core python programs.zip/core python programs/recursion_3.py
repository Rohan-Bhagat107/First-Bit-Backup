def fact(n):
    if n==1:
        return 1
    else:
        f=n*fact(n-1)
        return f
    
res=fact(5)
print("factorial of 5 is: ",res)
