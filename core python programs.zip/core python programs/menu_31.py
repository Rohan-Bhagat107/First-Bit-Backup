# Author=Rohan
# Date=26-12-23

# print "Welcome to my application"
# Accept first no
# accept second no.
# ask user that which operation you want to perform(+,-,/,%)
# accept choice of user 

print("Welcome to my application")
first_no=int(input("Enter first no.: "))
second_no=int(input("Enter second no.: "))
choice=input("Which operation you want to perform (+,-,/,%):")

if choice== "+":
        print("Addition of",first_no,"&",second_no,"is: ",int(first_no+second_no))
elif choice=="-":
        print("Subtraction of",first_no,"&",second_no,"is: ",int(first_no-second_no))

elif choice=="*":
        print("Multiplication of",first_no,"&",second_no,"is: ",int(first_no*second_no))

elif choice=="/":
        print("Division of",first_no,"&",second_no,"is: ",int(first_no/second_no))

else:
        print("Invalid choice")
