'''Author=Rohan 
Date=19-12-23'''
#accept price of a book from user and display the amount that has to pay after 10%of discount

book_price=int(input("Enter price of book: "))
discount=10 #it is in %
total_discount=book_price*(discount/100)
final_price=int(book_price-total_discount)
print("Total price after discount is:",final_price,"/-")

