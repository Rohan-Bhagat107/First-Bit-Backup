#write a function to print get_reverse(no)
#it returns reverse of the number


def get_reverse(no):
    org_no=no
    rev=0
    while no!=0:
    
        rev=rev*10+no%10
        no=no//10
    return rev

res=get_reverse(25)
print(res)
 


 #write a function get_palindrome(no)
#returns True if it is palindrome else false

def is_palindrome(n):
    if get_reverse(n)==n:
        return True
    else:
        return False

print(is_palindrome(151))
print(is_palindrome(157))

