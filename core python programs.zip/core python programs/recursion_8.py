#Armstrong number or not using recursion
def num(n):

    if n==0:
        return 0 
    else:
        sum=((n%10)**3)+num(n//10)
        return sum

no=int(input("Enter a number that you want to check:"))
res=num(no)
print(res)