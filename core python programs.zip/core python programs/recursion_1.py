def disp(n):
    if n==0:
        return
    else:
        print(n)
        disp(n-1)

disp(5)