#find minimum number of notes to represent any amount that user enters

amt=int(input("Enter your amount: "))         #500 200 100 50 20 10 

n1=amt//500
amt=amt%500

n2=amt//200
amt=amt%200

n3=amt//100
amt=amt%100

n4=amt//50
amt=amt%50

n5=amt//20
amt=amt%20

n6=amt//10
amt=amt%10

print("To represent your amount you need",n1,"notes of 500",n2,"notes of 200",n3,"notes of 100",n4,"notes of 50",n5,"notes of 20",n6,"notes of 10")
