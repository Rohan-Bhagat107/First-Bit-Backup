a=int(input("Please enter first no.: "))
b=int(input("Please enter second no.: "))
if a > b:
    print(a)
if a < b:
        print(b)
if a == b:
        print(a)
        