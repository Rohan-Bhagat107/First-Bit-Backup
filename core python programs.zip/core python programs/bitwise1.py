# Author=Rohan
# Date=25-12-23

# Bitwise operator

a=7  #binary form of this is 0000 0111

b=23   #binary form of this is 0001 0111
print(a&b)  #7

print(a | b)  #23

print(a^b)   #16

print(a>>2)     #1

print(a<<2)     #28

print(a<<3)

print(~a)  #-8