# Author=Rohan
# Date=29-12-23
# Accept a number from user and print if it is prime or not


n=int(input("Enter a number that you want to check."))
for i in range(2,n):
    if n%i==0:
        print("Not a prime number.")
        break

else:
    print("It is a prime number.")