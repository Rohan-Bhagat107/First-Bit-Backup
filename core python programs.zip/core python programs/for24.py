# print addition of first 5 numbers
sum=0
for x in range(1,6,1):
   sum+=x
print("Addition of 1st five no. is",sum)

                                #H.W

# print first 10 numbers but o/p should Be 
#  1 is an odd no.
#  2 is an even no.
#  3 is odd no.
# .
# .
# .
# .
# .10 is an even no.