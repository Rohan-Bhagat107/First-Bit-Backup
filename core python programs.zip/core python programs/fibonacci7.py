n=int(input("How many numbers you have to print: "))
a=1
b=0
for i in range(n):
    c=a+b
    print(c)
    a=b
    b=c