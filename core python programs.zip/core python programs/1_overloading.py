                                #function overloading
                             # Date=18-01-24

def add(a,b):
    print(a+b)

def add(a,b,c):
    print(a+b+c)

#add(10,20)           this will give an error
add(10,20,30)


#default arguments 

# def add(a,b,c=0):
#     print(a+b+c)

# add(10,20)
# add(10,20,30)



# def add(a,b=0,c=0):
#     print(a+b+c)

# add(7)
# add(10,20)
# add(10,20,30)

def add(a=0,b=0,c=0):
    print("--------------")
    print("a is:",a)
    print("b is:",b)
    print("c is:",c)
    print("Total is:",a+b+c)

add(10,20,30)
add(b=12,c=23)
add(7)
add()
