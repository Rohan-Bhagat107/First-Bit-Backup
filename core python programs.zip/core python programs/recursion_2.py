def demo(n):
    if n==0:
        print("--------------------------")
        return
    else:
        print(n)
        demo(n-1)
        print(n*n)

demo(5)