# Author=Rohan
# Date=29-12-23

#Task-

# print first N numbers from user 
#  but accept N from user
#  find if no. is prime
# if it is prime print it and increment count
# if count matches with user input n then stop
    #  if count==n 
    #  break
count=0
n=int(input("Please enter how many prime numbers you want to print: "))
for i in range(2,500):
    for x in range(2,500):
     if i%x==0:
        #print("No. is not  prime.")
        break
        
else :
     print(n)
     count+=1
print(n)     
    # if count==n:
    #     break
