#WAP to print
#         *   
#       *   *   
#     *   *   *
#   *   *   *   *
# *   *   *   *   *
#   *   *   *   *
#     *   *   *
#       *   *
#         *

for i in range(1,6):      
    for j in range(1,6-i):
        print(" ",end=" ")
    for j in range(1,i+1):
        print("*  ",end=" ")
    print( )

for i in range(2,6):         # row
    for j in range(2,i+1):   #print $ or space
        print(" ",end=" ")
    for j in range(1,7-i):    #print *
        print("*  ",end=" ")    #give 2 spaces after *
    print( )