# Author =Rohan
# Date=28-12-23
#print first 10 numbers but o/p should Be 
#  1 is an odd no.
#  2 is an even no.
#  3 is odd no.
# .
# .
# .
# .
# .10 is an even no.

for x in range (1,11,1):
    print(x, end=" ")
    if x%2==0:
     print("is an even no.")
    else:
     print("is an odd no.")