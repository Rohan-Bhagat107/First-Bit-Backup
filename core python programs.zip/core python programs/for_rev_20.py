# Author=Rohan
# Date=28-12-23

# W.A.P to print n numbers by taking user input from user

n=int(input("Enter how many numbers you have to print: "))


for x in range(1,n+1,1):
    print(x)


# for x in range(n+1):
#     print(x)