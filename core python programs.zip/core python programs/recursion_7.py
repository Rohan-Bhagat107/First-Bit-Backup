#print o/p as given below using recursion
# 5
# 4
# 3
# 2
# 1
# ***
# 1
# 2
# 3
# 4
# 5

def num(n):
    if n==0:
        print ("***")
        return
    else:
        print(n)
        num(n-1)
        # num(n-1)
        print(n)
        
num(5)