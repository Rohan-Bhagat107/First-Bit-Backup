# print numbers 0,5,10,15........50
for no in range (0,55,5):
    print(no, end=" ")