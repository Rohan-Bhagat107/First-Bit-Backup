#accept number from user and print its reverse and check if it is palindrome or not

n=int(input("Enter number: "))
org_no=n
rev=0
while n!=0:
    rev=rev*10+n%10
    n=n//10
print("Reverse of your number is: ",rev)
if rev==org_no:
    print("It is a palindrome.")
else:
 print("Not a palindrome.")