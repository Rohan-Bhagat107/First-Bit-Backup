#WHILE LOOP STARTS TODAY ON 2-1-24
n=int(input("Enter a number: "))
if n>=0:
    sum=0
    while n!=0:
        d=n%10
        n=n//10
        sum=sum+d
    print("sum of digits is: ",sum)  
else:
  print("Invalid number")      
        