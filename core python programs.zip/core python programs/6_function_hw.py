#WAP to accept marks of 3 subjects from user 
#write a function get_grade()which will accept marks of 3 subjects as parameters
#calculate average of these marks in this function and return a grade based on following conditions
#avg.marks>=90 then "A" grade
#avg.marks>=80 and <90 then "B+" grade
#avg.marks>=70  and <80 then "B" grade
#avg.marks<70 then "Pass" grade

def get_grade(a,b,c):
    sum=a+b+c
    avg_marks=int((sum)/3)
    if avg_marks>=90:
        return "A"
    elif avg_marks>=80 and avg_marks<90:
        return "B+"
    elif avg_marks>=70 and avg_marks<80:
        return "B"
    elif avg_marks<70:
        return "Pass"
    else:
        return "Invalid marks"
    
m1=int(input("Enter marks of sub 1: "))
m2=int(input("Enter marks of sub 2: "))
m3=int(input("Enter marks of sub 3: "))

res=get_grade(m1,m2,m3)

print("Grade =",res)