
def factorial(n):
    f=1
    for i in range (1,n+1):
        f=1
        f=f*i
        if i==1:
            print(i,end=" ")
        else:
            print(i,"x",end=" ")
    print("=",f)
factorial(5)