#WAP to print the numbers form n to 1 in reverse order using recursion

# def rev(n):
#     if n==0:
#         return 0
#     else:
#         print(n)
#         rev(n-1)
        


# n=int(input("Enter a number: "))
# rev(n)

#WAP to print numbers in forward direction

def rev(n):
    if n==0:
        return 0
    else:
        rev(n-1)
        print(n)


n=int(input("Enter a number: "))
rev(n)


