# Author=Rohan
# Date=29-12-23
#  print all prime numbers from 10 to 100

# no=10
for no in range(10,101):
    for i in range(2,int(no/2)):
        if no%i==0:
         break

    else:
     print(no,end=" ")


              #H.W for 1-1-24
             #  print first N numbers from user 
              
              #  but accept N from user
#      find if no. is prime
# if it is prime print it and increment count
# if count matches with user input n then stop
    #  if count==n 
    #  break