#WAP to find factorial of number:
# def factorial(n):
#     if n==1:
#         return 1
#     else:
#         return n*factorial(n-1)
    

# no=int(input("Enetr a number: "))
# res=factorial(no)
# print(res)



#WAP to find  sum of factorial of number:
def sum_of_factorial(n):
    if n==1:
        return 1
    else:
        return n*sum_of_factorial(n-1)
def sum(no):
    if no==0:
        return 0
    else:
        return sum_of_factorial(no)+sum(no-1)
    

no=int(input("Enter a number: "))
res=sum(no)
print(res)