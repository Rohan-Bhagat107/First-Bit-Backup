# Author=Rohan
# Date=28-12-23
# task-
# Find the count of odd numbers from 35 to 80
count_odd=0
for x in range (35,81,1):
    if x%2!=0:
      print(x,end=" ")
      count_odd+=1

print("\ntotal odd numbers within given range is: ",count_odd)        

                          
                          #H.W for 29-12-23
              #Accept 5 numbers (3 digit) from user .& print how many of them are palindrome
