#WAP to accept a number from user and print numbers till 1 in reverse order

def display(n):
    if n>0:
        print(n)
        display(n-1)
        
    else:
        return


no=int(input("Enter a number: "))   
display(no)

                                   #or
# def display(n):
#     if n>0:
#         print(n)
#         display(n-1)
        
# no=int(input("Enter a number: "))   
# display(no)


                                          #or

# def display(n):
#     if n==0:
#         return 
        
#     else:
#         print(n)
#         display(n-1)
#         
        
# display(5)