for i in range(1,6):         #ROW
    for j in range(5,0,-1):         #column
        print(j,end=" ")
    print( )

