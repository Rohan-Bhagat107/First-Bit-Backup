#WAP to print sum of digits using recursion

def sum_of_digit(n):
    if n==0:
        return 0
    else:
        a=n%10
        sum=a+sum_of_digit(n//10)
        return sum

n=int(input("Enter a number: "))
res=sum_of_digit(n)
print("Sum of digits of your",n,"is: ",res)