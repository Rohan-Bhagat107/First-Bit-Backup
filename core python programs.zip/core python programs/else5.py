a=int(input("Please enter first no.: "))
b=int(input("Please enter second no.: "))
if a > b:
    print(a)
    print("The max between ",a,"and",b,"is: ",a)

else:
      print(b)
      print("The max between ",a,"and",b,"is: ",b)


                              #or
      
# a=int(input("Please enter first no.: "))
# b=int(input("Please enter second no.: "))
# if a > b:
#      max=a
# else:
#      max=b
# print("The max between ",a,"and",b,"is: ",max)     
      


                                    #or
      
# a=int(input("Please enter first no.: "))
# b=int(input("Please enter second no.: "))
# if a > b:
#     print("The max between ",a,"and",b,"is: ",a)
# else:
#      if a < b:
#           print("The max between ",a,"and",b,"is: ",b)
#      else:
#           print("Both are same")
