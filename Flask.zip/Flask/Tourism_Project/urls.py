import category_op as cat
import place_op as pl
import package_op as pack
import admin_op as admin
import user as user
from main import app

#-------------------------Category------------------------------------

app.add_url_rule("/showAllCategory",view_func= cat.showAllCategory)
app.add_url_rule("/addCategory",view_func=cat.addCategory,methods=["GET","POST"])
app.add_url_rule("/delete/<cid>",view_func=cat.deleteCategory,methods=["GET","POST"])
app.add_url_rule("/edit/<cid>",view_func=cat.editCategory,methods=["GET","POST"])

#-------------------------Places------------------------------------

app.add_url_rule("/showAllPlaces",view_func=pl.showAllPlaces)
app.add_url_rule("/addPlace",view_func=pl.addPlace,methods=["GET","POST"])
app.add_url_rule("/editPlace/<pid>",view_func=pl.editPlace,methods=["GET","POST"])
app.add_url_rule("/deletePlace/<pid>",view_func=pl.deletePlace,methods=["GET","POST"])

#-------------------------Packages------------------------------------
app.add_url_rule("/showAllPackage",view_func=pack.showAllPackage)
app.add_url_rule("/addPackage",view_func=pack.addPackage,methods=["GET","POST"])
app.add_url_rule("/editPackage/<packid>",view_func=pack.editPackage,methods=["GET","POST"])
app.add_url_rule("/deletePackage/<pid>",view_func=pack.deletePackage,methods=["GET","POST"])

#-------------------------Admin------------------------------------

app.add_url_rule("/adminlogin",view_func=admin.adminlogin,methods=["GET","POST"])
app.add_url_rule("/adminHome",view_func=admin.adminHome)
app.add_url_rule("/adminLogout",view_func=admin.adminLogout)


#------------------------User------------------------------------
app.add_url_rule("/",view_func=user.homepage)
app.add_url_rule("/showplaces/<cid>",view_func=user.ShowPlaces,methods=["GET","POST"])
app.add_url_rule("/viewdetailsplace/<pid>",view_func=user.ViewDetails,methods=["GET","POST"])
app.add_url_rule("/register",view_func=user.register,methods=["GET","POST"])
app.add_url_rule("/login",view_func=user.login,methods=["GET","POST"])
app.add_url_rule("/logout",view_func=user.logout,methods=["GET"])
app.add_url_rule("/showcart",view_func=user.showcart,methods=["GET","POST"])
app.add_url_rule("/reset_password",view_func=user.resetpassword,methods=["GET","POST"])
app.add_url_rule("/reset",view_func=user.updatepassword,methods=["GET","POST"])
app.add_url_rule("/makepayment",view_func=user.makepayment,methods=["GET","POST"])
app.add_url_rule("/deleteconfirmation/<cart_id>",view_func=user.deleteconfirmation,methods=["GET","POST"])
app.add_url_rule("/edit_cart/<cart_id>",view_func=user.edit,methods=["GET","POST"])
#app.add_url_rule("/insufficientBalance",view_func=user.insufficientBalance,methods=["GET","POST"])


#-----------------------------Packages----------------------

app.add_url_rule("/viewdetailspack/<packid>",view_func=user.ViewDetailspack,methods=["GET","POST"])
app.add_url_rule("/showpackage/<packid>",view_func=user.showpackages,methods=["GET","POST"])
app.add_url_rule("/aboutus",view_func=user.aboutUs,methods=["GET"])

app.add_url_rule("/clearcart",view_func=user.clearCart,methods=["GET","POST"])

