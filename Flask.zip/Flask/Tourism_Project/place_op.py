from flask import render_template,redirect,request
import mysql.connector 
from werkzeug.utils import secure_filename


mydb=mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="Tourism")
cur=mydb.cursor()

def showAllPlaces():
    sql="select * from place"
    cur.execute(sql)
    places=cur.fetchall()
    return render_template("place/showAllPlaces.html",places=places)

def addPlace():
    if request.method == "GET":
        sql="select * from category"
        cur.execute(sql)
        cats=cur.fetchall()
        return render_template("place/addplace.html",cats=cats)
    else:
        pname=request.form["pname"]
        price=request.form["price"]
        cid=request.form["cid"]
        f=request.files["image_url"]
        filename=secure_filename(f.filename)
        filename="static/Images/"+f.filename

        f.save(filename)
        filename="Images/"+f.filename

        sql = "insert into place (pname,ImageUrl,Price,cid) values(%s,%s,%s,%s)"
        val = (pname,filename,price,cid)
        cur.execute(sql,val)
        mydb.commit()
        return redirect("/showAllPlaces")

def editPlace(pid):
    if request.method=="GET":
        sql="select * from place where pid=%s"
        val=(pid,)
        cur.execute(sql,val)
        place=cur.fetchone()
        print(place)
        return render_template("place/editPlace.html",place=place)
    else:
        pname=request.form["pname"]
        f=request.files["image_url"]
        price=request.form["price"]
        filename=secure_filename(f.filename)
        filename="static/Images/"+f.filename
        f.save(filename)
        filename="Images/"+f.filename

        sql = "update place set pname=%s,ImageUrl=%s,Price=%s where pid=%s"
        val = (pname,filename,price,pid)
        cur.execute(sql,val)
        mydb.commit()
        return redirect("/showAllPlaces")

def deletePlace(pid):
    if request.method=="GET":
        return render_template("place/deletePlace.html")
    else:
        action=request.form["action"]
        if action=="Yes":
            sql="delete from place where pid=%s"
            val=(pid,)
            cur.execute(sql,val)
            mydb.commit()
               
        return redirect("/showAllPlaces")
