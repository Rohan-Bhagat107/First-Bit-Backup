from flask import render_template,redirect,request
import mysql.connector 


mydb=mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="Tourism")
cur=mydb.cursor()

def showAllCategory():
        sql="select * from category"
        cur.execute(sql)
        cats=cur.fetchall()
        return render_template("Category/showAllCategory.html",cats=cats)


def addCategory():
    if request.method=="GET":
        return render_template ("Category/addCategory.html")
    else:
        cname=request.form["cname"]
        sql="insert into category(cname) values(%s)"
        val=(cname,)
        cur.execute(sql,val)
        mydb.commit()
        return redirect("/showAllCategory")

def deleteCategory(cid):
    if request.method=="GET":
        return render_template("Category/deleteCategory.html")
    else:
        action=request.form["action"]
        if action=="Yes":
            sql="delete  from category where cid=%s"
            val=(cid,)
            cur.execute(sql,val)
            mydb.commit()
            
        
        return redirect("/showAllCategory")

def editCategory(cid):
    if request.method=="GET":
        
        return render_template("Category/editCategory.html")
    else:
        
        cname=request.form["cname"]
        sql="update category set cname=%s where cid=%s"
        val=(cname,cid)
        cur.execute(sql,val)
        mydb.commit()
        return redirect("/showAllCategory")