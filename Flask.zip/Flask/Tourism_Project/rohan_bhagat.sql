-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: tourism
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adminuser`
--

DROP TABLE IF EXISTS `adminuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adminuser` (
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adminuser`
--

LOCK TABLES `adminuser` WRITE;
/*!40000 ALTER TABLE `adminuser` DISABLE KEYS */;
INSERT INTO `adminuser` VALUES ('Admin1','Admin@123','admin@100gmail.com'),('Admin2','Admin@1234','admin@101gmail.com');
/*!40000 ALTER TABLE `adminuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking`
--

DROP TABLE IF EXISTS `booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking` (
  `ord_id` int NOT NULL AUTO_INCREMENT,
  `booking_date` date DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `username` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ord_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking`
--

LOCK TABLES `booking` WRITE;
/*!40000 ALTER TABLE `booking` DISABLE KEYS */;
INSERT INTO `booking` VALUES (6,'2024-06-25',7900,'prafull'),(7,'2024-06-25',2500,'prafull'),(8,'2024-06-25',2500,'prafull'),(9,'2024-06-25',1900,'prafull'),(10,'2024-06-25',1900,'prafull'),(11,'2024-06-25',2500,'prafull');
/*!40000 ALTER TABLE `booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `cart_vw`
--

DROP TABLE IF EXISTS `cart_vw`;
/*!50001 DROP VIEW IF EXISTS `cart_vw`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `cart_vw` AS SELECT 
 1 AS `cart_id`,
 1 AS `pid`,
 1 AS `pname`,
 1 AS `price`,
 1 AS `imageurl`,
 1 AS `no_of_persons`,
 1 AS `Subtotal`,
 1 AS `username`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `cid` int NOT NULL AUTO_INCREMENT,
  `cname` varchar(45) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Beaches'),(2,'Religious'),(3,'Historical ');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mycart`
--

DROP TABLE IF EXISTS `mycart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mycart` (
  `cart_id` int NOT NULL AUTO_INCREMENT,
  `place_id` int DEFAULT NULL,
  `status` enum('cart','order') DEFAULT NULL,
  `username` varchar(25) DEFAULT NULL,
  `No_of_persons` int DEFAULT '1',
  `order_id` int DEFAULT NULL,
  PRIMARY KEY (`cart_id`),
  KEY `username` (`username`),
  KEY `place_id` (`place_id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `mycart_ibfk_1` FOREIGN KEY (`username`) REFERENCES `userinfo` (`username`),
  CONSTRAINT `mycart_ibfk_2` FOREIGN KEY (`place_id`) REFERENCES `place` (`pid`),
  CONSTRAINT `mycart_ibfk_3` FOREIGN KEY (`order_id`) REFERENCES `booking` (`ord_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mycart`
--

LOCK TABLES `mycart` WRITE;
/*!40000 ALTER TABLE `mycart` DISABLE KEYS */;
INSERT INTO `mycart` VALUES (10,2,'order','prafull',1,NULL),(11,7,'order','prafull',1,NULL),(12,3,'order','prafull',1,NULL),(22,2,'order','prafull',1,NULL),(23,5,'order','prafull',1,NULL),(24,6,'order','prafull',1,NULL),(25,4,'order','prafull',1,NULL),(26,6,'order','prafull',1,NULL);
/*!40000 ALTER TABLE `mycart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `package`
--

DROP TABLE IF EXISTS `package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `package` (
  `packid` int NOT NULL AUTO_INCREMENT,
  `packname` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `price` int NOT NULL,
  `Persons` int NOT NULL,
  `cid` int NOT NULL,
  `Image` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`packid`),
  KEY `cid` (`cid`),
  CONSTRAINT `package_ibfk_1` FOREIGN KEY (`cid`) REFERENCES `category` (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package`
--

LOCK TABLES `package` WRITE;
/*!40000 ALTER TABLE `package` DISABLE KEYS */;
INSERT INTO `package` VALUES (1,'South Goa Tour','Exotic beaches ,historic places in Goa',5000,1,1,'Images/south goa.jpeg'),(2,'North Goa Tour','Historic Places,Sunkissed beach vibes',2500,1,3,'Images/north goa.jpg'),(3,'The Historical Touch','Temples, Churches, Forts',3500,1,2,'Images/Corjuem Fort.jpg'),(4,'Saltwater in my veins.','Beaches, Sunkissed vibes',4800,1,1,'Images/baga beach.jpg');
/*!40000 ALTER TABLE `package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment` (
  `cardno` varchar(16) DEFAULT NULL,
  `cvv` varchar(4) DEFAULT NULL,
  `expiry` varchar(10) DEFAULT NULL,
  `balance` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES ('111','111','12/2020',12500),('222','222','12/2020',7500),('333','333','12/2020',10000);
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `place`
--

DROP TABLE IF EXISTS `place`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `place` (
  `pid` int NOT NULL AUTO_INCREMENT,
  `pname` varchar(60) NOT NULL,
  `ImageUrl` varchar(100) NOT NULL,
  `price` int NOT NULL,
  `cid` int NOT NULL,
  `packid` int DEFAULT NULL,
  `Description` mediumtext,
  PRIMARY KEY (`pid`),
  KEY `cid` (`cid`),
  KEY `packid` (`packid`),
  CONSTRAINT `place_ibfk_1` FOREIGN KEY (`cid`) REFERENCES `category` (`cid`),
  CONSTRAINT `place_ibfk_2` FOREIGN KEY (`packid`) REFERENCES `package` (`packid`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `place`
--

LOCK TABLES `place` WRITE;
/*!40000 ALTER TABLE `place` DISABLE KEYS */;
INSERT INTO `place` VALUES (1,' Aguada Fort','Images/Aguada Fort.jpg',4500,3,1,'Fort Aguada is a typical example of Portuguese military architecture. Built of durable laterite stone, so easily available all over Goa, its massive bulwarks which stand fully 5 metres high and 1.3 metres thick, have stood the test of time, lashed as they are by fierce monsoon storms and winds. The fort covers the entirety of the peninsula, and was built using the natural terrain in order to make it more difficult for its walls to be breached.'),(2,'Corjuem Fort','Images/Corjuem Fort.jpg',1200,3,2,'Corjuem fort was built in 1550 and was originally the property of the Bhonsle rulers of Sawantwadi. However, in the time of Viceroy Caetano de Mello e Castro, the fort was annexed to the Portuguese administration of Goa. The colonists rebuilt the fort in 1705 to boost their defences of Panaji, which had by then become the capital city.Although small, the fort had great strategic importance. During the 18th century, it held off Maratha invasions by Rane Rajput and the Bhonsles. In the early 1800’s the fort was used as a military school.'),(3,'Baga Beach','Images/baga beach.jpg',1700,1,4,'1)Watersports : Baga Beach’s major attraction is its plethora of watersports like parasailing, wake boarding, windsurfing, kite surfing, jet skiing that can be enjoyed by the tourists.2)Dolphin Sighting Trips : A lot of trips are organized from Baga Beach to sight dolphins in the sea and to witness the beautiful islands close to the beach.3)Snow Park : Baga Beach has an indoor snow park where one can enjoy a number of games in the play area, sledge in the sledding area and relish a few drinks at the ice bar.'),(4,'Shree Mangesh Temple','Images/Mangesh Temple.jpg',1900,2,3,'Located at Priol in the Ponda Taluka Shri Mangeshi Temple is at a distance of 22 kms from Panaji. Dedicated to Lord Manhueshi who is a form of another Hindu God Lord Shiva it is quite popular amongst tourists.There are many legends associated with this temple. According Hindu Beliefs Lord Shiva had lost everything to his wife Goddess Parvati at the game of dice.This is when he had come to Goa.'),(5,'Palolem Beach','Images/palolem beach.jpg',1500,1,4,'1)Hike to Butterfly Beach : During the low tide, one can even attempt to hike to the Butterfly Beach. It is the perfect place to catch the view of the beautiful sunset.2) Cotigao Wildlife Sanctuary : A day trip from Palolem can be made to Cotigao Wildlife Sanctuary, where the rich wildlife of Goa can be witnessed.3)Shopping : Palolem has a strip of shops just behind the beach where one can buy a number of items including souvenirs and Bohomenian jewellery and clothing.'),(6,'Estevam Island','Images/Estevam Island.jpg',2500,3,1,'St Estevam is an Island in Tiswadi, Goa. It is encircled by the Mandovi River on all sides and was connected to the mainland by the bridge only in the mid 1980s. Also known as Juvem and in the past it was known as Shakecho Juvo - the isle of vegetables. Santo Estevao is most famous for its premium seven-ridged, light-green and long lady finger or okra. That\'s why many people refer to villagers as \'bhendde\'.Juvem is the fourth largest island in Goa. This Island originally consisted of three small islets Jua, Tolto and Vantso with a canal connecting them. These small islets have been joined together into one island that is Santo Estevam. Juvem is rich in historical heritage and natural beauty.'),(7,'Safa Masjid','Images/Safa Masjid.jpg',2300,2,3,'The Shahouri Masjid in Ponda taluka, the biggest and most famous of the mosques in Goa, was built in 1560 by Ibrahim Adilshah of Bijapur. Adjacent to the mosque is a well constructed masonry tank with small chambers with \'meharab\' designs.'),(8,'Varca Beach','Images/Varca Beach.jpg',2000,1,4,'What you won’t find on Varca Beach is a lot of beach shacks or eateries of any kind. But maybe, that’s where the appeal of Varca Beach lies! It’s relatively uncrowded compared to the other beaches in Goa, and gives you the privacy you need while enjoying a vacation. It enjoys a great location too, as it’s situated just 45 minutes from the airport as compared to the other beaches in South Goa.'),(9,'Benaulim Beach','Images/benaulim beach.jpg',2200,1,4,'Benaulim Beach, surprisingly, stands apart from the other beaches of North Goa. It is much quieter than them and yet, has enough avenues that ensures you have a wonderful time. The only time when it does tend to get crowded is in the evening, when tourists visit it to enjoy the lovely sunset.'),(10,'St. Augustine Tower','Images/St. Augustine Tower.jpg',1400,3,2,'Built in the year of 1602, the Church and monastery of St Augustine is believed to be constructed by the Augustinian friars. The construction of church which was started in 1597 and completed in 1602 took almost 400 years. The designer of the church isn’t known but has been believed to be of Italian origin.'),(11,'Birla Radha Krishna Mandir','Images/Radha Krishn Mandir.jpg',2800,2,3,'The Birla Radha Krishna Mandir in Goa, also known as the Birla Temple, is a magnificent architectural marvel that showcases the rich cultural and spiritual heritage of India. This temple, dedicated to Radha Krishna, Ganesh, Hanuman, and Ramdarbar, is a welcoming place that attracts devotees of all religions. Here is a travel blog capturing the essence of this divine destination'),(12,'Church of St. Francis of Assissi','Images/St. Francis of Assissi.jpg',3000,2,3,'The original shrine, constructed by the Fransican monks in 1521 and subsequently enlarged, was showing signs of decay, so a new church was constructed and dedicated to the Holy Spirit. Built in 1665, it retained the portal of the old structure which was in the Portuguese–Manueline style. It is a unique architectural specimen, of this style in the country.The façade of the church is built in the Tuscan style of architecture with only the portal being Manueline since it is a relic from the older structure. The façade is also distinctive in that it is flanked by octagonal towers.');
/*!40000 ALTER TABLE `place` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `place_cat_vw`
--

DROP TABLE IF EXISTS `place_cat_vw`;
/*!50001 DROP VIEW IF EXISTS `place_cat_vw`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `place_cat_vw` AS SELECT 
 1 AS `pid`,
 1 AS `pname`,
 1 AS `cname`,
 1 AS `imageurl`,
 1 AS `price`,
 1 AS `cid`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `place_pack_vw`
--

DROP TABLE IF EXISTS `place_pack_vw`;
/*!50001 DROP VIEW IF EXISTS `place_pack_vw`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `place_pack_vw` AS SELECT 
 1 AS `pid`,
 1 AS `pname`,
 1 AS `packname`,
 1 AS `image`,
 1 AS `price`,
 1 AS `packid`,
 1 AS `description`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `userinfo`
--

DROP TABLE IF EXISTS `userinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userinfo` (
  `username` varchar(25) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userinfo`
--

LOCK TABLES `userinfo` WRITE;
/*!40000 ALTER TABLE `userinfo` DISABLE KEYS */;
INSERT INTO `userinfo` VALUES ('prafull','praful123','praful121'),('Rohan','rohan123','rohan121');
/*!40000 ALTER TABLE `userinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `cart_vw`
--

/*!50001 DROP VIEW IF EXISTS `cart_vw`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `cart_vw` AS select `m`.`cart_id` AS `cart_id`,`p`.`pid` AS `pid`,`p`.`pname` AS `pname`,`p`.`price` AS `price`,`p`.`ImageUrl` AS `imageurl`,`m`.`No_of_persons` AS `no_of_persons`,(`p`.`price` * `m`.`No_of_persons`) AS `Subtotal`,`m`.`username` AS `username` from (`place` `p` join `mycart` `m` on(((`p`.`pid` = `m`.`place_id`) and (`m`.`status` = 'cart')))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `place_cat_vw`
--

/*!50001 DROP VIEW IF EXISTS `place_cat_vw`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `place_cat_vw` AS select `p`.`pid` AS `pid`,`p`.`pname` AS `pname`,`c`.`cname` AS `cname`,`p`.`ImageUrl` AS `imageurl`,`p`.`price` AS `price`,`p`.`cid` AS `cid` from (`place` `p` join `category` `c` on((`p`.`cid` = `c`.`cid`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `place_pack_vw`
--

/*!50001 DROP VIEW IF EXISTS `place_pack_vw`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `place_pack_vw` AS select `pl`.`pid` AS `pid`,`pl`.`pname` AS `pname`,`p`.`packname` AS `packname`,`p`.`Image` AS `image`,`p`.`price` AS `price`,`p`.`packid` AS `packid`,`pl`.`Description` AS `description` from (`place` `pl` join `package` `p` on((`pl`.`packid` = `p`.`packid`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-25 17:34:17
