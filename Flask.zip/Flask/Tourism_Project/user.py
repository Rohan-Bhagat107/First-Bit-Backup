from flask import render_template,redirect,request,session
import mysql.connector
from datetime import datetime


def homepage():
    con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",
    database="tourism")
    cursor =con.cursor()

    sql = "select * from Category"
    cursor.execute(sql,)
    cats = cursor.fetchall()

    sql = "select * from package"
    cursor.execute(sql,)
    packages= cursor.fetchall()

    sql = "select * from place"
    cursor.execute(sql,)
    places = cursor.fetchall()

    return render_template("user/homepage.html",cats=cats,packages=packages,places=places)

def ShowPlaces(cid):
    con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",
    database="tourism")
    cursor =con.cursor()

    sql="select * from category"
    cursor.execute(sql,)
    cats=cursor.fetchall()

    sql="select * from place where cid=%s"
    val=(cid,)
    cursor.execute(sql,val)
    places=cursor.fetchall()


    sql="select cname from category where cid=%s"
    val=(cid,)
    cursor.execute(sql,val)
    catname=cursor.fetchone()[0]

    sql="select * from package where cid=%s"
    val=(cid,)
    cursor.execute(sql,val)
    package=cursor.fetchone()


    return render_template("user/homepage.html",cats=cats,places=places,catname=catname,package=package)

def showpackages(packid):
    con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",
    database="tourism")
    cursor =con.cursor()

    sql = "select * from Category"
    cursor.execute(sql,)
    cats = cursor.fetchall()

    sql = "select * from package"
    cursor.execute(sql,)
    packages= cursor.fetchall()

    sql = "select * from place"
    cursor.execute(sql,)
    places = cursor.fetchall()

    sql="select * from package where packid=%s"
    val=(packid,)
    cursor.execute(sql,val)
    package=cursor.fetchone()[0]
    

    return render_template("user/homepage.html",package=package,places=places,packages=packages,cats=cats)

def ViewDetails(pid):
    con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",
    database="tourism")
    cursor =con.cursor()
    if request.method=="GET":
        sql="select * from category"
        cursor.execute(sql,)
        cats=cursor.fetchall()

        sql="select * from place_cat_vw where pid=%s"
        val=(pid,)
        cursor.execute(sql,val)
        place=cursor.fetchone()

        sql = "select * from place"
        cursor.execute(sql,)
        places = cursor.fetchall()

        #sql="select * from place_pack_vw where packid=%s"
        return render_template("user/viewdetails.html",cats=cats,place=place,places=places) 
    else:
        if "uname" in session:
            uname=session["uname"] 
            place_id=request.form["pid"]
            persons=request.form["persons"]
            sql="insert into mycart(place_id,status,username,no_of_persons,Type) values(%s,%s,%s,%s,%s)"
            val=(pid,"cart",uname,persons,"Place")
            cursor.execute(sql,val)
            con.commit()
            return redirect("/showcart")
        else:
            return redirect("/login")

def ViewDetailspack(packid):
    con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",
    database="tourism")
    cursor =con.cursor()
    if request.method=="GET":
        sql="select * from category"
        cursor.execute(sql,)
        cats=cursor.fetchall()

        sql="select * from package"
        cursor.execute(sql,)
        packs=cursor.fetchall()

        sql="select * from place where packid=%s"
        val=(packid,)
        cursor.execute(sql,val)
        places=cursor.fetchall()


        sql="select * from place_pack_vw where packid=%s"
        val=(packid,)
        cursor.execute(sql,val)
        onepack=cursor.fetchall()[0]
        print(onepack)

        return render_template("user/viewdetailspack.html",cats=cats,onepack=onepack,packs=packs,places=places,name="Package") 
    else:
        if "uname" in session:
            uname=session["uname"] 
            packid=request.form["packid"]
            persons=request.form["persons"]
            sql="insert into mycart(place_id,status,username,no_of_persons,Type) values(%s,%s,%s,%s,%s)"
            val=(packid,"cart",uname,persons,"Package")
            cursor.execute(sql,val)
            con.commit()
            return redirect("/showcart")
        else:
            return redirect("/login")



def register():
    con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",
    database="tourism")
    cursor =con.cursor()
    if request.method=="GET":
        sql="select * from category"
        
        cursor.execute(sql,)
        cats=cursor.fetchall()

        sql = "select * from place"
        cursor.execute(sql,)
        places = cursor.fetchall()

        return render_template("user/register.html",cats=cats,places=places)
    else:
        uname=request.form["uname"]
        pwd=request.form["pwd"]
        email=request.form["email"]
        sql="insert into userinfo values (%s,%s,%s)"
        try:
            val=(uname,pwd,email) 
            cursor.execute(sql,val)
            con.commit()
            return redirect("/")
        except:
            return redirect("/register")

def login():
    con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",
    database="tourism")
    cursor =con.cursor()
    if request.method=="GET":
        sql="select * from category"
        cursor.execute(sql,)
        cats=cursor.fetchall()

        sql = "select * from place"
        cursor.execute(sql,)
        places = cursor.fetchall()

        return render_template("user/login.html",cats=cats,places=places)
    else:
        uname=request.form["uname"]
        pwd=request.form["pwd"]
    
        sql="select count(*) from userinfo where username=%s and password=%s"
        
        val=(uname,pwd) 
        cursor.execute(sql,val)
        count=int(cursor.fetchone()[0])
        if count==1:
            session["uname"]=uname
            return redirect("/")
    
        return redirect("/login")

def logout():
    con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",
    database="tourism")
    cursor =con.cursor()
    session.clear()
    return redirect("/")

def showcart():
    con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",
    database="tourism")
    cursor =con.cursor()
    if "uname" in session:
        if request.method=="GET":
            sql="select * from category"
        
            cursor.execute(sql,)
            cats=cursor.fetchall()

            sql="select * from final_cart_vw where username=%s"
            val=(session["uname"],)
            cursor.execute(sql,val)
            items=cursor.fetchall()

            sql="select sum(subtotal) from cart_vw where username=%s"
            cursor.execute(sql,val)
            total=(cursor.fetchone()[0])
            session["total"]=total

            sql = "select * from place"
            cursor.execute(sql,)
            places = cursor.fetchall()
                
            return render_template("user/showcart.html",items=items,total=total,cats=cats,places=places)

           
        else:
            action=request.form["action"]
            cart_id=request.form["cart_id"]
            if action=="edit":
                return redirect("/edititem/{{cart_id}}")
            else:
            
                return redirect("/deleteconfirmation/{{cart_id}}")
    
    else:
        return redirect ("/login")

def edit(cart_id):
    con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",
    database="tourism")
    cursor =con.cursor()
    if request.method=="GET":
        sql="select * from cart_vw where cart_id=%s"
        val=(cart_id,)
        cursor.execute(sql,val)
        place=cursor.fetchone()
        print(str(place))

        sql = "select * from place"
        cursor.execute(sql,)
        places = cursor.fetchall()

        return render_template("user/edit.html",place=place,places=places)
    else:
        persons=request.form["persons"]
        sql="update cart_vw set no_of_persons=%s where cart_id=%s"
        val=(persons,cart_id)
        cursor.execute(sql,val)
        con.commit()
        return redirect("/showcart")
            

def deleteconfirmation(cart_id):
    con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",
    database="tourism")
    cursor =con.cursor()
    if request.method=="GET":

        sql = "select * from place"
        cursor.execute(sql,)
        places = cursor.fetchall()

        return render_template("user/deleteconfirmation.html",places=places)
    else:
        confirmation=request.form["confirmation"]
        if confirmation=="Yes":
            sql="delete from mycart where cart_id=%s"
            val=(cart_id,)
            cursor.execute(sql,val)
            con.commit()
            return redirect("/showcart")
        else:
            return redirect("/showcart")

def resetpassword():
    con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",
    database="tourism")
    cursor =con.cursor()
    if request.method=="GET":

        sql = "select * from place"
        cursor.execute(sql,)
        places = cursor.fetchall()

        return render_template("user/verify.html",places=places)
    else:
        uname=request.form['uname']
        email=request.form["email"]
        sql="select count(*) from userinfo where username=%s and email=%s"
        val=(uname,email)
        cursor.execute(sql,val)
        count=cursor.fetchone()[0]
        print(count)
        if count==1:
            session["user"]=uname
            session["mail"]=email
            return redirect("/reset")
    
def updatepassword():
    con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",
    database="tourism")
    cursor =con.cursor()
    if request.method=="GET":

        sql = "select * from place"
        cursor.execute(sql,)
        places = cursor.fetchall()

        return render_template("user/reset.html",places=places)
    
    else:    
        pwd=request.form["pwd"]
        sql="update userinfo set password=%s where username=%s and email=%s"
        val=(pwd,session["user"],session["mail"])
        cursor.execute(sql,val)
        con.commit()
        return redirect("/login")

def makepayment():
    con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",
    database="tourism")
    cursor =con.cursor()
    sql = "select * from place"
    cursor.execute(sql,)
    places = cursor.fetchall()

    sql = "select * from Category"
    cursor.execute(sql,)
    cats = cursor.fetchall()

    if request.method=="GET":
            
            return render_template("user/makepayment.html",places=places,cats=cats)
    else:
        card_no=request.form["card_no"]
        cvv=request.form["cvv"]
        expiry=request.form["expiry"]
        amount=request.form["amt"]
        balance=request.form["balance"]
        if balance=="Yes":
            sql="select balance from payment where cardno=%s and cvv=%s and expiry=%s"
            val=(card_no,cvv,expiry)
            cursor.execute(sql,val)
            balance=cursor.fetchone()[0]
            balance=int(balance)
            amount=int(amount)
            print(balance)
            if balance>amount:
                print(cvv,card_no,expiry)
                sql="select count(*) from payment where cardno=%s and cvv=%s and expiry=%s"
                val=(card_no,cvv,expiry)
                cursor.execute(sql,val)
                count=cursor.fetchone()[0]
                print(count)
                if count==1:
                    
                    sql1="update payment set balance=balance+%s where cardno=%s"
                    val1=(session["total"],"111")
                    cursor.execute(sql1,val1)

                    sql2="update payment set balance=balance-%s where cardno=%s"
                    val2=(session["total"],card_no)
                    cursor.execute(sql2,val2)

                    sql="update mycart set status='order' where username=%s"
                    val=(session["uname"],)
                    cursor.execute(sql,val)
                    con.commit()


                    sql="insert into booking (booking_date,amount,username) values(%s,%s,%s)"
                    val=(datetime.now(),amount,session["uname"])
                    cursor.execute(sql,val)
                    con.commit()

                    dd=datetime.today().strftime("%y-%m-%d")
                    
                    sql="select ord_id from booking where booking_date=%s and amount=%s and username=%s "
                    val=(dd,amount,session["uname"])
                    cursor.execute(sql,val)
                    ord_id=cursor.fetchone()[0]


                    sql="update mycart set status='order',order_id=%s where username=%s and status='cart' "
                    val=(ord_id,session['uname'])
                    cursor.execute(sql,val)
                    con.commit()
                    return render_template("user/mybooking.html",places=places,cats=cats,dd=dd)
                    
            else:
                return redirect("/makepayment")




def aboutUs():
    con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",
    database="tourism")
    cursor =con.cursor()
    if request.method=="GET":

        sql = "select * from place"
        cursor.execute(sql,)
        places = cursor.fetchall()

        sql="select * from category"
        cursor.execute(sql,)
        cats=cursor.fetchall()

        return render_template("user/aboutus.html",places=places,cats=cats)
    
def clearCart():
    con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",
    database="tourism")
    cursor =con.cursor()
    if request.method=="GET":
        sql = "select * from place"
        cursor.execute(sql,)
        places = cursor.fetchall()

        return render_template("user/clearcart.html",places=places)
    else:
        confirmation=request.form["confirmation"]
        if confirmation=="Yes":
            sql="delete from mycart"
            cursor.execute(sql,)
            con.commit()
            return redirect("/showcart")
        else:
            return redirect("/showcart")




