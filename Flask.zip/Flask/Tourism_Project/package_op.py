from flask import render_template,redirect,request
import mysql.connector 
from werkzeug.utils import secure_filename


mydb=mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="Tourism")
cur=mydb.cursor()

def showAllPackage():
    sql="select * from package"
    cur.execute(sql)
    packages=cur.fetchall()
    return render_template("package/showAllPackage.html",packages=packages)

def addPackage():
    if request.method=="GET":
        sql="select * from category"
        cur.execute(sql)
        cats=cur.fetchall()
        return render_template("package/addPackage.html",cats=cats)
    else:
        pname=request.form["pname"]
        description=request.form["description"]
        price=request.form["price"]
        persons=request.form["persons"]
        cid=request.form["cid"]
        f=request.files["img_url"]
        filename=secure_filename(f.filename)
        filename="static/Images/"+f.filename

        #this will save the file to the specified location
        f.save(filename)
        filename="Images/"+f.filename
        sql="insert into package(packname,description,price,persons,cid,image) values(%s,%s,%s,%s,%s,%s)"
        val=(pname,description,price,persons,cid,filename)
        cur.execute(sql,val)
        mydb.commit()
        return redirect("/showAllPackage")


def editPackage(packid):
    if request.method=="GET":
        sql="select * from package where packid=%s"
        val=(packid,)
        cur.execute(sql,val)
        package=cur.fetchone()
        return render_template("package/editPackage.html",package=package)
    
    else:
        pname=request.form["pname"]
        description=request.form["description"]
        price=request.form["price"]
        persons=request.form["persons"]
        f=request.files["img_url"]
        filename=secure_filename(f.filename)
        filename="static/Images/"+f.filename

        #this will save the file to the specified location
        f.save(filename)
        filename="Images/"+f.filename
        sql="update package set packname=%s,description=%s,price=%s,persons=%s,image=%s where packid=%s"
        val=(pname,description,price,persons,filename,packid)
        cur.execute(sql,val)
        mydb.commit()
        return redirect("/showAllPackage")

# def deletePackage(pid):
    
#     if request.method=="GET":
        
#         return render_template("package/deletePackage.html")
#     else:
#         action=request.form["action"]
#         if action=="Yes":
#             print("Hello")
#             sql="delete from package where packid=%s"
#             val=(pid,)
#             cur.execute(sql,val)
#             mydb.commit()

#         return redirect("/showAllPackage")

def deletePackage(pid):
    if request.method == "GET":
        return render_template("package/deletePackage.html", pid=pid)
    else:
        action = request.form["action"]
        if action == "Yes":
            print("Hello")
            sql = "DELETE FROM package WHERE packid=%s"
            val = (pid,)
            cur.execute(sql, val)
            mydb.commit()
        return redirect("/showAllPackage")
