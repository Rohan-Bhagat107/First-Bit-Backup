from flask import render_template,redirect,request
import mysql.connector 



def showAllCategories():
    con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="cakeshop")
    cursor = con.cursor()
    sql = "select * from Category"
    cursor.execute(sql)
    cats = cursor.fetchall()
    return render_template("Category/showAllCategories.html",cats=cats)

def addCategory():
    if request.method == "GET":
        return render_template("Category/addCategory.html")
    else:
        con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="cakeshop")
        cursor = con.cursor()
        sql = "insert into Category (cname) values (%s)"
        val = (request.form["cname"],)
        cursor.execute(sql,val)
        con.commit()
        return redirect("/showAllCategories")

def deleteCategory(cid):
    if request.method == "GET":
        return render_template("Category/deleteCategory.html")
    else:
        action = request.form["action"]
        if action == "Yes":
            con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="cakeshop")
            cursor = con.cursor()
            sql = "delete from Category where cid=%s"
            val = (cid,)
            cursor.execute(sql,val)
            con.commit()
        return redirect("/showAllCategories")


def editCategory(cid):
    mydb=mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="cakeshop")
    cur=mydb.cursor()
    if request.method=="GET":
        sql="select * from category where cid=%s"
        val=(cid,)
        cur.execute(sql,val)
        record=cur.fetchone()
        return render_template("category/editCategory.html",record=record)
        
    
    else:
        cid=request.form["cid"]
        cname=request.form["cname"]

        sql="update category set cname=%s where cid=%s "
        val=(cname,cid)
        cur.execute(sql,val)
        mydb.commit()
        return redirect("/showAllCategories")

