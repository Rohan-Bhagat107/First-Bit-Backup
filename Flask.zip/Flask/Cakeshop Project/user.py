from flask import render_template,redirect,request,session
import mysql.connector


con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="cakeshop")
cursor = con.cursor()
def homepage():
    sql = "select * from Category"
    cursor.execute(sql)
    cats = cursor.fetchall()
    sql = "select * from Cake"
    cursor.execute(sql)
    cakes= cursor.fetchall()
    return render_template("user/homepage.html",cats=cats,cakes=cakes)

def ShowCakes(cid):
    sql="select * from category"
    cursor.execute(sql,)
    cats=cursor.fetchall()

    sql="select * from cake where cid=%s"
    val=(cid,)
    cursor.execute(sql,val)
    cakes=cursor.fetchall()

    sql="select cname from category where cid=%s"
    val=(cid,)
    cursor.execute(sql,val)
    catname=cursor.fetchone()[0]

    return render_template("user/homepage.html",cats=cats,cakes=cakes,catname=catname)

def ViewDetails(cakeid):
    if request.method=="GET":

        sql="select * from category"
        cursor.execute(sql)
        cats=cursor.fetchall()

        sql="select * from cake_cat_vw where cakeid=%s"
        val=(cakeid,)
        cursor.execute(sql,val)
        cake=cursor.fetchone()
        return render_template("user/viewdetails.html",cats=cats,cake=cake)
    else:
        if "uname" in session:
            uname=session["uname"]
            cake_id=request.form["cid"]
            qty=request.form["qty"]
            sql="insert into mycart(cake_id,qty,status,username) values(%s,%s,%s,%s)"
            val=(cake_id,qty,"cart",uname)
            cursor.execute(sql,val)
            con.commit()
            return redirect("/showcart")

            
        else:
            return redirect("/login")



def register():
    if request.method=="GET":
        return render_template("user/registerpage.html")
    else:
        uname=request.form["uname"]
        pwd=request.form["pwd"]
        email=request.form["email"]
        sql="insert into userinfo values (%s,%s,%s)"
        try:
            val=(uname,pwd,email) 
            cursor.execute(sql,val)
            con.commit()
            return redirect("/")
        except:
            return redirect("/register")

def login():
    if request.method=="GET":
        return render_template("user/login.html")
    else:
        uname=request.form["uname"]
        pwd=request.form["pwd"]
    
        sql="select count(*) from userinfo where username=%s and password=%s"
        
        val=(uname,pwd) 
        cursor.execute(sql,val)
        count=int(cursor.fetchone()[0])
        if count==1:
            session["uname"]=uname
            return redirect("/")
    
        return redirect("/login")

def logout():
    session.clear()
    return redirect("/")


def showcart():
    if "uname" in session:
        if request.method=="GET":
            sql="select * from cart_vw where username=%s"
            val=(session["uname"],)
            cursor.execute(sql,val)
            items=cursor.fetchall()

            sql="select sum(subtotal) from cart_vw where username=%s"
            cursor.execute(sql,val)
            total=cursor.fetchone()[0]
            session["total"]=total

            return render_template("user/showcart.html",items=items,total=total)


        else:
            return redirect("/login")
    else:
        action=request.form["action"]
        if action=="Edit":
            qty=request.form["qty"]
            sql="update mycart set qty=%s where cart_id=%s"
            val=(qty,cart_id)
            cursor.execute(sql,val)
            con.commit()
        else:
            return redirect("/deleteconfirmation")
            # cart_id=request.form["cart_id"]
            # return render_template("deleteconfirmation",cart_id=cart_id)
            # respone=request.form["response"]
            # if respone=="Yes":
            # cart_id=request.form["cart_id"]
            # sql="delete from my_cart where cart_id=%s"
            # val=(cart_id,)
            # cursor.execute(sql,val)
            # con.commit()
            # return redirect("/showcart")

def deleteconfirmation():
    if request.method=="GET":
        return render_template("deleteconfirmation.html")
    else:
        respone=request.form["response"]
        cart_id=request.form["cart_id"]
        if respone=="Yes":
            sql="delete from my_cart where cart_id=%s"
            val=(cart_id,)
            cursor.execute(sql,val)
            con.commit()
            return redirect("/showcart")
        else:
            return redirect("/showcart")



def makepayment():
    if request.method=="GET":
        return render_template("user/makepayment.html")
    else:
        cardno=request.form["cardno"]
        cvv=request.form["cvv"]
        expiry=request.form["expiry"]
        sql="select count(*) from payment where cardno=%s and cvv=%s and expiry=%s" 
        val=(cardno,cvv,expiry)
        cursor.execute(sql,val)
        count=int(cursor.fetchone()[0])
        # if count==1:
        #     return render_template(









 