from flask import render_template,redirect,request
import mysql.connector 
from werkzeug.utils import secure_filename

def showAllCakes():
    con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="cakeshop")
    cursor = con.cursor()
    sql = "select * from Cake_cat_vw order by cakeId asc"
    cursor.execute(sql)
    cakes = cursor.fetchall()
    return render_template("Cake/showAllCakes.html",cakes=cakes)

def addCake():
    con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="cakeshop")
    cursor = con.cursor()
    if request.method == "GET":
        sql="select * from category"
        cursor.execute(sql)
        cats=cursor.fetchall()
        return render_template("Cake/addCake.html",cats=cats)
    else:
        cname=request.form["cname"]
        price=request.form["price"]
        description=request.form["description"]
        cid=request.form["cat"]
        f=request.files["image_url"]
        filename=secure_filename(f.filename)
        filename="static/Images/"+f.filename

        #this will save the file to the specified location
        f.save(filename)
        filename="Images/"+f.filename

        sql = "insert into cake (cakename,price,description,imageurl,cid) values(%s,%s,%s,%s,%s)"
        val = (cname,price,description,filename,cid)
        cursor.execute(sql,val)
        con.commit()
        return render_template("showAllCakes.html")

def deleteCake(cid):
    if request.method == "GET":
        return render_template("cake/deleteCake.html")
    else:
        action = request.form["action"]
        if action == "Yes":
            con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="cakeshop")
            cursor = con.cursor()
            sql = "delete from cake where cakeId=%s"
            val = (cid,)
            cursor.execute(sql,val)
            con.commit()
        return redirect("/showAllCakes")



def editCake(cid):
    mydb=mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="cakeshop")
    cur=mydb.cursor()
    if request.method=="GET":
        sql="select * from cake where cakeid=%s"
        val=(cid,)
        cur.execute(sql,val)
        record=cur.fetchone()
        return render_template("cake/editCake.html",record=record)
        
    
    else:
        cid=request.form["cid"]
        cname=request.form["cname"]

        sql="update cake set cakename=%s where cid=%s "
        val=(cname,cid)
        cur.execute(sql,val)
        mydb.commit()
        return redirect("/showallrecords")

