from flask import render_template ,redirect,request,session
import mysql.connector


mydb=mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="quiz")
cur=mydb.cursor()

def login():
    if request.method=="GET":
        return render_template("login.html")
    
    else:
        uname=request.form["uname"]
        pwd=request.form["pwd"]
        sql="select * FROM admininfo WHERE username = %s AND password = %s"
        val=(uname,pwd)
        try:
            cur.execute(sql,val)
            admin=cur.fetchone()
        except:
            return redirect("/")
        # admin=str(admin[0])
        else:

        
            if admin:
                session["uname"]=uname
                return redirect("/display")
            else:
                sql="select count(*) from userinfo where username=%s and password=%s"
                val=(uname,pwd)
                cur.execute(sql,val)
                count=cur.fetchone()
                count=int(count[0])
                print(count)
                if count==1:
                    session["uname"]=uname
                    return render_template("userhome.html")
        
        return redirect("/")


def logout():
    
    session.clear()
    return redirect("/")


# def register():
#     if request.method=="GET":
#         return render_template("register.html")
    
#     else:
#         uname=request.form["uname"]
#         pwd=request.form["pwd"]
#         sql="insert into userinfo(username,password) values(%s,%s)"
#         val=(uname,pwd)
#         cur.execute(sql,val)
#         mydb.commit()
#         return redirect("/")
    
# def quiz():
#     if request.method=="GET":
#         return render_template("startquiz.html")

def edit(id):
    if request.method=="GET":
        sql="select * from questions where q_no=%s"
        val=(id,)
        cur.execute(sql,val)
        question=cur.fetchone()
        return render_template("edit.html",question=question)
    else:
        que=request.form["que"]
        A=request.form["A"]
        B=request.form["B"]
        C=request.form["C"]
        D=request.form["D"]
        ans=request.form["ans"]
        sql="update questions set question=%s,option_A=%s,option_B=%s,option_C=%s,option_D=%s,Answer=%s where q_no=%s"
        val=(que,A,B,C,D,ans,id)
        cur.execute(sql,val)
        mydb.commit()
        return redirect("/display")

def delete(id):
    if request.method=="GET":
        return render_template("delete.html")
    else:
        action=request.form["action"]
        if action=="Yes":
            sql="delete from questions where q_no=%s"
            val=(id,)
            cur.execute(sql,val)
            mydb.commit()
            return redirect("/display")
        else:
            return redirect("/display")
        
def addquestion():
    if request.method=="GET":
        return render_template("addquestion.html")
    else:
        que=request.form["que"]
        opt1=request.form["opt1"]
        opt2=request.form["opt2"]
        opt3=request.form["opt3"]
        opt4=request.form["opt4"]
        ans=request.form["ans"]
        sql="insert into questions(question,option_A,option_B,option_C,option_D,answer) values(%s,%s,%s,%s,%s,%s)"
        val=(que,opt1,opt2,opt3,opt4,ans)
        try:
            cur.execute(sql,val)
            mydb.commit()
            return redirect("/display")
        except:
            return redirect("/addquestion")

def display():
    sql="select * from questions"
    cur.execute(sql)
    data=cur.fetchall()
    print(data)
    return render_template("display.html",data=data)
