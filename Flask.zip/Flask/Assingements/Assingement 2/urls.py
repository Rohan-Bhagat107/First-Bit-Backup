
from main import app
import admin as admin
import user as user

app.add_url_rule("/",view_func=admin.login,methods=["GET","POST"])
app.add_url_rule("/logout",view_func=admin.logout)
# app.add_url_rule("/register",view_func=admin.register,methods=["GET","POST"])
# app.add_url_rule("/playquiz",view_func=admin.quiz,methods=["GET","POST"])
app.add_url_rule("/edit/<id>",view_func=admin.edit,methods=["GET","POST"])
app.add_url_rule("/delete/<id>",view_func=admin.delete,methods=["GET","POST"])
app.add_url_rule("/addquestion" ,view_func=admin.addquestion,methods=["GET","POST"])
app.add_url_rule("/display",view_func=admin.display)


app.add_url_rule("/register",view_func=user.register,methods=["GET","POST"])
app.add_url_rule("/playquiz",view_func=user.playquiz,methods=["GET","POST"])
#app.add_url_rule("/logout",view_func=user.logout)
