from flask import Flask,render_template,redirect,request,session,flash
import mysql.connector

mydb=mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="quiz")
cur=mydb.cursor()



def register():
    if request.method=="GET":
        return render_template("register.html")
    
    else:
        uname=request.form["uname"]
        pwd=request.form["pwd"]
        sql="insert into userinfo(username,password) values(%s,%s)"
        val=(uname,pwd)
        cur.execute(sql,val)
        mydb.commit()
        return redirect("/")


def logout():
    session.clear()
    return redirect("/")

def playquiz():

    if request.method=="GET":
        sql = "SELECT * FROM questions"
        cur.execute(sql)
        questions = cur.fetchall()

            
        total_questions = len(questions)


        first_question = questions[0] 

                
        print(first_question)
        print(questions)
        return render_template("quiz.html",questions=questions)
    else:
        score=0
        sql="select q_no from questions"
        cur.execute(sql)
        data=str(cur.fetchall()[0])

        for i in range(1,len(data)+2):
            sql="select answer from questions where q_no=%s"
            val=(i,)
            cur.execute(sql,val)
            ans=str(cur.fetchone()[0])
        
            q="q"+str(i)
            q=request.form["q"+str(i)]

            if q==ans:
                score+=2 
        
        
        return render_template("score.html",score=score)
        
       
        

            

        

# def quiz():
#     if request.method=="GET":
        # sql="select * from questions"
        # cur.execute(sql)
        # questions=cur.fetchall()

#         sql="select count(*) from questions"
#         cur.execute(sql)

#         # total_qustions=int(cur.fetchall()[0])
#         total_qustions=cur.fetchall()
#         quest_1=list(total_qustions[0])
#         print(quest_1)
#         return render_template("startquiz.html") 
#     else:
#         pass

