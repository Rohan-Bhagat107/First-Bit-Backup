from flask import Flask,render_template,redirect,request,session

app=Flask(__name__)
app.secret_key="user"

@app.route("/login",methods=["GET","POST"])
def userlogin():
    if request.method=="GET":
        return render_template("login.html")
    else:
        uname=request.form["uname"]
        pwd=request.form["pwd"]
        if uname=="Firstbit" and pwd=="abc@123":
            session["uname"]=uname
            return redirect("/welcome")
        else:
            return redirect("/login")

@app.route("/welcome")
def userHome():
    if "uname" in session:
        return render_template("welcome.html")
    else:
        return redirect("/login")


def userLogout():
    session.clear()
    return redirect("/login")



if __name__=="__main__":
    app.run(debug=True)