from flask import Flask,render_template,redirect,request

app=Flask(__name__)

@app.route("/quiz",methods=["GET","POST"])
def quiz():
    
    if request.method=="GET":
        return render_template("quiz.html")
    else:
        
        fname=request.form["fname"]
        lname=request.form["lname"]
        ans1=request.form["question1"]
        ans2=request.form["question2"]
        ans3=request.form["question3"]
        ans4=request.form["question4"]
        ans5=request.form["question5"]
        score=0
        if ans1=="Python":
            score+=2
        if ans2=="Guido van Rossum":
            score+=2
        if ans3==".py":
            score+=2
        if ans4=="def":
            score+=2
        if ans5=="#":
            score+=2
        return render_template("score.html",marks=score,fname=fname,lname=lname)



        
        request.form["question2"]
        request.form["question3"]
        request.form["question4"]
        request.form["question5"]

if __name__=="__main__":
    app.run()