from flask import Flask
app = Flask(__name__)
@ app.route("/display")
def demo1():
    return "I am display method"
@ app.route("/hello")
def demo2():
    return "I am hello method"
@ app.route("/visit")
def demo3():
    return"I am visit method"

if __name__ == "__main__":
    app.run()