from flask import Flask,render_template,redirect,request,session




app=Flask(__name__)
app.secret_key="user"

@app.route("/login",methods=["GET","POST"])
# def login():
#     if request.method=="GET":
#         return render_template("login.html")
#     else:
#         uname=request.form["uname"]
#         pwd=request.form["pwd"]
#         if uname=="Firstbit" and pwd=="abc@123":
#             session["uname"]=uname
#             return render_template("userHome.html")
#         else:
#             return redirect("/login")
#         # sql="select count(*) from adminuser where username=%s and password=%s"
#         # val=(uname,pwd)
#         # con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="cakeshop")
#         # cursor = con.cursor()
#         # cursor.execute(sql,val)
#         # count=cursor.fetchone()
#         # count=int(count[0])
#         # if count==1:
#         #     session["uname"]=uname
#         #     return redirect("/adminHome")
#         # else:
#         #     return redirect("/adminlogin")

# def adminHome():
#     #check if user has loged in or not
#     if "uname" in session:
#         return render_template("admin/adminHome.html")
#     else:
#         return redirect("/adminlogin")


# def adminLogout():
#     session.clear()
#     return redirect("/adminlogin")
@app.route("/login",methods=["GET","POST"])
def userlogin():
    if request.method=="GET":
        return render_template("login.html")
    else:
        uname=request.form["uname"]
        pwd=request.form["pwd"]
        if uname=="Firstbit" and pwd=="abc@123":
            session["uname"]=uname
            return redirect("/welcome")
        else:
            return redirect("/login")

@app.route("/welcome")
def userHome():
    if "uname" in session:
        return render_template("welcome.html")
    else:
        return redirect("/login")


def userLogout():
    session.clear()
    return redirect("/login")



if __name__=="__main__":
    app.run(debug=True)