from flask import Flask,redirect,render_template,request
import mysql.connector


def showAllCategory():
    mydb=mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="Flask")
    cur=mydb.cursor()
    sql="select * from category"
    cur.execute(sql)
    records=cur.fetchall()
    return render_template("category/showAllCategory.html",records=records)

def addCategory():
    if request.method == "GET":
        return render_template("Category/addCategory.html")
    else:
        con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="Flask")
        cursor = con.cursor()
        sql = "insert into Category (cname) values (%s)"
        val = (request.form["cname"],)
        cursor.execute(sql,val)
        con.commit()
        return redirect("/showAllCategories")