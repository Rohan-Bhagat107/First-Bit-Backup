import category_op as cat
from flask import url_for
from main import app

app.add_url_rule("/showAllCategory",view_func=cat.showAllCategory)
app.add_url_rule("/addCategory",view_func=cat.addCategory,methods=["GET","POST"])

app.add_url_rule("/",view_func=cat.showAllCategory)
