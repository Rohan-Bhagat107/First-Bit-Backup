# from flask import Flask,render_template
# from datetime import datetime
# app=Flask(__name__)

# @app.route("/first")
# def demo1():
#     return render_template("first.html")

# @app.route("/second")
# def demo2():
#     uname="Rohan Bhagat"
#     return render_template("second.html",user=uname,time=datetime.now())

# @app.route("/third")
# def demo3():
#     data=["Rohan","Kshitij","Prafull"]
#     return render_template("third.html",mydata=data)
# if __name__=="__main__":
#     app.run(debug=True)

from flask import Flask,render_template
from datetime import datetime

app=Flask(__name__)

@app.route("/demo1")
def demo1():
    uname="Rohan Bhagat"
    return render_template("second.html",user=uname)

@app.route("/demo2")
def demo2():
    data=["Rohan","Kshitij","Ishita","Prafull"]
    return render_template("second.html",data=data)

@app.route("/demo3")
def demo3():
    data=[[1,"Rohan",86],[2,"Kshitj",84],[3,"Prafull","75"]]
    return render_template("third.html",data=data)

@app.route("/demo4")
def demo4():
    data={1:"Rohan",2:"Kshitij",3:"Prafull"}
    return render_template("fourth.html",data=data)


if __name__=="__main__":
    app.run(debug=True)