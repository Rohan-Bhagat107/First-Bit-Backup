from flask import Flask,render_template,redirect,request
import mysql.connector

app=Flask(__name__)

@app.route("/showall")
def showall():
    mydb=mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="Flask")
    cursor=mydb.cursor()
    sql="select * from student"
    cursor.execute(sql)
    records=cursor.fetchall()
    return render_template("showall.html",students=records)

@app.route("/addrecord")
def addrecord():
    if request.method=="GET":
        return render_template("addrecord.html")
    else:
        sname=request.form["sname"]
        percentage=request.form["percentage"]
        dob=request.form["dob"]
        mydb=mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="Flask")
        cursor=mydb.cursor()
        sql="insert into student(S_name,Percentage,DOB) values (%s,%s,%s)"
        value=(sname,percentage,dob)
        cursor.execute(sql,value)
        mydb.commit()
        return redirect("/showall")
if __name__=="__main__":
    app.run(debug=True)