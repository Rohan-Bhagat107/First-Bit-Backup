from flask import Flask,render_template,request

app=Flask(__name__)

@app.route("/login")
def demo1():
    return render_template("login.html")

@app.route("/verify")
def verify():
    uname=request.args["uname"]
    pwd=request.args["pwd"]
    if uname=="Rohan" and pwd=="abc@123":
        return "Login Succesfull!"
    else:
        return "Login Faild!"

@app.route("/verify1",methods=["GET","POST"])
def verify1():
    # Fetching data of POST method
    user_name=request.form["uname"]
    password=request.form["pwd"]
    if user_name=="Rohan" and password=="abc@123":
        return "Login Succesfull!"
    else:
        return "Login Faild!"

if __name__=="__main__":
    app.run(debug=True)