from flask import Flask,render_template,redirect,request
import mysql.connector

app=Flask(__name__)

@app.route("/showallrecords")
def showallrecords():
    if request.method=="GET":
        mydb=mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="Flask")
        cur=mydb.cursor()
        sql="select * from student"
        cur.execute(sql)
        records=cur.fetchall()
        return render_template("showall.html",students=records)

@app.route("/addrecord",methods=["GET","POST"])
def addrecord():
    if request.method=="GET":
        return render_template("add_record.html")
    else:
        s_name=request.form["s_name"]
        percentage=request.form["percentage"]
        dob=request.form["dob"]
        mydb=mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="Flask")
        cur=mydb.cursor()
        sql="insert into students(s_name,percentage,dob) values(%s,%s,%s)"
        val=(s_name,percentage,dob)
        cur.execute(sql,val)
        mydb.commit()
        records=cur.fetchall()
        return render_template("showall.html",students=records)

@app.route("/delete/<Roll_no>",methods=["GET","POST"])
def delete_record(Roll_no):
    if request.method=="GET":
        return render_template("delete_confirm.html")
    else:
        action=request.form["action"]
        if action=="Yes":
            mydb=mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="Flask")
            cur=mydb.cursor()
            sql="delete from student where roll_no=%s"
            val=(Roll_no,)
            cur.execute(sql,val)
            
            return redirect("/showallrecords")
        else:
            return redirect("/showallrecords")

@app.route("/edit/<Roll_no>",methods=["GET","POST"])
def editrecord(Roll_no):
    mydb=mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="Flask")
    cur=mydb.cursor()
    if request.method=="GET":
        sql="select * from student where roll_no=%s"
        val=(Roll_no,)
        cur.execute(sql,val)
        student=cur.fetchone()
        return render_template("/edit_student.html",student=student)
        
    
    else:
        s_name=request.form["s_name"]
        percentage=request.form["percentage"]
        dob=request.form["dob"]
        sql="update student set Student_name=%s, Percentage=%s,DOB=%s where roll_no=%s "
        val=(s_name,percentage,dob,Roll_no)
        cur.execute(sql,val)
        mydb.commit()
        return redirect("/showallrecords")
        
        


if __name__=="__main__":
    app.run(debug=True)