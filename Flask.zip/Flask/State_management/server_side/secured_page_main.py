from flask import Flask,render_template,redirect,request,session

app=Flask(__name__)
app.secret_key="rohan"

@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="GET":
        return render_template("login.html")
    
    else:
        uname=request.form["uname"]
        pwd=request.form["pwd"]
        if uname=="Rohan" and pwd=="Abcd@123":
            session["uname"]=uname
            return redirect("/securedurl")
        else:
         return redirect("/login")
        
@app.route("/securedurl")
def securedpage():
    if "uname" in session:
        return render_template("secured_page.html")
    else:
        return redirect("/login")
if __name__=="__main__":
    app.run(debug=True)