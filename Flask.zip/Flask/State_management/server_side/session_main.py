from flask import Flask,render_template,redirect,request,session

app=Flask(__name__)
app.secret_key="Rohan Bhagat"

@app.route("/sessiondemo",methods=["GET","POST"])
def sessiondemo():
    if request.method=="GET":
        return render_template("session_demo.html")
    else:
        fname=request.form["fname"]
        lname=request.form["lname"]
        session["uname"]=fname+" "+lname
        return "Session created"

@app.route("/session_display")
def displaysession():
    return render_template("session_display.html")


if __name__=="__main__":
    app.run(debug=True)