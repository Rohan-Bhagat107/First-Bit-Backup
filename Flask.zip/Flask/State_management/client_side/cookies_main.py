from flask import Flask,render_template,redirect,request,make_response

app=Flask(__name__)



@app.route("/cookiedemo",methods=["GET","POST"])
def cookiedemo():
    
    if request.method=="GET":
        return render_template("cookiedemo.html")
    else:
        fname=request.form["fname"]
        lname=request.form["lname"]
        # Give me reference of response object
        resp=make_response("Cookie Created")
        # Embed the cookie inside response object
        resp.set_cookie("fname",fname)
        resp.set_cookie("lname",lname)
        return resp

@app.route("/cookiedisplay")
def displaycookie():
    fname=request.cookies.get("fname","Not set")
    lname=request.cookies.get("lname","Not set")
    return fname+" "+lname
if __name__=="__main__":
    app.run(debug=True)
