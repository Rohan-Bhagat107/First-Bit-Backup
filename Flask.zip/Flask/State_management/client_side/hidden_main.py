from flask import Flask ,render_template,redirect,request

app=Flask(__name__)

@app.route("/hidden",methods=["GET","POST"])
def hiddendemo():
    if request.method=="GET":
        return render_template("hidden.html")
    else: 
        fname=request.form["fname"]
        lname=request.form["lname"]
        item=request.form["items"]
        myitem=request.form["myitems"]
        items=myitem+" "+item
        uname=fname+" "+lname
        return render_template("hidden.html",uname=uname,item=items)
    

if __name__=="__main__":
    app.run(debug=True)