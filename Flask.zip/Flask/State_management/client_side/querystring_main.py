from flask import Flask,render_template,redirect,request

app=Flask(__name__)

@app.route("/querystring",methods=["GET","POST"])
def query():
    if request.method=="GET":
        return render_template("querydemo.html")
    else:
        fname=request.form["fname"]
        lname=request.form["lname"]
        url="/itemselection?fname="+fname+"&lname="+lname
        return redirect(url)

@app.route("/itemselection",methods=["GET","POST"])
def itemselection():
    if request.method=="GET":
        fname=request.args["fname"]
        lname=request.args["lname"]
        return render_template("items.html",fname=fname,lname=lname)
    else:
        items=request.form["item"]
        url="/finalpage?fname="+fname+"&lname"+lname+"&items="+items
        return redirect(url)
@app.route("/finalpage")
def finalpage():
        fname=request.args["fname"]
        lname=request.args["lname"]
        items=request.args["items"]
        return render_template("final.html",fname=fname,lname=lname,items=items)


if __name__=="__main__":
    app.run(debug=True)