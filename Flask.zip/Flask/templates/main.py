from flask import Flask,render_template
from datetime import datetime

app = Flask(__name__)

@app.route("/first")
def first():
    return render_template("first.html")

@app.route("/second")
def second():
    uname = "Rohan Bhagat"
    mydate = datetime.now()
    return render_template("second.html",user = uname,mydate=mydate )

@app.route("/third")
def third():
    data = ["Geeta","Rohan","Praphul","Ketan","Ishita","Barsha"]
    return render_template("third.html",data=data)

@app.route("/fourth")
def fourth():
    data = [[101,"Geeta",67],[102,"Rohan",77],[103,"Praphul",65],[104,"Ketan",87]]
    return render_template("fourth.html",data=data)

@app.route("/fifth")
def fifth():
    data = {101:"Geeta",102:"Rohan",103:"Praphul",104:"Ketan",105:"Ishita",106:"Barsha"}
    return render_template("fifth.html",data=data)

if __name__ == "__main__":
    app.run(debug=True)