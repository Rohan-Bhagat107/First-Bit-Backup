from main import app
import admin as ad

app.add_url_rule("/addBook",view_func=ad.addBook,methods=["GET","POST"])
app.add_url_rule("/showAllBooks",view_func=ad.showAllBooks)
app.add_url_rule("/editBook/<bid>",view_func=ad.editBook,methods=["GET","POST"])
app.add_url_rule("/deleteBook/<bid>",view_func=ad.deleteBook,methods=["GET","POST"])
app.add_url_rule("/searchById",view_func=ad.searchById,methods=["GET","POST"])
app.add_url_rule("/searchByName",view_func=ad.searchByName,methods=["GET","POST"])
