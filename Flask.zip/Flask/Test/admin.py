from flask import render_template ,redirect,request,session
import mysql.connector


con = mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="flaskTest")
cursor = con.cursor()
def addBook():
    if request.method=="GET":
        return render_template("addBook.html")
    
    else:
        bname=request.form["bname"]
        price=request.form["price"]
        author=request.form["author"]
        sql="insert into book(bname,price,author) values(%s,%s,%s)"
        val=(bname,price,author)
        cursor.execute(sql,val)
        con.commit()
        return "Book Added"
def showAllBooks():
        sql="select * from book"
        cursor.execute(sql,)
        books=cursor.fetchall()
        print(books)
        return render_template("showAllBooks.html",books=books)
def editBook(bid):
    if request.method=="GET":
        sql="select * from book where bid=%s"
        val=(bid,)
        cursor.execute(sql,val)
        book=cursor.fetchone()
        
        return render_template("editBook.html",book=book)
    else:
        bname=request.form["bname"]
        price=request.form["price"]
        author=request.form["author"]
        sql="update book set bname=%s,price=%s,author=%s where bid=%s"
        val=(bname,price,author,bid)
        cursor.execute(sql,val)
        con.commit()
        return redirect("/showAllBooks")
def deleteBook(bid):
    if request.method=="GET":

        return render_template("deleteConfirm.html")
    else:
        action=request.form["action"] 
        if action=="Yes":
            sql="delete from book where bid=%s"
            val=(bid,)
            cursor.execute(sql,val)
            con.commit()
            return redirect("/showAllBooks")
        else:
            return redirect("/showAllBooks")

def searchById():
    if request.method=="GET":
        return render_template("searchById.html")
    else:
        bid=request.form["bid"]
        sql="select count(*) from book where bid=%s"
        val=(bid,)
        cursor.execute(sql,val)
        count=cursor.fetchone()[0]
        if count==1:
            return "Book Found"
        else:
            return "No Book is there with this ID"

def searchByName():
    if request.method=="GET":
        return render_template("searchByName.html")
    else:
        bname=request.form["bname"]
        sql="select count(*) from book where bname=%s"
        val=(bname,)
        cursor.execute(sql,val)
        count=cursor.fetchone()[0]
        if count==1:
            return "Book Found"
        else:
            return "No Book is there with this Name"