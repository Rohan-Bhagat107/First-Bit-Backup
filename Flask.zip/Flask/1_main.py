# from flask import Flask

# app = Flask(__name__)

# @app.route("/display")
# def demo1():
#     return "I am display method"

# @app.route("/hello")
# def demo2():
#     return "I am hello method"

# @app.route("/visit")
# def demo3():
#     return "I am visit method"


# if __name__ == "__main__":
#     #It starts the flask server
#     app.run()

from flask import Flask
app=Flask(__name__)

@app.route("/demo1")
def demo1():
    return("I am display method ")

@app.route("/demo2")
def demo2():
    return("I am Hello method")

@app.route("/demo3")
def demo3():
    return("I am Visit method")

if __name__=="__main__":
    app.run(debug=True)