from flask import Flask

app=Flask(__name__)
def login():
    return render_template("login.html")
    