from flask import Flask,render_template,request,redirect,session,make_response
import mysql.connector


app=Flask(__name__)
app.secret_key="user"

@app.route("/register",methods=["GET","POST"])
def register():
    if request.method=="GET":
        return render_template("1_register.html")
    
    else:
        try:
            uname=request.form["uname"]
            pwd=request.form["pwd"]
            email=request.form["email"]
            mydb=mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="Flask")
            cur=mydb.cursor()
            sql="insert into user_info values (%s,%s,%s)"
            val=(uname,pwd,email)
            cur.execute(sql,val)
            mydb.commit()
        except:
            return "This username is alrady exists"
        else:
            return redirect("/login")


@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="GET":
        return render_template("2_login.html")
    else:
        
        uname=request.form["uname"]
        pwd=request.form["pwd"]
        result=request.form["result"]
        
        mydb=mysql.connector.connect(host="localhost",username="root",password="Pass@123",database="Flask")
        cur=mydb.cursor()
        sql="select count(*) from user_info where user_name=%s and password=%s"
        val=(uname,pwd)
        cur.execute(sql,val)
        count=cur.fetchone()  # IT returns a tuple
        count=int(count[0]) # therefore we extract first column value
        if count==1:
            session["uname"]=uname

            return render_template("3_welcome.html")
        else:
            return redirect("/login")

@app.route("/logout")
def logout():
    return redirect("/login")
if __name__=="__main__":
    app.run(debug=True)