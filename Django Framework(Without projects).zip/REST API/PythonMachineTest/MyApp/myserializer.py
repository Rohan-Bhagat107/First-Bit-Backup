from rest_framework import serializers
from .models import User, Client, Project

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ("id","username")

class ClientSerializer(serializers.ModelSerializer):
    created_by = serializers.StringRelatedField(read_only=True)

    class Meta:
        model = Client
        fields = "__all__"

class ProjectSerializer(serializers.ModelSerializer):
    client = serializers.StringRelatedField(read_only=True)
    users = UserSerializer(many=True, read_only=True)

    class Meta:
        model = Project
        fields = "__all__"
        
class CreateProjectSerializer(serializers.ModelSerializer):
    users = serializers.ListField(
        child=serializers.IntegerField(), write_only=True
    )  

    class Meta:
        model = Project
        fields = "__all__"

    def create(self, validated_data):
        users = validated_data.pop('users')
        project = Project.objects.create(**validated_data)
        project.users.set(users)
        return project


# ProjectSerializer: Converts the Project model into a JSON-compatible format.
# client: Shows the string representation of the client (e.g., "ABC Corp.") instead of its ID.
# users: A nested serializer (UserSerializer) to show detailed information about all users linked to the project.



# CreateProjectSerializer: A serializer specifically designed for creating projects.
# users: A custom field where you pass a list of user IDs (e.g., [1, 2, 3]) when creating a project.
# ListField: Accepts multiple values (IDs in this case).
# child=serializers.IntegerField(): Ensures each value in the list is an integer (representing user IDs).
# write_only=True: This field is only used for input; it won't appear in the output.