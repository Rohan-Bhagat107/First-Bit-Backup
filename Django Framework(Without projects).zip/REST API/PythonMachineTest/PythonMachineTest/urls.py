from django.contrib import admin
from django.urls import path,include
from MyApp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    #User API
    path('users/', views.UserListView.as_view(), name='user-list-create'),

    # Client APIs
    path('GET/clients/', views.All_Clients.as_view(), name='clients-list'),

    path('POST/clients/', views.Add_clients.as_view(), name='new_client'),

    path('GET/clients/:<cid>/', views.Single_client.as_view(), name='specific_client'),

    path('PUT-PATCH/clients/:<cid>/', views.Update_client.as_view(), name='update_client-details'),

    path('DELETE/clients/:<cid>', views.Delete_client.as_view(), name='delete_client'),



    # Project APIs
    path('GET/projects/', views.All_projects.as_view(), name='project-list'),
    path('POST/projects/', views.New_project.as_view(), name='add_project'),
    path('DELETE/projects/:<pid>/', views.Delete_project.as_view(), name='delete_project'),

    
    # Projects assigned to logged-in user
    path('user/projects/:<uid>', views.User_Assigned_ProjectsView.as_view(), name='user-projects'),
    
]
