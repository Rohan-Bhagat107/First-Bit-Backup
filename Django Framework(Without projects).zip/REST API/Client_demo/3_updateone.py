import requests

BASE="http://127.0.0.1:8000/"
response=requests.put(BASE+"prd_op/2",
{'id': 2, 'pname': 'White Notebooks', 'price': 65.0, 'quantity': 12})
print(response.json())