import requests

BASE="http://127.0.0.1:12021/"
response=requests.get(BASE+"prds/")
print(response.json())