import requests

BASE="http://127.0.0.1.8000/"
response=requests.get(BASE+"prds/",json={"id":2,"pname":Book,"price":75.0,"quantity":3})
print(response.json())

