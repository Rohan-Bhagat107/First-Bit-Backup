
from django.contrib import admin
from django.urls import path,include
from MyApp import views
urlpatterns = [
    path('admin/', admin.site.urls),
    path("accounts/",include("django.contrib.auth.urls")),
    path('clients/', views.showClients.as_view()),
    path('clients/<cid>', views.ClientOp.as_view()),
    path('projects/', views.showProjects.as_view()),
    path('projects/<pid>', views.ProjectOp.as_view()),
]
