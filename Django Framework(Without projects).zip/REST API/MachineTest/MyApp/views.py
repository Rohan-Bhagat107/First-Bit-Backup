
from django.shortcuts import render
from .models import *
from .myserializer import *
from django.shortcuts import get_object_or_404
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
# Create your views here.

class showClients(APIView):
    def get(self,request):    # To fetch data
        #select * from product
        prds=Client.objects.all() #gets the data in binary format
        serializer=ClientSerializer(prds,many=True) # converts binary data into text format(JSON)
        return Response(serializer.data)
    
    def post(self,request):      # To add record
        serializer=ClientSerializer(data=request.data) #fetch the data and create object

        if (serializer.is_valid()):
            # store data into database
            serializer.save()
            return Response(serializer.data,status=status.HTTP_201_CREATED)

        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)

class ClientOp(APIView): 
    def get(self,request,cid):
        myclient=Client.objects.get(id=cid)  
        serialize=ClientSerializer(myclient)
        return Response(serialize.data)
    def delete(self,request,cid):
        try:
            myclient=Client.objects.get(id=cid)
            myclient.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
        except:
            return Response(status=status.HTTP_404_NOT_FOUND)
    def put(self,request,cid):
        try:
            #prd is the original data
            myclient=Client.objects.get(id=cid)
            #request.data is the modified data
            serializer=ClientSerializer(myclient,request.data)
            if (serializer.is_valid()):
                serializer.save()
            return Response(serializer.data())
        except:
            return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)

class showProjects(APIView):
    def get(self,request):    # To fetch data
        #select * from product
        prj=Project.objects.all() #gets the data in binary format
        serializer=ProjectSerializer(prj,many=True) # converts binary data into text format(JSON)
        return Response(serializer.data)
    
    def post(self,request):      # To add record
        serializer=ProjectSerializer(data=request.data) #fetch the data and create object

        if (serializer.is_valid()):
            # store data into database
            serializer.save()
            return Response(serializer.data,status=status.HTTP_201_CREATED)

        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)

class ProjectOp(APIView): 
    def get(self,request,pid):
        myproject=Project.objects.get(id=pid)  
        serialize=ProjectSerializer(myproject)
        return Response(serialize.data)
    def delete(self,request,pid):
        try:
            myproject=Project.objects.get(id=pid)
            myproject.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
        except:
            return Response(status=status.HTTP_404_NOT_FOUND)
    def put(self,request,pid):
        try:
            #prd is the original data
            myproject=Project.objects.get(id=pid)
            #request.data is the modified data
            serializer=ProjectSerializer(myproject,request.data)
            if (serializer.is_valid()):
                serializer.save()
            return Response(serializer.data())
        except:
            return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)

