from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Client(models.Model):
    client_name=models.CharField(max_length=200)
    created_at=models.DateTimeField(auto_now_add=True)
    created_by=models.CharField(max_length=200)

    class Meta:
        db_table="Client"
    def __str__(self):
        return self.client_name

# class User(models.Model):
#     user_name=models.CharField(max_length=200)
    
#     class Meta:
#         db_table="User"
#     def __str__(self):
#         return self.user_name

class Project(models.Model):
    project_name=models.CharField(max_length=500)
    client_name=models.ForeignKey(Client,on_delete=models.CASCADE)
    user_name=models.ForeignKey(User,on_delete=models.CASCADE)
    created_at=models.DateTimeField(auto_now_add=True)
    created_by=models.CharField(max_length=200)

    class Meta:
        db_table="Projects"
    def __str__(self):
        return self.project_name