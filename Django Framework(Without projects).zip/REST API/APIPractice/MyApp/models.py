from django.db import models

# Create your models here.
class Student(models.Model):
    Name=models.CharField(max_length=35)
    Age=models.IntegerField(default=18)
    Gender=models.CharField(max_length=6)

    class Meta:
        db_table="Student"
    def __str__(self):
       return self.Name
