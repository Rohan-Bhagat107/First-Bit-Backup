from django.shortcuts import render
from rest_framework import status
from rest_framework.views  import APIView
from rest_framework.response  import Response
from .models import Student
from .myserializer import StudentSerializer
from django.shortcuts import get_object_or_404



# Create your views here.
class StudentList(APIView):
    def get(self,request):
        studs=Student.objects.all()
        serialize=StudentSerializer(studs,many=True)
        return Response(serialize.data)
    def post(self,request):
        serializer=StudentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=status.HTTP_201_CREATED)
        else:
            return Response(status=status.HTTP_406_NOT_ACCEPTABLE)

class Student_op(APIView):
    def get(self,request,id):
        stud=Student.objects.get(id=id)
        serializer=StudentSerializer(stud)
        return Response(serializer.data)
    def delete(self,request,id):
        try:
            stud=Student.objects.get(id=id)
            stud.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
        except:
            return Response(status=status.HTTP_404_NOT_FOUND)
    def put(self,request,id):
        try:
            stud=Student.objects.get(id=id)
            serializer=StudentSerializer(stud,data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
        except:
            return Response(status=status.HTTP_404_NOT_FOUND)
        