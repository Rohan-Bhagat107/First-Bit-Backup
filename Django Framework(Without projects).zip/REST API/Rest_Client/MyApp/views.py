from django.shortcuts import render
import requests
BASE="https://127.0.0.1:8000/"
# Create your views here.
def showProducts(request):
    response=requests.get(BASE+"prds")
    prds=response.json()
    return render(request,"showprds.html",{"data":prds})