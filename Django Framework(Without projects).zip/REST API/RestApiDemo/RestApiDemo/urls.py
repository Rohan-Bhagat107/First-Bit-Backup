
from django.contrib import admin
from django.urls import path
from MyApp import views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('prds/', views.ProductList.as_view()),# This url is valid only for get,post(ie to read ,add the data respectively
    path('prd_op/<pid>', views.ProductOp.as_view()),# This url is valid only for put,delete (ie to edit ,delete the  particular data respectively()

]
