from django.shortcuts import render
from .models import Product
from .myserializer import ProductSerializer
from django.shortcuts import get_object_or_404
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
# Create your views here.

class ProductList(APIView):
    def get(self,request):    # To fetch data
        #select * from product
        prds=Product.objects.all() #gets the data in binary format
        serializer=ProductSerializer(prds,many=True) # converts binary data into text format(JSON)
        return Response(serializer.data)
    
    def post(self,request):      # To add record
        serializer=ProductSerializer(data=request.data) #fetch the data and create object

        if (serializer.is_valid()):
            # store data into database
            serializer.save()
            return Response(serializer.data,status=status.HTTP_201_CREATED)

        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)

# for edit and delete operation
class ProductOp(APIView): 
    def get(self,request,pid):
        prd=Product.objects.get(id=pid)  
        serialize=ProductSerializer(prd)
        return Response(serialize.data)
    def delete(self,request,pid):
        try:
            prd=Product.objects.get(id=pid)
            prd.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
        except:
            return Response(status=status.HTTP_404_NOT_FOUND)
    def put(self,request,pid):
        try:
            #prd is the original data
            prd=Product.objects.get(id=pid)
            #request.data is the modified data
            serializer=ProductSerializer(prd,request.data)
            if (serializer.is_valid()):
                serializer.save()
            return Response(serializer.data())
        except:
            return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)

        
            

