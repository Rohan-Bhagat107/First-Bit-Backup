from django.db import models

# Create your models here.
class Product(models.Model):
    pname=models.CharField(max_length=15)
    price=models.FloatField(default=60)
    quantity=models.IntegerField(default=3)
    class Meta:
        db_table="Product"