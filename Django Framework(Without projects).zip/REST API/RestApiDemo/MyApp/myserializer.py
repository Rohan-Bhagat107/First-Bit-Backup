from rest_framework import serializers
from .models import Product

# This class will serialize the information in JSON format
class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model=Product
        fields="__all__"
        