from django.db import models

# Create your models here.
class Product(models.Model):
    p_name=models.CharField(max_length=20,null=True,blank=True)
    price=models.IntegerField(default=50,null=True,blank=True)
    quantity=models.IntegerField(default=5,null=True,blank=True)
    class Meta():
        db_table="Product"
    def __str__(self):
        return self.p_name