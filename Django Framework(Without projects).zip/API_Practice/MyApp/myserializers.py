from rest_framework import serializers
from MyApp.models import *

class ProductSerializer(serializers.ModelSerializer):
    class Meta():
        model=Product
        fields="__all__"