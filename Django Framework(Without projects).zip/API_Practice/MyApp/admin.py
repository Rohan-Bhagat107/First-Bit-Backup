from django.contrib import admin
from .models import Product
# Register your models here.
class ProdcutAdmin(admin.ModelAdmin):
    list_display=["p_name","price","quantity"]

admin.site.register(Product,ProdcutAdmin)