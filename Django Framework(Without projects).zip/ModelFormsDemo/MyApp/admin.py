from django.contrib import admin
from MyApp.models import Student
# Register your models here.
class StudentAdmin(admin.ModelAdmin):
    list_display=["sname","age","percentage","location"]

admin.site.register(Student,StudentAdmin)