from django.shortcuts import render
from django.http import HttpResponse
from .forms import StudentForm
# Create your views here.
def addStudent(request):
    if request.method=="GET":
        s1=StudentForm()
        return render(request,"addStudent.html",{"s1":s1})
    else:
        s1=StudentForm(request.POST)
        s1.save()
        return HttpResponse("Record Added") 