from django.db import models

# Create your models here.
class Student(models.Model):
    sname=models.CharField(max_length=20)
    age=models.IntegerField(default=18)
    percentage=models.FloatField(default=35)
    email=models.CharField(max_length=25)

    class Meta:
        db_table="Student"
    def __str__(self):
        return self.sname