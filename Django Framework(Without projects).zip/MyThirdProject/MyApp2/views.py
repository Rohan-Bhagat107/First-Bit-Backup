from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def helloSecond(request):
    return HttpResponse("I am second Hello from second app")