from django.urls import path
from . import views

urlpatterns = [
    path("helloSecond",views.helloSecond)   
]
