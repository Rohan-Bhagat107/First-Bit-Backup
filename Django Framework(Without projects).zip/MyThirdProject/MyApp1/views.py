from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def helloFirst(request):
    return HttpResponse("I am hello from first app ")

def login(request):
    if request.method=="GET":
        return render(request,"login.html",{})
    
def verify(request):
        uname=request.POST["uname"]
        pwd=request.POST["pwd"]
        if uname=="Rohan" and pwd=="Rohan123":
            return HttpResponse("Login Succesfull")
        else:
            return HttpResponse("Login Failed")

def Display(request):
    data=["Rohan","Geeta","Ketan","Kshitij","Prafull"]
    return render(request,"display.html",{"data":data})

def displayinfo(request):
    data={101:["Rohan",98,"Buldhana"],
    102:["Kshitij",86,"Amravati"],
    103:["Prafull",80,"Nagar"]}
    return render(request,"displayinfo.html",{"data":data})