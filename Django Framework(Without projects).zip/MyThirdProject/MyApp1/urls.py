from django.urls import path
from . import views

urlpatterns = [
    path("helloFirst",views.helloFirst),
    path("login",views.login),
    path("verify",views.verify),
    path("display",views.Display),
    path("displayinfo",views.displayinfo)

]
