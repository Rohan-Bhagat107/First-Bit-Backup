from django.db import models

# Create your models here.
class Students(models.Model):
    sname=models.CharField(max_length=20)
    percentage=models.FloatField(default=35)
    Age=models.IntegerField(default=18)
    City=models.CharField(max_length=20)

    class Meta():
        db_table="Students"
    def __str__(self):
        return f"Name: {self.sname}"
    
