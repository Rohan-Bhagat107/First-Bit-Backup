from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import *
# Create your views here.

def login(request):
    if request.method=="GET":
        return render(request,"login.html",{})

def verify(request):
    if request.method=="POST":
        uname=request.POST["uname"]
        pwd=request.POST["pwd"]
        if uname=="Rohan" and pwd=="Rohan101":
            return HttpResponse("Login Successfull!")
        else:
           return redirect(login)

def addStudents(request):
    if request.method=="GET":
        return render(request, "AddStudent.html",{})
    else:
        sname=request.POST["sname"]
        percentage=request.POST["spercentage"]
        age=request.POST["sage"]
        city=request.POST["slocation"]
        s1=Students(sname=sname,percentage=percentage,Age=age, City=city)
        s1.save()
        return HttpResponse(displayAllStudents)

def displayAllStudents(request):
    if request.method=="GET":
        allstudents=Students.objects.all()
        return render(request, "AllStudents.html",{"AllStudents":allstudents})
def editStudent(request,id):
    if request.method=="GET":
        # sid=request.GET["id"]
        s1=Students.objects.get(id=id)
        return render(request,"editstudent.html",{"s1":s1})
    else:
        sname=request.POST["sname"]
        percentage=request.POST["spercentage"]
        age=request.POST["sage"]
        city=request.POST["scity"]
        s1=Students.objects.get(id=id)
        s1.name=sname
        s1.percentage=percentage
        s1.Age=age
        s1.City=city
        s1.save()
        return redirect(displayAllStudents) 
def deleteStudent(request,id):
    if request.method=="GET":
        s1=Students.objects.get(id=id)
        s1.delete()
        return redirect(displayAllStudents)