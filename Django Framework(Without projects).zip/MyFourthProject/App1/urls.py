from django.urls import path
from . import views

urlpatterns=[
    path("login",views.login),
    path("verify",views.verify),
    path("addstudent",views.addStudents),
    path("allstudents",views.displayAllStudents),
    path("edit/<id>",views.editStudent),
    path("delete/<id>",views.deleteStudent)

]
