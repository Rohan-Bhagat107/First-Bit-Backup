from django.shortcuts import render,redirect
from django.http import HttpResponse

from MyApp.models import Student,Employee

# Create your views here.
def addStudent(request):
    if request.method=="GET":
        return render(request,"add_student.html",{})
    else:
        sname=request.POST["sname"] 
        age=request.POST["age"]
        percentage=request.POST["percentage"]
        location=request.POST["location"]
        s1=Student(Name=sname,age=age,Percentage=percentage,Location=location)
        s1.save()
        return redirect(displayAllStudents)

def displayAllStudents(request):
    if request.method=="GET":
        Students=Student.objects.all()
        return render(request,"displayStudents.html",{"Students":Students})
def editStudent(request,sid):
    stud=Student.objects.get(id=sid)
    if request.method=="GET":
        
        return render(request,"editStudent.html",{"stud":stud})
    else:
        sname=request.POST["sname"]
        age=request.POST["age"]
        percentage=request.POST["percentage"]
        location=request.POST["location"]
        
        stud.Name=sname
        stud.Age=age
        stud.Percentage=percentage
        stud.Location=location
        stud.save()
        return redirect(displayAllStudents)


def deleteStudent(request,sid):
    if request.method=="GET":
        return render(request,"deleteConfirm.html")
    else:
        result=request.POST["action"]
        if result=="Yes":
            s1=Student.objects.get(id=sid)
            s1.delete()
        return redirect(displayAllStudents)

def addEmployee(request):
    if request.method=="GET":
        return render(request,"addEmployee.html")
    else:
        ename=request.POST["ename"]
        age=request.POST["age"]
        salary=request.POST["salary"]
        designation=request.POST["designation"]
        e1=Employee(ename=ename,age=age,salary=salary,designation=designation)
        e1.save()
        return "Record Added"
        # return redirect("displayAllEmployee")