from . import views
from django.urls import path

urlpatterns = [
    path('addstudent', views.addStudent),
    path("displayAllStudents",views.displayAllStudents),
    path("editStudent/<sid>",views.editStudent),
    path("deleteStudent/<sid>",views.deleteStudent),
    path("addEmployee",views.addEmployee),
]