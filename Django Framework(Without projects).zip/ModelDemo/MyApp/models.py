from django.db import models

# Create your models here.
class Student(models.Model):
    Name=models.CharField(max_length=20)
    age=models.IntegerField(default=18)
    Percentage=models.FloatField(default=60)
    Location=models.CharField(max_length=30)
      
    class Meta:
        db_table="Student"
    # class __str__(self):
    #     return f"Name:{self.Name}" 
    
class Employee(models.Model):
    ename=models.CharField(max_length=20)
    age=models.IntegerField(default=18)
    salary=models.IntegerField(default=35000)
    designation=models.CharField(max_length=20)

    class Meta:
        db_table="Employee"
    
    def __str__(self):
        return f"Name:{self.ename}"
    

