from django.shortcuts import render
from .forms import StudentForm
from MyApp.models import Student
# Create your views here.
def addStudent(request):
    if request.method=="GET":
        s1=StudentForm()
        return render(request,"addStudent.html",{"s1":s1})
    
    else:
        pass