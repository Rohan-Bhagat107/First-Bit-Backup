from django.shortcuts import render,redirect
from django.http import HttpResponse
from MyApp1.models import Student
# Create your views here.
def addStudent(request):
    if request.method=="GET":
        return render(request,"addStudent.html")
    else:
        sname=request.POST["sname"]
        age=request.POST["age"]
        percentage=request.POST["percentage"]
        location=request.POST["location"]
        s1=Student(sname=sname,age=age,percentage=percentage,location=location)
        s1.save()
        return HttpResponse("Done")

def displayAllStudents(request):
    if request.method=="GET":
        s1=Student.objects.all()
        return render(request,"viewStudents.html",{"Students":s1})

def deleteStudent(request,sid):
    if request.method=="GET":
        s1=Student.objects.get(id=sid)
        s1.delete()
        return redirect(viewStudents)

def editStudent(request,sid):
    if request.method=="GET":
        s1=Student.objects.get(id=sid)
        return render(request,"editStudent.html",{"student":s1})