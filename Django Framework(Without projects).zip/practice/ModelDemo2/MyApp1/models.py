from django.db import models

# Create your models here.
class Student(models.Model):
    sname=models.CharField(max_length=25)
    age=models.IntegerField(default=20)
    percentage=models.FloatField(default=60)
    location=models.CharField(max_length=35,default="Pune")

    class Meta:
        db_table="Student"
    def __str__(self):
        return self.sname