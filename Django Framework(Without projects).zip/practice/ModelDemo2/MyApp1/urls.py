from django.urls import path
from . import views

urlpatterns = [
    path('addStudent',views.addStudent),
    path('viewStudents',views.displayAllStudents),
    path('editStudent/<sid>',views.displayAllStudents),
    path('deleteStudent/<sid>',views.displayAllStudents),
    
]