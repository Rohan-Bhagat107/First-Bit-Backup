from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def hello(request):
    return HttpResponse("Hello")

def logout(request):
    return HttpResponse("Logout")

def login(request):
    return HttpResponse("Login")