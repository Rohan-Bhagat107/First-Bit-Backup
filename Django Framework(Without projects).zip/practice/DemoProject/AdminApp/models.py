from django.db import models

# Create your models here.
class Product(models.Model):
    name=models.CharField(max_length=25),
    price=models.IntegerField(default=150),
    quantity=models.IntegerField(default=1)

    class Meta:
        db_table="Product"
    def __str__(self):
        return self.name
