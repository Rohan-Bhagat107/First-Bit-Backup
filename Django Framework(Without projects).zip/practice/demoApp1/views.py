from django.shortcuts import render,redirect
from django.http import HttpResponse

def demo1(request):
    return HttpResponse("Succesfull")

# Create your views here.
