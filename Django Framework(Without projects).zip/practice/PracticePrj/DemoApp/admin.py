from django.contrib import admin
from DemoApp.models import Product

class ProductAdmin(admin.ModelAdmin):
    list_display=("pname","price")
admin.site.register(Product,ProductAdmin)

# Register your models here.
