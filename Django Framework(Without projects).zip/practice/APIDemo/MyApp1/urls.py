from django.contrib import admin
from django.urls import path
from MyApp1 import views
urlpatterns = [
    path('prds/', views.ProductList.as_view()),
    path('prd_op/<id>', views.ProductOp.as_view()),
]
