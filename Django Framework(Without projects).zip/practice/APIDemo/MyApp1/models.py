from django.db import models

# Create your models here.
class Product(models.Model):
    Name=models.CharField(max_length=25)
    Price=models.FloatField(default=50)
    Quantity=models.IntegerField(default=2)

    class Meta:
        db_table="Product"
    
