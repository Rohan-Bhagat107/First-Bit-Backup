from django.shortcuts import render
from .models import Product
from .myserializer import ProductSerializer
from django.shortcuts import get_object_or_404
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
# Create your views here.

class ProductOp(APIView):
    def get(self,request,id):
        prd=Product.objects.get(id=id)
        serialize=ProductSerializer(prd)
        return Response(serialize.data)
        
    def delete(self,request,id):
        prd=Product.objects.get(id=id)
        prd.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
    def put(self,request,id):
        ##prd is the original data
       try:
        prd=Product.objects.get(id=id)
        serialize=ProductSerializer(prd,data=request.data)
        if serialize.is_valid():
            serialize.save()
        return Response(serialize.data)
       except:
           return Response(serialize.data,status=status.HTTP_404_NOT_FOUND)
        
class ProductList(APIView):
    def get(self,request):
        prds=Product.objects.all()
        serializers=ProductSerializer(prds,many=True)
        return Response(serializers.data)
    def post(self,request):
        serializer=ProductSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=status.HTTP_201_CREATED)
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)

