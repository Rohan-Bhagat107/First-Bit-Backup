from django.contrib import admin
from MyApp1.models import Product
# Register your models here.
class ProductAdmin(admin.ModelAdmin):
    list_display=["Name","Price","Quantity"]

admin.site.register(Product,ProductAdmin)