import numpy as np

data=[8,6,7,5,6]
mean=np.mean(data)
print(mean)
