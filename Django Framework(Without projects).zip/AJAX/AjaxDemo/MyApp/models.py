from django.db import models

# Create your models here.
class Product(models.Model):
    pname=models.CharField(max_length=15)
    price=models.IntegerField(default=30)
    qty=models.IntegerField(default=2)
    class Meta:
        db_table="Product"
