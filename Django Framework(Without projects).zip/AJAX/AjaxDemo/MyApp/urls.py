from django.urls import path
from . import views

urlpatterns = [
    path('demo1', views.Demo1),
    path('showResult/', views.showResult),
    path('addProduct/', views.addProduct),
    path('saveProduct/', views.saveProduct),
]
