from django.db import models

# Create your models here.
class Feedback(models.Model):
    name=models.CharField(max_length=35)
    email=models.EmailField(max_length=30,unique=True)
    message=models.TextField()

    class Meta:
        db_table="Feedback"
    def __str__(self):
        return self.name