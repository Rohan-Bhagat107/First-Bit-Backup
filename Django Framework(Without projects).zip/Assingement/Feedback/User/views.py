from django.shortcuts import render
from django.http import HttpResponse
from .forms import FeedbackForm
from User.models import *
# Create your views here.
def displayForm(request):
    if request.method=="GET":
        F1=FeedbackForm()
        return render(request,"feedback_form.html",{"F1":F1,})
    else:
        data=FeedbackForm(request.POST)
        data.save()
        return HttpResponse("Thank You for your response !\nForm Submitted")

def viewFeedbacks(request):
    if request.method=="GET":
        data=Feedback.objects.all()
        records=[]
        for i in data:
            records.append(i)
        
        return render(request,"viewFeedbacks.html",{"records":records})