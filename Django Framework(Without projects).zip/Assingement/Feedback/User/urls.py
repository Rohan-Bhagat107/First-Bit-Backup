from . import views
from django.urls import path

urlpatterns = [
    path('', views.displayForm),
    path('list', views.viewFeedbacks),
]