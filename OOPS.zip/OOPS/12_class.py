# create a class Book with parameters as b_id,b_name,b_price,author.Also add following methods-1) constructor(supports both parameterized and non-parameterised),destructor,showprice,display_details

class Book():
    def __init__(self,b_id=0,b_name="------",b_price=0,author="-----"):
        self.id=b_id
        self.name=b_name
        self.price=b_price
        self.author=author
    def show_price(self):
        print("Price of book is: ",self.price,"INR")

    def display_details(self):
        print("Name of book is: ",self.name,"and the author name is: ",self.author,"also the price of book is: ",self.price,"INR")
    def __del__(b1):
        print("Distructor is called.")
        print("Uninitialized")

b1=Book(1,"Psycology of money",250)
b1.show_price()
b1.display_details
