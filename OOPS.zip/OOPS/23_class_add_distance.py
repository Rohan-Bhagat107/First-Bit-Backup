#Create class"Distance" with datamembers as- km,m,cm.
#Also add following methods
#1)Constructor 2)Destructor 3)add 4)delete

class Distance():
    def __init__(self,km,m,cm):
        self.km=km
        self.m=m 
        self.cm=cm
    def __add__(self,other):
        dist=Distance(0,0,0)
        dist.km=self.km+other.km
        dist.m=self.m+other.m
        dist.cm=self.cm+other.cm
        return dist
    def __str__(self):
        return (f"{self.km}km, {self.m}m, {self.cm}cm")
    def __del__(self):
        print("Destructor is called")
        print("Uninitialized")

d1=Distance(1,200,500)
d2=Distance(3,600,900)

#d3=d1.__add__(d2)
d3=d1+d2
print(d3)