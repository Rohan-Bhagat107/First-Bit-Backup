# from shapes_parent import Shapes
    
# class Square(Shapes):      #child
#     def displays(self):
#         print("This is child class")
#         super().displays()


# sq=Square()
# sq.displays()



class Shapes():
    def __init__(self,color):
        self.color=color
    
    def display(self):
        print( f"Color: {self.color}")

# S1=Shapes("Black")
# S1.display()

class Circle(Shapes):
    def display(self):
        super().displays()
    
c1=Circle("Red")