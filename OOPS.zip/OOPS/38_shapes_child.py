from shapes_parent import Shapes
class Square(Shapes):
    def displays(self):
        print("This is child class")

sq=Square()
sq.displays()