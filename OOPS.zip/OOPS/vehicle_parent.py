#parent class of- (43_automobile)
class Vehicle():
    def __init__(self,chassis_no=0,colour=" ",engine_capacity="-"):
        self.chassis_no=chassis_no
        self.colour=colour
        self.engine_capacity=engine_capacity
    
    def start(self):
        print("Vehicle is starting")
    
    def stop(self):
        print("Vehicle stopped.")
if __name__=="__main__":   
    v=Vehicle(120389,"Black","600cc")
    v.start()
    v.stop()