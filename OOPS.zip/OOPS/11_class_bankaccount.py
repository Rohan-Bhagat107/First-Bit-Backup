class BankAccount():
    def __init__(self,acc_no,name,initial_deposite):
        self.acc_no=acc_no
        self.name=name
        self.balance=initial_deposite
    def deposite(self,amt):
        if amt>=0:
            self.balance+=amt
    def withdraw(self,amt):
        if (amt<self.balance):
             self.balance-=amt
        else:
             print("Insuficient Balance")
    def display_details(self):
        print("Name of customer is: ",self.name,"which has acc number: ",self.acc_no," with balance of: ",self.balance)

A1=BankAccount(100,"Rohan",5000)
A1.withdraw(800)
A1.deposite(3000)
A1.display_details()
A1.withdraw(1500)
A1.display_details()

