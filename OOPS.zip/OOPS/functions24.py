def add(a,b):
    return a+b

def isOdd(n):
    if n%2==0:
        return False
    return True
