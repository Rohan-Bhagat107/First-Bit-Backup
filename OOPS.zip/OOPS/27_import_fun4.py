from functions24 import isOdd
print(isOdd(23))