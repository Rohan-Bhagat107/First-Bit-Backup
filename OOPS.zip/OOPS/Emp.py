#parent class of class- 1)salesmanager 2)Accountant 3)Developer
class Emp():
    def __init__(self,id,name,basic_sal):
        self.id=id
        self.name=name
        self.basic_sal=basic_sal
    
    def display(self):
        print(f"ID: {self.id} | Name: {self.name} | Basic_salary: {self.basic_sal}")
if (__name__=="__main__"):  
    e=Emp(1,"Rohan",45000)
    e.display()