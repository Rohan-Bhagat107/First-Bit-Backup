from Emp import Emp
from salesmanager import salesManager

e=Emp(101,"Rahul",40000)
e.display()

sm=salesManager(250,"Pooja",49000,2500)
sm.displayManager()