class  Employee():
    def __init__(self,id,name,department,leaves=0):
        self.id=id
        self.name=name
        self.department=department
        self.leaves=leaves

    def display_details(self):
        print("Name of employee is",self.name,"from department",self.department,"having leaves",self.leaves)

    def display_leaves(self):
        print("Employee",self.name,"has leaves: ",self.leaves)
    def display_department(self):
        print("Employee",self.name,"is from department: ",self.department)

e1=Employee(1,"Rohan","IT",4)
e2=Employee(2,"Kshitij","IT",5)
e3=Employee(3,"Praful","IT",6)

e1.display_department()
e1.display_leaves()
e1.display_details()
print("---------------------------")
e2.display_department()
e2.display_leaves()
e2.display_details()
print("---------------------------")
e3.display_department()
e3.display_leaves()
e3.display_details()
        