from Emp import Emp
class Developer(Emp):
    def __init__(self,id,name,basic_sal,over_time,rateperHour):       #constructor of child class
        super().__init__(id,name,basic_sal)         #calls the constructor of parent class ie Emp
        self.over_time=over_time
        self.rateperHour=rateperHour
    
    def displayDev(self):
        print(f"ID: {self.id} | Name:{self.name} | Basic_salary:{self.basic_sal} |Overtime:{self.over_time} hr | rate per Hour:{self.rateperHour} | Total Salary={self.basic_sal+(self.over_time*self.rateperHour)} INR9")


d=Developer(303,"Rohan",45000,3,2000)
d.displayDev()