from vehicle_parent import Vehicle
from Bus import Bus
from car import Car
from motorcycle import MotorCycle

v=Vehicle(120389,"Black","600cc")
# v.start()

m=MotorCycle(1597865,"Silver","250cc","Regular") 

b=Bus(99992665,"Red","900cc",3)

c=Car(99992665,"Silver","700cc","Camera")


automobileList=[v,m,b,c]

for a in automobileList:
    a.start()
    a.stop()



