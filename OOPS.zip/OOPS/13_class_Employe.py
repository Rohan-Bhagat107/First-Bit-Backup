#write a class"Employe" 
#add static name "Company_name"
#Also add following methods-1)constructor 2)DisplaySalary 3)Static method "displaycompany_name"
#try to access static variable inside static and non static method
#try to access non static variable inside static and non static method


class Employe():
    comp_name="TCS"
    def __init__(self,id,name,salary):
        self.id=id
        self.name=name
        self.salary=salary
    def display_salary(self):              #non Static method
        print(Employe.comp_name)
        print("Id of an employe is: ",self.id)
        print("Name of an employe is: ",self.name)
        print("Salary of employee is: ",self.salary)
        print("--------------------------------")
        

     #static method
    def display_company():            #it dosen't expect 1st parameter as object reference(self)
        print(Employe.comp_name)
        #we cant access non static member inside static method  as they are only accessed with object reference but static method is a method that dosen't expect 1st parameter as object reference(self) so we cant access them 
e1=Employe(1,"Rohan",45000)
e1.display_salary()
Employe.display_company()


