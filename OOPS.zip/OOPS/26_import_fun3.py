from functions24 import add
a=10
b=20
print(add(a,b))