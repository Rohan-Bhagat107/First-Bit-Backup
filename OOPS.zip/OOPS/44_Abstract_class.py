from abc import ABC,abstractmethod
class Vehicle(ABC):
    def __init__(self,colour,brand):
        self.colour=colour
        self.brand=brand
    
    @abstractmethod
    def start(self):
        pass

    #non Abstract method
    def stop(self):
        print("Stopped....")
    

class Motorcycle(Vehicle):
    def __init__(self,colour,brand,engine):
        super().__init__(colour,brand)
        self.engine=engine
    
    def start(self):
        print("Starting a motorcycle.")

# v=Vehicle("Black","Maruti")
# v.start()                    #NOte-We cant create object of a abstract class

m=Motorcycle("Black","Hero",125)
m.start()            #note- we can create object of non-abstract class which is a child of abstract class
m.stop()
