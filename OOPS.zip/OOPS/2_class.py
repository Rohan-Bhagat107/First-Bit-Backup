class Student:
#1) __init__ is a constructor so we don't have to call it everytime explicitly it will called automatically as soon as the object of that particular class is created
#2) It is a special method which is automatically called when we create object of the class
#3)it is used to initilize the state of an object
    
    def __init__(self):
        self.roll=1
        self.name="Tushar"
        self.marks=97
    def display(self):
        print("Roll No: ",self.roll)
        print("Name: ",self.name)
        print("Marks: ",self.marks)

s=Student()         #create object

s.display()         #display attribute values