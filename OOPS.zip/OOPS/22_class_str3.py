#Create a class "Shirt" with members as sid,sname,type(formal etc..),price and size(small,large.etc) 
#Also Add following methods-
#1)constructor (supports both parameterised and non parameterised)
#2)Destructor
#3)Showshirt
#4)__str__()

class Shirt():
    def __init__(self,id=0,name="-",type="-",price=0,size=" "):
        self.sid=id
        self.sname=name
        self.type=type
        self.price=price
        self.size=size
    def showshirt(self):
        print("Name of shirt is: ",self.sname)
    def __str__(self):
        return (f"Name of shirt is: {self.sname}, type: {self.type}, Price: {self.price}, size: {self.size}")
    
    def __del__(self):
        print("Destructor is called")
        print("Uninitialized")

    
s1=Shirt(289,"Half Slevs","Formal",999,"Medium")
s2=Shirt(226,"Full Sleevs","Western",1500,"Long")
s3=Shirt(101,"Half Sleevs","Casual",1110,"Small")

#s1.showshirt()
print(s1)
del(s1)
print("------------------------------")
#s2.showshirt()
print(s2)
del(s2)
print("------------------------------")
print(s3)
#s3.showshirt()