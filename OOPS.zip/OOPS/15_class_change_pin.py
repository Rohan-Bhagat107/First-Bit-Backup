class BankAccount():
    def __init__(self,acc_no,name,initial_deposite,pin):
        self.acc_no=acc_no
        self.name=name
        self.balance=initial_deposite
        self.pin=pin
    def deposite(self,amt):
            self.balance+=amt
    def withdraw(self,amt):
        if (amt<self.balance):
             self.balance-=amt
        else:
             print("Insuficient Balance")
    def display_details(self):
        print("Name of customer is: ",self.name,"which has acc number: ",self.acc_no," with balance of: ",self.balance)
    def change_pin(self):
         self.pin=input("Enter your new pin")
         print("Your new pin is: ",self.pin)
         

A1=BankAccount(100,"Rohan",5000,14582)
print(A1.pin)
A1.withdraw(800)
A1.deposite(3000)
A1.display_details()
A1.withdraw(1500)
A1.display_details()
A1.change_pin()


