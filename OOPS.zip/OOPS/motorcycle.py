from vehicle_parent import Vehicle
class MotorCycle(Vehicle):
    def __init__(self,chassis_no=0,colour="-",engine_capacity=0,handle_type="-"):
        super().__init__(chassis_no,colour,engine_capacity)
        self.handle_type="Regular"
    
    def start(self):
        print(f'''" Starting a motor cycle with-> 
                     chassis no:{self.chassis_no} 
                     Colour: {self.colour}
                     Engine_capacity: {self.engine_capacity}
                     Handle_Type: {self.handle_type}''')
    
    def stop(self):
        print("Motorcycle is stopped")
if __name__=="__main__":
    m=MotorCycle(1597865,"Silver","250cc","Regular") 
    m.Start()
    m.Stop()
