from Employee_parent import Employee

class SalesManager(Employee):
    def __init__(self,id,name,basic_salary,incentive):
        super().__init__(id,name,basic_salary)
        self.incentive=incentive

    def Displaydetails(self):
        print(f"Id={self.id}| Name={self.name} | Basic_salary={self.basic_salary} | Incentive={self.incentive}")


s1=SalesManager(250,"Roy",49000,2500)
s1.Displaydetails()
