#parent class of (37_class_Shapes,38_shapes_child)

class Shapes():     #Parent
    def displays(self):
        print("This is parent class")