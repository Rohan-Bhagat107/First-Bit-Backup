
from vehicle_parent import Vehicle
class Bus(Vehicle):
    def __init__(self,chassis_no=0,colour="-",engine_capacity=0,Cabin_capacity="-"):
        super().__init__(chassis_no,colour,engine_capacity)
        self.Cabin_capacity=Cabin_capacity
    
    def start(self):
        print(f'''" Starting a Bus with-> 
                     chassis no:{self.chassis_no} 
                     Colour: {self.colour}
                     Engine_capacity: {self.engine_capacity}
                     cabin_capacity: {self.Cabin_capacity}''')
    
    def stop(self):
        print("Bus stopped.")
if __name__=="__main__":   
    b=Bus(99992665,"Red","900cc",3)
    b.start()
    b.stop()

