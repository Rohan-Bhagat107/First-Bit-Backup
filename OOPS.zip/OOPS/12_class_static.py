class Student():
    count=0
    def __init__(self,name,roll,marks):
        self.name=name
        self.roll=roll
        self.marks=marks
        Student.count+=1
    
s1=Student(14,"Akash",95)
s2=Student(15,"Umesh",98)
s3=Student(16,"Rahul",99)
print("count: ",Student.count)
