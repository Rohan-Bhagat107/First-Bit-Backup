class Time():
    def __init__(self,hours=0,minutes=0,seconds=0):
        self.hours=hours
        self.minutes=minutes
        self.seconds=seconds
    def __str__(self):
        return f"{self.hours}:{self.minutes}:{self.seconds}"
    def __add__(self,t):
        temp=Time()
        temp.hours=self.hours+t.hours
        temp.minutes=self.minutes+t.minutes
        temp.seconds=self.seconds+t.seconds
        return temp


t1=Time(4,15,30)
t2=Time(2,3,15)
t3=t1+t2
print(f"New time is: {t3}")



# class Time():
#     def __init__(self,hours,minutes,seconds):
#         self.hours=hours
#         self.minutes=minutes
#         self.seconds=seconds
    
#     def __str__(self):
#         return f"{self.hours}:{self.minutes}:{self.seconds}"
    
#     def __add__(self,new_time):
#         temp=Time(0,0,0)
#         temp.hours=self.hours+new_time.hours
#         temp.minutes=self.minutes+new_time.minutes
#         temp.seconds=self.seconds+new_time.seconds
#         return temp

# t1=Time(2,10,30)
# t2=Time(3,10,20)
# print(t1+t2)
    
    
    
