from Emp import Emp
class Accountant(Emp):
    def __init__(self,id,name,basic_sal):
     super().__init__(id,name,basic_sal)


A=Accountant(101,"Rohan",45000)
A.display()