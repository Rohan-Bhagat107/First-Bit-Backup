from mypackage import function
function.displayMsg()


#ways to import package
# 1)import mypackage.function
# 2)import mypackage.function as a        #we can use nickename for a module
# 3)from mypackage.function import *     #import all functions of that module from that package


# ie in general-
# 1) import packagename
# 2)import packagename as a
# 3)from packagename.modulename import functionname
# 4)from packagename.modulename import *
