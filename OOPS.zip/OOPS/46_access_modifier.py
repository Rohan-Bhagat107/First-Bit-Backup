class Book():
    def __init__(self,id=0,Name="- ",Price="-"):
        self.__id=id
        self.Name=Name
        self.__Price=Price
    
    def __get_price_after_discount(self):
        return ((self.__Price)-(self.__Price*10/100))
    
    def Display(self):
        print(f"ID: {self.__id} | Name: {self.Name} | Price after discount:{self.__get_price_after_discount()}")


b=Book(100,"Atomic Habit",700)
b.Display()

#we can access private members out of the class by thier mangled(changed) name as follows-
# print(b._Book__get_price_after_discount())
# print(b._Book__id)  
# print(b._Book__Price)
