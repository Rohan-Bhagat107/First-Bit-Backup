#WAP to make a product class with constructor .The members are- Product name,product price,product brand,product colour
#also make methods - showbrand,showprice,showcolour,displaydetails

class Product():
    def __init__(self,id,name,price,brand,colour):
        self.id=id
        self.name=name
        self.price=price
        self.brand=brand
        self.colour=colour
    def showbrand(self):
        print("Brand of your product is: ",self.brand)

    def showcolour(self):
        print("Colour of your product is: ",self.colour)
    
    def showprice(self):
        print("Price of your product is: ",self.price)
    
    def display_details(self):
        print("Your product is:",self.name,"which is the brand of:",self.brand,"having colour:",self.colour,"with price of: ",self.price,"INR")
    def show_id(self):
        print("Id of your product is: ",self.id)

p1=Product(1,"Shirt",300,"Zara","Navy Blue")
p2=Product(2,"T-Shirt",400,"Puma","Grey")
p3=Product(3,"Pant",500,"Adidas","Black")

p1.showbrand()
p1.showcolour()
p1.display_details()
print("-------------------")

p2.showbrand()
p2.showcolour()
p2.display_details()
print("-------------------")

p3.showbrand()
p3.showcolour()
p3.display_details()
p3.show_id()
print("-------------------")

