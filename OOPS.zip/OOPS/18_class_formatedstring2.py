class Empployee():
    def __init__(self,id,name,salary):
        self.id=id
        self.name=name
        self.salary=salary
    def __str__(self):
        return f"Id: {self.id} Name of Employee is: {self.name} which has salary of RS: {self.salary}"


e1=Empployee(101,"Rohan",45000)
print(e1)