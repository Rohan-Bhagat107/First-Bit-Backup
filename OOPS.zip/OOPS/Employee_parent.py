#parent class of module - (31_Sales_manager,)
class Employee():
    def __init__(self,id,name,basic_salary):
        self.id=id
        self.name=name
        self.basic_salary=basic_salary

    def Display(self):
        print(f"Id={self.id}| Name={self.name} | Basic_salary={self.basic_salary}")
if (__name__=="__main__"):
    e1=Employee(101,"Rohan",45000)
    e1.Display()