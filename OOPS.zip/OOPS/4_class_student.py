class Student():
    def set_data(self):
        self.name=input("Enter name of student: ")
        self.DOB=(input("Enter DOB of student: "))
        self.blood_group=input("Enter blood group of student: ")
        self.section=input("Enter section of student:")

    def display(self):
        print("Name: ",self.name)
        print("DOB: ",self.DOB)
        print("Blood group: ",self.blood_group)
        print("Section: ",self.section)

s1=Student()
s1.set_data()
s1.display()
print("------------------------")
    
s2=Student()
s2.set_data()
s2.display()
print("------------------")
    
s3=Student()
s3.set_data()
s3.display()
    
