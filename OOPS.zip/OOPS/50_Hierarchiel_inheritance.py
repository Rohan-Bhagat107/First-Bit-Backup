class Vehicle():
    def __init__(self):
        pass
    def display(Self):
        pass

class Car(Vehicle):
    def __init__(self):
        pass

    def display(self):
        pass
class Bus(Vehicle):
    def __init__(self):
         pass
    
    def display(self):
        pass

class Nitro():
    def __init__(self):
        pass
    def display(self):
        pass

class Motorcycle(Vehicle,Nitro):
    def __init__(self):
        pass
    def display(self):
        pass



