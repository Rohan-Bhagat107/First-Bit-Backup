class Book():
    def set_data(self):
        self.name=input("Enter name of book: ")
        self.Author=input("Enter name of author: ")
        self.price=int(input("Enter name of book: "))
    def display(self):
        print("Name of book is: ",self.name)
        print("Name of author is: ",self.Author)
        print("Price of book is: ",self.price)

b1=Book()
b1.set_data()
b1.display()

b2=Book()
b2.set_data()
b2.display()