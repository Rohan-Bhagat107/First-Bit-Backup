from Emp import *
class salesManager(Emp):
    def __init__(self,id,name,basic_sal,incentive):
        super().__init__(id,name,basic_sal)
        self.incentive=incentive
    
    def displayManager(self):
        print(f"ID:{self.id} | Name={self.name} | Basic_salary={self.basic_sal} | Incentives={self.incentive} | Total Salary: {self.basic_sal+self.incentive} ")
    
sm=salesManager(102,"ABC",35000,2000)
sm.displayManager()