list1=[2,5,8,1,6]
print(len(list1))