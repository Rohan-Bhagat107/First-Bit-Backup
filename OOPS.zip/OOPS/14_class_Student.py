class Student():
    count=0
    def __init__(self,id,name,percentage):
        self.id=id
        self.name=name
        self.percentage=percentage
        Student.count+=1
    def display_percentage(self):
        print(self.percentage)
    def display_details(self):
        print("Id of student is: ",self.id)
        print("Name of student is: ",self.name)
        print("Percentage of student is: ",self.percentage)
        print("-----------------------------------")

    def __del__(self):
        print("Distructor Called")
        print("Uninitialized")
    def display_count():
        print("Total number of students is: ",Student.count)

s1=Student(101,"Rohan",95)
s2=Student(102,"Kshitij",94)
s1.display_percentage()
s1.display_details()
Student.display_count()


