class Lemon():
    def __init__(self):
        self.count=1
    
    def display(self):
        print("lemon::display")
    
class Sugar():
    def __init__(self):
        self.count=2
    
    def display(self):
        print("Sugar:: Display")
    
class lemonjuice(Lemon,Sugar):
    def __init__(Self):
        super().__init__()
    
    def display(self):
        print("Limejuice:: Display")
        print(self.count)
    
l=Lemon()
l.display()

s=Sugar()
s.display()

ls=lemonjuice()
l.display()
