#create  class " Book" with memebers as - bid ,bname,bprice,and author.Add following methods-
# 1)constructor (supports both parameterised and non parameterised)
# 2)Destructor()
# 3)ShowBook()
# 4)showprice()

class Book():
    def __init__(self,id=0,name="  ",price=0,author=" "):
        self.bid=id
        self.bname=name
        self.bprice=price
        self.bauthor=author
    def show_book(self):
        print("Book name is: ",self.bname)
    
    def showprice(self):
        print("Price of book is: ",self.bprice)
    def __str__(self):
        return(f"Name of book is:{self.bname} which has price of:{self.bprice} whose author name is: {self.bauthor}" )
    def __del__(self):
        print("Distructor is called")
        print("Uninitialized")

b1=Book(102,"XYZ",250,"Rohan")
# b1.show_book()
# b1.showprice()
print(b1)
del(b1)
print("-----------------------------")

b2=Book(111,"ABC",999,"XYZ")
# b2.show_book()
# b2.showprice()
print(b2)
del(b2)
print("---------------------")

b3=Book(112,"PQR",350,"ABC")
# b3.show_book()
# b3.showprice()
print(b3)