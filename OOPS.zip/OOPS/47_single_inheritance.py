class car():
    def __init__(self,colour,brand,price):
        self.colour=colour
        self.brand=brand
        self.price=price
    
    def display(self):
        print(f"Car colour is: {self.colour}")
    

class sportscar(car):
    def __init__(self,colour,brand,price):
        #super().__init__(colour,brand,price)
        self.colour=colour
        self.brand=brand
        self.price=price
    
    def display(self):
        print(f"Sports car colour is: {self.colour}")
    
c=car("Black","Farrari",500000)
c.display()
sc=sportscar("White","Honda",450000)
sc.display()