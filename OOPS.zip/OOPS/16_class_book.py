# create  class " Book" with memebers as - bid ,bname,bprice,and author.Add following methods-
# 1)constructor (supports both parameterised and non parameterised)
# 2)Destructor()
# 3)ShowBook()
# 4)showprice()
#Also add 10% GST in book class by making a method "buybook"
#Also use static concept if applicable

class Book():
    count=0
    gst=1.1
    def __init__(self,id=0,name="  ",price=0,author=" "):
        self.bid=id
        self.bname=name
        self.bprice=price
        self.bauthor=author
        Book.count+=1
    def show_book(self):
        print("Book name is: ",self.bname)
    
    def showprice(self):
        print("Price of book is: ",self.bprice,"INR")
    def buybook(self):
        Bill=self.bprice*Book.gst
        print("Book price after adding 10%""GST is: ",Bill)
    def __del__(self):
        print("Distructor is called")
        print("Uninitialized")

b1=Book(102,"XYZ",250,"Rohan")
b1.show_book()
b1.showprice()
b1.buybook()
print("Total number of book is: ",Book.count)