#implement a Book class with following
#Attributes: id,name,author,price
#method: 
#print_author()
#print_name()
#print_details()

class Book:
    def __init__(self):
        self.id=101
        self.name="Pchycology of money"
        self.author="XYZ"
        self.price=100

    def print_author(self):
        print("Author: ",self.author)
    def print_name(self):
        print("Name: ",self.name)

    def print_details(self):
        print("Id:",self.id)
        print("Name:",self.name)
        print("Author:",self.author)
        print("Price:",self.price)

    
b=Book()
b.print_author()
print("------------------------")
b.print_name()
print("----------------")
b.print_details()
