from functions24 import *
a=10
b=20
print(add(a,b))
print(isOdd(24))