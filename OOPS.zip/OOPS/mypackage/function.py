def displayMsg():
    print("Hello world")