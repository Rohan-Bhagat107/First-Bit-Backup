class Employee():
    def __init__(self,id,name):
        self.id=id
        self.name=name

class Programmer(Employee):
    def __init__(self,id,name,extra_hrs):
        super().__init__(id,name)
        self.extra_hrs=extra_hrs
    
    def display(self):
        print(f"Id:{self.id} | Name:{self.name} | Extra_hrs:{self.extra_hrs} hr")

class SalesManager(Employee):
    def __init__(self,id,name,extra_hrs,incentives):
        super().__init__(id,name)
        self.extra_hrs=extra_hrs
        self.incentives=incentives
    
    def display(self):
        print(f"Id:{self.id} | Name:{self.name} | Extra_hrs:{self.extra_hrs} | Incentives:{self.incentives} INR")
    
p=Programmer(1,"Rohan",25)
p.display()
e1=Employee(202,"XYZ")
print(e1)
sm=SalesManager(203,"ABC",3,3600)
sm.display()

