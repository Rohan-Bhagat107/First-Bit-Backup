name="Rohan"
company="TCS"
salary=45000

print(name,"is working in company",company,"with salary of RS: ",salary)

print(f"{name} is working in company {company} with salary of RS: {salary}")