class vehicle():
    def __init__(self,colour,brand):
        self.colour=colour
        self.brand=brand

    def display(self):
        print(f"Car colour is: {self.colour}")
    
class sportscar(vehicle):                          #parent=vehicle
    def __init__(self,colour,brand):
     self.colour=colour
     self.brand=brand
    
    def display(self):
        print(f"Sprots Car colour is: {self.colour}")
    
class racingcar(sportscar):                         #parent=sportsCar
    
    def __init__(self,colour,brand):
        self.colour=colour
        self.brand=brand
    
    def display(self):
        print(f"Colour of racing car is: {self.colour}")
    
v=vehicle("Black","Hond")
v.display()
sp=sportscar("Yellow","Bugati")
sp.display()
rc=racingcar("White","XYZ")
rc.display()