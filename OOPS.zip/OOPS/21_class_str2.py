#Create a class "Product" with members as pid,pname,price,quantity 
#Also Add following methods-
#1)constructor (supports both parameterised and non parameterised)
#2)Destructor
#3)Showprice

class Product():
    def __init__(self,id=0,name=" ",price=0,quantity=0):
        self.pid=id
        self.pname=name
        self.price=price
        self.quantity=quantity
    def showprice(self):
        print("Price of Product is: ",self.price)
    def __str__(self):
        return(f"Name of product is: {self.pname} which has price of: {self.price} and quantity that you have purchesd is: {self.quantity}")
    def __del__(self):
        print("Destructor is called")
        print("Uninitialized")
    
p1=Product(101,"ABC",999,2)
#p1.showprice()
print(p1)
del(p1)
print("-----------------------")

p2=Product(105,"XYZ",1500,3)
#p2.showprice()
print(p2)
del(p2)
print("-----------------------")

p3=Product(103,"PQR",2500,1)
print(p3)
#p3.showprice()
del(p3)