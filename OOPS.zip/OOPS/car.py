from vehicle_parent import Vehicle
class Car(Vehicle):
    def __init__(self,chassis_no=0,colour="-",engine_capacity=0,dashboard_screen="-"):
        super().__init__(chassis_no,colour,engine_capacity)
        self.dashboard_screen=dashboard_screen
    
    def start(self):
        print(f'''" Starting a Car with-> 
                     chassis no:{self.chassis_no} 
                     Colour: {self.colour}
                     Engine_capacity: {self.engine_capacity}
                     Dashboard_screen: {self.dashboard_screen}''')
    
    def stop(self):
        print("Car stopped.")
if __name__=="__main__":     
    c=Car(99992665,"Silver","700cc","Camera")
    c.start()
    c.stop()

