#without try block

# a=int(input("Enteer a number: "))
# print(f"square of {a} is {a*a}")

#with try block
try:
    a=int(input("Enteer a number: "))
except:
    print("Invalid integer value")
else:
    print(f"square of {a} is {a*a}")

