import mysql.connector

mydb=mysql.connector.connect(host="localhost",user="root",password="Pass@123")
cur=mydb.cursor()
str=''' create database python_practice'''

cur.execute(str)
mydb.close()