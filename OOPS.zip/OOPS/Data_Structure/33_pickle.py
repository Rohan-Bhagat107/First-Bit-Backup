import pickle
data=[10,22,30,35,26]
def write_data():
    with open("Mydata.abc","wb") as fp:
        pickle.dump(data,fp)
        print("Data Saved!")

def read_data():
    with open("Mydata.abc","rb") as fp:
        d=pickle.load(fp)
        print(d)
        print(type(d))
        print(type(d[0]))

write_data()
read_data()
