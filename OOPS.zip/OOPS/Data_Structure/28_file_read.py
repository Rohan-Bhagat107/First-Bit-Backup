f=open("Abc.txt","r")
print(f.read())
