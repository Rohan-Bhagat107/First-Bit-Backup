def fibo():
    a,b=0,1
    while True:
        c=a+b
        yield c
        a,b=b,c

f=fibo()
# print(f)

for x in range(10):
    print(next(f))

