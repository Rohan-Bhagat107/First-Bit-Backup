# import threading
# import time

# class Mythread(threading.Thread):
#     def __init__(self,x):
#         super(). __init__()
#         self.data=x
    
#     def table(self):
#         for i in range(1,11):
#             time.sleep(2)
            
#             print(self.data*i)
    
#     def run(self):
#         self.table()
# if __name__=="__main__":   
#     t1=Mythread(5)
#     t2=Mythread(3)

#     t2.start()
#     t1.start()



# import threading

# class MyThread(threading.Thread):
#     def __init__(self,N):
#         super().__init__()
#         self.Number=N
    
#     def display(self):
#         for i in range(1,11):
#             print(self.Number*i)
    
#     def run(self):
#         self.display()
    

# t1=MyThread(5)
# t1.start()

import time
import threading
lock1=threading.Lock()
def display(msg):
    lock1.acquire()
    for i in msg:
        print(i)
        time.sleep(1)
    lock1.release()

def info(msg):
    # lock1.acquire()
    for i in msg:
        print(i)
        time.sleep(2)
    # lock1.release() 
t1=threading.Thread(target=display,name="Thread1",args=("Rohan",))
t2=threading.Thread(target=info,name="Thread2",args=("Bhagat",))

t1.start()
t2.start()