name=input("Enter your name: ")
#creating a file with name: User_input.txt
f=open("User_input.txt","a")

#writing name in the file
f.write(name + "\n")

#closing the file
f.close()
print("data saved succesfully")