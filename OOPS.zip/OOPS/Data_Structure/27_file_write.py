#opens the file if exist or creates that file if it is not in 
fp=open("Abc.txt","w")
fp.write("Hello world\n ")
fp.write("I am Rohan")
fp.close()


