f=open("stud_data.txt","a")
n=int(input("Enter how many students are there: "))
for i in range(n):
    name=input("Enter name of student: ")
    id=int(input("Enter ID of an Student: "))
    f.write(f"Name={name} | ID: {id}","\n")
# f=open("stud_data.txt","r")
# data=f.read()
# f.close()
# print(data)

