try:
    a=int(input("Enter a number: "))
    b=int(input("Enter a number: "))
    print(f" Division of a and b is: {a/b}")
except ValueError as v :
    print(v)
    print("Invalid Integer value")
except ZeroDivisionError as z :
    print(z)
    print("Division with zero is not possible")
