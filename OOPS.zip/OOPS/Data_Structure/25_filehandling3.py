fp = open("students.txt","r")

'''
# Reading all the data at once
studData = fp.read()
print(studData)
'''

'''
# Reading single line at a time
for line in fp:
    print(line)
'''

# Read the data and store it in a list
data = []
for line in fp:
    data.append(line.rstrip("\n"))

print(data)
