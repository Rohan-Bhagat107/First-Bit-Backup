from age_error import Ageerror
try:
    age=int(input("Enter your age: "))
    if age<18:
        raise Ageerror
except Ageerror as a:
    print(a)

else:
    print("Thank you!")
