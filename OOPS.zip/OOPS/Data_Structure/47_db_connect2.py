import mysql.connector

mydb=mysql.connector.connect(host="localhost",user="root",password="Pass@123",database="class")
cur=mydb.cursor()
str=''' select * from employees where employee_id in( %s,%s)  '''

value=(101,102)
cur.execute(str,value)
record=cur.fetchall()
for i in record:
    print(i)

mydb.close()