# import threading

# def print1():
#     str="FirstBit"
#     for i in str:
#         print(i)

# def print2():
#     str="Solution"
#     for i in str:
#         print(i)
# t1=threading.Thread(name="Thread1",target=print1)
# t2=threading.Thread(name="Thread2",target=print2)
# t1.start()
# t1.join()
# t2.start()
import threading
import time

def display(msg):
    lock1.acquire()
    for i in msg:
        print(i)
        time.sleep(2)
    lock1.release()

def info(msg):
    lock1.acquire()
    for i in msg:
        print(i)
        time.sleep(1)
    lock1.release()

t1=threading.Thread(name="Thread1",target=display,args=("Rohan",))
t2=threading.Thread(name="Thread2",target=info,args=("He is a boy",))

lock1=threading.Lock()
t1.start()
t2.start()