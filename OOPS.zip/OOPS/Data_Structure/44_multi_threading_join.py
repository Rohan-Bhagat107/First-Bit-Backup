# import threading
# import time

# def display(msg):
#     # time.sleep(4)
    
#     for i in msg:
        
#         print(i)

# def info(msg):
#     for i in msg:
#         print(i)

# t1=threading.Thread(name="Thread1",target=display,args=("First",))
# t2=threading.Thread(name="Thread2",target=info,args=("Bit",))
# t3=threading.Thread(name="Thread3",target=display,args=("Python",))

# lock1=threading.Lock()
# t1.start()
# t1.join()
# t2.start()
# t2.join()
# t3.start()


### Implementing concept of lock

import threading 
import time
lock1=threading.Lock()

def display(msg):
    # lock1.acquire()
    for  i in msg:
        print(i)
        time.sleep(4)
    # lock1.release()
    

def info(msg):
    # lock1.acquire()
    for i in msg:
        print(i)
        time.sleep(5)
    # lock1.release()
   
def data(msg):
    # lock1.acquire()
    for i in msg:
        print(i)
        time.sleep(6)
    # lock1.release()
    

t1=threading.Thread(target=display,name="thread1",args=("Rohan",))
t2=threading.Thread(target=info,name="thread2",args=("Samadhan",))
t3=threading.Thread(target=data,name="thread3",args=("Bhagat",))

t1.start()
# t1.join()
t2.start()
t3.start()