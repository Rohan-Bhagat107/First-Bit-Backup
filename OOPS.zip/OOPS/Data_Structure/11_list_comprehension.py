#Find all numbers from 1 to 1000 that are divisible by 8
list1=[]

list2=[x for x in range(1,1001) if x%8==0]  
print(list2) 