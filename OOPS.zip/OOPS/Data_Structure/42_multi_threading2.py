import threading
import time

def print1(str):
    for i in str:
        time.sleep(2)
        print(i)

t1=threading.Thread(name="Thread1",target=print1,args=("This is nice",))
t2=threading.Thread(name="Thread2",target=print1,args=("Hello World",))

t1.start()
t2.start()