#WAP to find sum of all elements of a list

a=[10,12,20,30]
sum=0
for x in a:
    sum+=x
print("Sum of all elements of list is: ",sum)