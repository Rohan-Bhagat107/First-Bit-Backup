from tkinter import *
wind=Tk()
def multi():
    n1=int(e1.get())
    n2=int(e2.get())
    n3=int(n1*n2)
    l3.config(n3)
wind.geometry("400x400")
l1=Label(wind,text="Enter 1st number: ")
e1=Entry()
l2=Label(wind,text="Enter 2nd number: ")
e2=Entry()
btn=Button(wind,text="Calculate",command=multi)
l3=Label(wind)

l1.grid(row=1,column=1)
e1.grid(row=1,column=2)

l2.grid(row=2,column=1)
e2.grid(row=2,column=2)

btn.grid(row=3,column=2)
l3.grid(row=4,column=2)

wind.mainloop()