import mysql.connector

mydb=mysql.connector.connect(host="localhost",user="root",password="Pass@123",database="python_practice")
cur=mydb.cursor()
str=''' insert into student_info(%s,%s,%s);'''
values=(1,"Rohan",23)
cur.execute(str,values)
mydb.commit()
mydb.close()