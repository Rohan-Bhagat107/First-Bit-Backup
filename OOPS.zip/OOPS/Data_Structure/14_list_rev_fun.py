l1=[4,1,8,9,2]
(l1.sort(reverse=True))
print(l1)





