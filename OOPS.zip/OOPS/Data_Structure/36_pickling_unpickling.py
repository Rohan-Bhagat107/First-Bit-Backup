import pickle
class Account():
    def __init__(self,acc_no):
        self.acc_no=acc_no
    
    def display(self):
        print("The account number is: ",self.acc_no)
    
    def __str__(self):
        return ("The acc_no is: "+str(self.acc_no))


def pickling(acc_no):
    with open("Acc.txt","wb") as fp:
        pickle.dump(acc_no,fp)
    
def unpickling():
    with open ("Acc.txt","rb") as fp:
        w=pickle.load(fp)
        for i,j in w.items():
            print(i,":",j)

a1=Account(1)
a2=Account(2)
a3=Account(3)
all_acc={1:a1,2:a2,3:a3}
pickling(all_acc)
unpickling()

