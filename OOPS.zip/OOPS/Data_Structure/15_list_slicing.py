# l1=[2,8,6,9,4]
# print(l1[0:3 :1])
# print(l1)


#slicing 
l1=(2,8,6,9,4)
print(l1[0:3])   #slicing the a part of "L1" tuple
print(l1)




