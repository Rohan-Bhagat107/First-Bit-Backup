data=[2,4,5,7,9,12,16,20,25,26,35]
start=0
end=len(data)-1
no_searched=int(input("Enter no that you want to search: "))

while start<=end:
    mid=(start+end)//2
    if data[mid]==no_searched:
       print(f"{no_searched} is present in the list at index: {mid}")
       break
    elif no_searched>data[mid]:
        start=mid+1
    elif no_searched<data[mid]:
        end=mid-1
else:
    print(f"{no_searched} is not in the list")



# data=[5,1,8,2,9,77,88,9,98]
# start=0
# end=len(data)-1
# num=9
# while start<=end:
#     mid=(start+end)//2
#     if data[mid]==num:
#         print("Number s found at index: ",mid )
#         break
#     elif num<data[mid]:
#         end=mid-1
#     elif num>data[mid]:
#         start=mid+1
# else:
#     print("Number is not found")
