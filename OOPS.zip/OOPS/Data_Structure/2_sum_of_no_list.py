 #WAP to find sum of all numbersof a list

n=int(input("How many number are there: "))
numbers=[]
count=0
sum=0
for i in range(1,n+1):
    no=int(input("Enter a number: "))
    numbers.append(no)
    count+=1
    sum+=no
    if count==n:
        break
print("Sum of all numbers of list is: ",sum)
print(numbers)
