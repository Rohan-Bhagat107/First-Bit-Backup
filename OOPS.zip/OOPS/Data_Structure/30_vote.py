from age_error import Ageerror
try:
    age=int(input("Enter your age: "))
    if age<18:
        raise Ageerror 
except ValueError:
    print("Age should be an integer value")

except Ageerror as a:
    print(a)

else:
    print("You are eligible to vote.")
finally:
    print("Code is completed")

