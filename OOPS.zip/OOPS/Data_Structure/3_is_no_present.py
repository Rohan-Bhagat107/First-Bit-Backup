#WAP to accept numbers from user and check is the number is present in list or not
n=int(input("How many number are there: "))
no_checked=int(input("which number you want to find in list: "))
numbers=[]
count=0

for i in range(1,n+1):
    no=int(input("Enter a number: "))
    numbers.append(no)
    count+=1
    
for i in numbers:
    if i==no_checked:
        print(f"{no_checked} is present in the list")
        break
else:
    print(f"{no_checked} is not present in the list")

print(f"{no_checked} is there in list {count} times")

