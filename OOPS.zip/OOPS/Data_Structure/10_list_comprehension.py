#WAP to find even numbers from given list:

list1=[]

n=int(input("Enter how many elemnts you want to add in a list: "))
for i in range(n):
    element=int(input("Enter the element: "))
    list1.append(element)
list2=[x for x in list1 if x%2==0]  
print(list2) 
