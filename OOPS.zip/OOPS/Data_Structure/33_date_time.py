import datetime as dt 

d1=dt.datetime(2000,10,25)
print(d1)

d2=dt.datetime.now()
print(d2)
d2=dt.datetime.today()
print(d2)

print(d2.date())
print(d2.day)
print(d2.month)
print(d2.year)
print(d2.hour)
print(d2.minute)
print(d2.second)

d3=d2-d1
print(d3)

exit_date=d2-dt.timedelta(days=60)
print(exit_date)