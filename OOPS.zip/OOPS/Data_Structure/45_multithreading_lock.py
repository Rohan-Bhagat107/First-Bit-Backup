import threading
import time

class Account():
    def __init__(self,acc_no,name,balance):
        self.acc_no=acc_no
        self.name=name
        self.balance=balance
    
    def deposite(self,amt):
        print("Balance before deposite : ",self.balance)
        time.sleep(4)
        lock1.acquire()
        self.balance+=amt
        lock1.release()
        print("Balance after withdraw : ",self.balance)

    
    def withdraw(self,amt):
        print("Balance before withdraw: ",self.balance)
        time.sleep(4)
        lock1.acquire()
        self.balance-=amt
        lock1.release()
        print("Balance after withdraw: ",self.balance)



if __name__=="__main__":
    acc=Account(101,"Rohan",5000)
    t1=threading.Thread(name="Thread1",target=acc.deposite,args=(2000,))
    t2=threading.Thread(name="Thread2",target=acc.withdraw,args=(3000,))

    t1.start()
    t2.start()

    lock1=threading.Lock()
