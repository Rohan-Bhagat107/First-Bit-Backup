import mysql.connector

mydb=mysql.connector.connect(host="localhost",user="root",password="Pass@123",database="python_practice")

cur=mydb.cursor()
str=''' create table student_info(roll_no int primary key,name varchar(45),Age int);'''
cur.execute(str)
mydb.close()
