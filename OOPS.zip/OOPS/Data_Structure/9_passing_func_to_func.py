#Passing one function to another function:-

def f1(f):
    print(f)
    f()


def demo():
    print("I am demo()")


print(demo)
print(f1)
f1(demo)