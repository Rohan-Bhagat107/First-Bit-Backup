#WAP to separate even and odd elements from the list in two different list
list1=[]
even_list=[]
odd_list=[]
n=int(input("How many elements you want  to add un list: "))
for i in range(n):
    element=int(input("Enter a element: "))
    list1.append(element)
    if element%2==0:
        even_list.append(element)
    else:
        odd_list.append(element)

print(list1)
print(even_list)
print(odd_list)

#same progarm with list_comprehension

list1=[]
n=int(input("How many elements you want  to add un list: "))
for i in range(n):
    element=int(input("Enter a element: "))
    list1.append(element)
even_list=[x for x in list1 if x%2==1]
print(even_list)