#WAP to find  maximum and minimum element of a list without using inbuild functions:

a=[10,2,48,6,95]
f=0
s=0

for i in a:
    if i>f:
        s=f
        x=i
    
