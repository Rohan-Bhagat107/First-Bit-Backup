#WAP to find  maximum and minimum element of a list by using inbuild functions:

a=[10,15,9,7,55]
#descending sort

a.sort(reverse=True)
print("Maximum number is: ",a[0])

#Ascending sort
a.sort()
print("Minimum number is: ",a[0])
