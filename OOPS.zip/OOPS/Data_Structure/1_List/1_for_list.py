marks=[95,85,97,87]
for i in marks:
    print(i)
print(marks)