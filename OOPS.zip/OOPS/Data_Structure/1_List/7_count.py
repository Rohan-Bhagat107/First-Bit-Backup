marks=[98,85,96,75,66,98]
print(f"98 -> {marks.count(98)}" )
