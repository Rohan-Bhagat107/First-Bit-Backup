from company import Company
from Employee import Employee

if __name__=="__main__":
    c=Company()

    choice=0
    while choice !=7 :
        print('''            1)Add employee
                2)show emplyee
                3)search employee by ID
                4)update employee
                5)delete employee
                6)Search employee by name
                7)Exit''')

        choice=int(input("Enter your choice: "))
        if choice==1:
            id=int(input("Enter employee ID: "))
            for x in c.emp:
                if id==x.id:
                    print("This ID already exists please enter another ID....")
                    break
            else:
                name=input("Enter name of employee:")
                e1=Employee(id,name)
                c.add_emp(e1)
        
        if choice==2:
            c.show_emp()
        
        if choice==3:
            id=int(input("Enter id of employee that you want to search: "))
            #e1=Employee(id)
            c.search_emp_by_id(id)
        
        if choice==4:
            id =int(input("Enter Id of employee that you want to update: "))
            #e1=Employee(id)
            c.update_emp(id)
        
        if choice==5:
            id=int(input("Enter employee ID that you want to delete: "))
            c.delete_emp(id)
        
        if choice==6:
            name=input("Enter name of employee that you want to search: ")
            c.search_emp_by_name(name)

