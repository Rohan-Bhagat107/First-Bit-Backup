marks=[98,85,96,75,66,98]
marks.sort(reverse=True)
print(marks)