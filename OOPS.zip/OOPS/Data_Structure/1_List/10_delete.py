marks=[98,86,89,99,74]
del marks
print(marks)