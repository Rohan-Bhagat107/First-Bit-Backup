# def bubble_sort(data):
#     print(data)

#     for j in range(1,len(data)):
#         for i in range(len(data)-j):
#             if data[i]>data[i+1]:
#                 data[i],data[i+1]=data[i+1],data[i]

#     print(data)

# nums=[2,100,8,10,-5,13,-400]
# bubble_sort(nums)

data=[1,9,2,8,4,7,3]
for i in range(1,len(data)-1):
    for j in range(len(data)-i):
        if data[j]>data[j+1]:
            data[j],data[j+1]=data[j+1],data[j]
print(data)