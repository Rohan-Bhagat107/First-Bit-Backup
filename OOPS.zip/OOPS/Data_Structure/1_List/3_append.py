marks=[76,98,84,97,98]
marks.append(84)
print(marks)