class Bank():
    def __init__(self,Acc_no="-",Name="-",Balance=0):
        self.Account=[]
        self.acc_no=Acc_no
        self.name=Name
        self.balance=Balance
    
    def add_cust(self,c1):
        self.Account.append(c1)
    
    def show_all_cust(self):
        for x in self.Account:
            print(f"Acc_no:{x.acc_no} | Name: {x.name} | Balance: {x.balance}")
    
    def update_cust(self,balance,acc_no="-"):
        #self.amt=int(input("Enter amount that you want to deposite/withdraw: "))
        self.balance=balance
        self.acc_no=acc_no
        amt=int(input("Enter amount that you want to deposite/withdraw: "))

        print(''' What do you want to do ?
                   1)Deposite
                   2)withdraw''')
        choice=int(input("Enter a number from above menu to select operation: "))
        

        for x in self.Account:
            if acc_no==x.acc_no:
                if choice==1:
                    
                    if amt>0:
                        self.balance+=amt
                        print(f"Acc_no: {x.acc_no} | Name: {x.name} |Balance: {self.balance}")

                        break

                    else:
                        print("Please enter valid amount....")
                        break
                
                if choice==2:
                    if amt>0 and amt<self.balance:

                        self.balance-=amt
                        print(f"Acc_no: {x.acc_no} | Name: {x.name} |Balance: {self.balance}")

                        break
                    
                    else:
                        print("Insufficient balance......")
                        break
        

            
        
    def delete_cust(self,acc_no="-"):
        for x in range(len(self.Account)):
            if self.Account[x].acc_no==acc_no:
                index=x
                self.Account.pop(index)
                print(f"Customer with acc_no: {self.acc_no} is removed and  now the customers are:  ")
                B.show_all_cust()
                break
    def show_details(self,acc_no):
        for x in self.Account:
            if x.acc_no==acc_no:
             print(f"Acc_no:{x.acc_no} | Name: {x.name} | Balance: {x.balance}")
             break
    


class Customer():
    def __init__(self,Acc_no,Name,Balance=0):
        self.acc_no=Acc_no
        self.name=Name
        self.balance=Balance


if __name__=="__main__":
    B=Bank()
    choice=0
    while choice!=6:
        print(''' 
                1)add_cust
                2)Show all Customers
                3)update_cust
                4)delete_cust
                5)show_details
                6)exit.....''' )
        choice=int(input("Please enter a no. from above menu as per your requirement: "))
        if choice==1:
            acc_no=int(input("Enter account number: "))
            for x in B.Account:
                if x.acc_no==acc_no:
                    print("This account number is already exist please enter another one")
                    break
            else:
                name=input("Enter name of customer: ")
                balance=int(input("Enter initial deposite: "))
                c1=Customer(acc_no,name,balance)
                B.add_cust(c1)
        
        if choice==2:
            B.show_all_cust()
        
        if choice==3:
            acc_no=int(input("Enter your account number: "))
            balance=int(input("Enter your initial balance: "))
            B.update_cust(balance,acc_no)
        
        if choice==4:
            acc_no=int(input("Enter your account number: "))
            B.delete_cust(acc_no)
        
        if choice==5:
            acc_no=int(input("Enter acc_no of which you want details: "))
            B.show_details(acc_no)
        
        
              

