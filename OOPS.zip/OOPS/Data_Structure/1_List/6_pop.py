marks=[98,86,89,99,74]
print(marks.pop())
print(marks)


#pop with index
# marks=[98,86,89,99,74]
# print(marks.pop(-2))
# print(marks)
