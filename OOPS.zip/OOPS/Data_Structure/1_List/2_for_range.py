marks=[95,85,87,98]
for i in range(4):
    print(marks[i])
print(marks)