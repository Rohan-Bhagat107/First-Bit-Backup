marks=[86,97,95,98]
marks.insert(1,75)
print((marks))