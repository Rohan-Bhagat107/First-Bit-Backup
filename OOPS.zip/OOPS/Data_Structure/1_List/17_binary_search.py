def binary_search(data,n):
    start=0
    end=len(data)-1

    while  (start<=end):
        mid=(start+end)//2

        if data[mid]==n:
            #print(f"{n}  is found at index-> {mid}")
            return True
        
        elif n> data[mid]:
            start=mid+1
        
        elif n< data[mid]:
            end=mid-1
    
    else:
        return False
    
num=[1,5,1,14,19,25,33,50,78,100]
n=int(input("Enter a number that you want to search: "))
res=binary_search(num,n)
if res==True:
    print(f"{n} is found .")

else:
    print(f"{n} is not forund.")
