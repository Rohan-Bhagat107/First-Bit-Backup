class Company():
    def __init__(self):
        self.emp=[]
    
    def add_emp(self,e1):
        self.emp.append(e1)
        
    
    def show_emp(self):
        for x in self.emp:
            print(f"Name of employee is : {x.name} | ID is: {x.id}")
    
    def search_emp_by_id(self,id):
        for x in self.emp:
            if id==x.id:
                print(f"Name of employee is : {x.name} | ID is: {x.id}")
                break
        else:
            print("There is no employee with your entered id:")
    def search_emp_by_name(self,name):
        for x in self.emp:
            if name==x.name:
                print("Employee is found.")
                print("Name:",x.name,"| ID: ",x.id)
                break
        else:
            print("There is no employee with name: ",name)

    
    
    def update_emp(self,id):
        for x in self.emp:
            if id==x.id:
                x.name=input("Enter new name of an employee: ")
                x.id=int(input("Enter new id of an employee: "))
                print(f"Name of employee is : {x.name} | ID is: {x.id}")
                break
        else:
            print("There is no employee with id:",{self.id})
    def delete_emp(self,id):
        for x in range(len(self.emp)):
            if (self.emp[x].id==id):
                index=x
                self.emp.pop(index)
                print("The employees after deleting  are: ")
                c.show_emp()
                break

    
class Employee():
    def __init__(self,id,name):
        self.id=id
        self.name=name

if __name__=="__main__":
    c=Company()

    choice=0
    while choice !=7 :
        print('''            1)Add employee
                2)show emplyee
                3)search employee by ID
                4)update employee
                5)delete employee
                6)Search employee by name
                7)Exit''')

        choice=int(input("Enter your choice: "))
        if choice==1:
            id=int(input("Enter employee ID: "))
            for x in c.emp:
                if id==x.id:
                    print("This ID already exists please enter another ID....")
                    break
            else:
                name=input("Enter name of employee:")
                e1=Employee(id,name)
                c.add_emp(e1)
        
        if choice==2:
            c.show_emp()
        
        if choice==3:
            id=int(input("Enter id of employee that you want to search: "))
            #e1=Employee(id)
            c.search_emp_by_id(id)
        
        if choice==4:
            id =int(input("Enter Id of employee that you want to update: "))
            #e1=Employee(id)
            c.update_emp(id)
        
        if choice==5:
            id=int(input("Enter employee ID that you want to delete: "))
            c.delete_emp(id)
        
        if choice==6:
            name=input("Enter name of employee that you want to search: ")
            c.search_emp_by_name(name)



