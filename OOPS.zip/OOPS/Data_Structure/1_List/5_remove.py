marks=[85,94,79,88]
marks.remove(94)
print(marks)