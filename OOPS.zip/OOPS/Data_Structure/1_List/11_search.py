marks=[98,86,89,99,74]
m=89
if m in marks:
    print(f"{m} is found at index number-  {marks.index(m)}")
else:
    print(f"{m} is not in the list")