marks=[98,86,89,99,74]
print(marks.clear())
print(marks)