list1=[75,98,85,86,95]
list2=[86,95,35,65]
list3=[65,42,35]

list1.extend(list2)
print(list1)
list1.extend(list3)
print(list1)