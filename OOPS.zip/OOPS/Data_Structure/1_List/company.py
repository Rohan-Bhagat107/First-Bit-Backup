from Employee import Employee

class Company():
    def __init__(self):
        self.emp=[]
    
    def add_emp(self,e1):
        self.emp.append(e1)
        
    
    def show_emp(self):
        for x in self.emp:
            print(f"Name of employee is : {x.name} | ID is: {x.id}")
    
    def search_emp_by_id(self,id):
        for x in self.emp:
            if id==x.id:
                print(f"Name of employee is : {x.name} | ID is: {x.id}")
                break
        else:
            print("There is no employee with your entered id:")
    def search_emp_by_name(self,name):
        for x in self.emp:
            if name==x.name:
                print("Employee is found.")
                print("Name:",x.name,"| ID: ",x.id)
                break
        else:
            print("There is no employee with name: ",name)

    
    
    def update_emp(self,id):
        for x in self.emp:
            if id==x.id:
                x.name=input("Enter new name of an employee: ")
                x.id=int(input("Enter new id of an employee: "))
                print(f"Name of employee is : {x.name} | ID is: {x.id}")
                break
        else:
            print("There is no employee with id:",{self.id})
    def delete_emp(self,id):
        for x in range(len(self.emp)):
            if (self.emp[x].id==id):
                index=x
                self.emp.pop(index)
                print("The employees after deleting  are: ")
                c.show_emp()
                break