from tkinter import *
from os import path
from tkinter import messagebox

def clear():
    e1.delete(0,END)
    e2.delete(0,END)
    e3.delete(0,END)

def add():
    id = e1.get()
    name = e2.get()
    sal = e3.get()
    with open ("data.txt","r") as fp:
        data=fp.read()
      
        for i in data:
            b=i.split(",")

            if b[0]==id:
                
                messagebox.showinfo(title="Information",message="This ID already exists.Please enter another ID")
                break
        else:
            emp = id+","+name+","+sal
            list1.insert(END,emp)
            with open("data.txt","a") as fp:
                fp.write(emp+"\n")
    
            clear()
            e1.focus()

    

def select():
            clear()
            e = list1.get(ACTIVE)
            print(e)
            emp =e.split(",")
            print(emp)
            e1.insert(0, emp[0])
            e2.insert(0, emp[1])
            e3.insert(0, emp[2])
            t=list1.curselection()
            index.set(t[0])
            
def delete():
    list1.delete(ACTIVE)

def update():
    list1.delete(ACTIVE)
    id=e1.get()
    name=e2.get()
    salary=e3.get()
    emp=id+" "+name+" "+salary
    list1.insert(index.get(),emp)



wind = Tk()
f1 = Frame(wind)
f2= Frame(wind)
f3= Frame(wind)
index=IntVar()

l1 = Label(f1, text="Enter id")
e1= Entry(f1)
l2 = Label(f1, text="Enter Name")
e2= Entry(f1)
l3 = Label(f1, text="Enter Salary")
e3= Entry(f1)

btn1= Button(f2,text="Add",command=add)
btn2= Button(f2,text="Select",command=select)
btn3= Button(f2,text="Update",command=update)
btn4= Button(f2,text="Delete",command=delete)

list1 = Listbox(f3)

l1.grid(row=1,column=1,pady=10)
e1.grid(row=1,column=2,pady=10)
l2.grid(row=2,column=1,pady=10)
e2.grid(row=2,column=2,pady=10)
l3.grid(row=3,column=1,pady=10)
e3.grid(row=3,column=2,pady=10)

f1.pack(pady=20)

btn1.pack(side=LEFT,padx=10)
btn2.pack(side=LEFT,padx=10)
btn3.pack(side=LEFT,padx=10)
btn4.pack(side=LEFT,padx=10)

f2.pack(pady=30)

list1.pack()
f3.pack()

if(path.exists("data.txt")):
    with open("data.txt", "r") as fp:
        for i in fp:
            print(i,"\n")
           
            list1.insert(END,i)

wind.mainloop()