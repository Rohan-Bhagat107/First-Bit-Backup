marks=[]
count=0
sum=0
for a in range(1,6):
    m=int(input("Enter marks obtained: "))
    marks.append(m)
    sum+=m
    count+=1
    if count==5:
        break
    
print(marks)
print(sum/count)
    
