class Ageerror(Exception):
    def __str__(self):
        return (f"You are not eligible to vote")