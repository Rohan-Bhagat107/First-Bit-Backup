import pickle

class student():
    def __init__(self,roll,name,marks):
        self.roll=roll
        self.name=name
        self.marks=marks
    
    def __str__(self):
        return f"Roll: {self.roll} | Name: {self.name} | Marks: {self.marks}"

s=student(101,"Rohan",95)

def write_data():
    with open("student.xyz","wb") as fp:
        pickle.dump(s,fp)
        print("Data Saved!")

def read_data():
    with open("student.xyz","rb") as fp:
        d=pickle.load(fp)
        print(d)
        print(type(d))
       
    
write_data()
read_data()
