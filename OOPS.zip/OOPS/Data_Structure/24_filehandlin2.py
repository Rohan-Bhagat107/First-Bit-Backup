#open the file
f=open("User_input.txt", "r")

data=f.read()

f.close()

print(data)
print("Data retrived succesfully")