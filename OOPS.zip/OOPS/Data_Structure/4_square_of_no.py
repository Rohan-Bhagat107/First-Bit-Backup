#WAP to create a new list out of existing list that has squares of all members of the existing list

n=int(input("How many number are there: "))
numbers=[]
count=0

for i in range(1,n+1):
    no=int(input("Enter a number: "))
    numbers.append(no)
    count+=1
print(numbers)

square=[]
for i in numbers:
    square.append(i*i)

print(square)
    


