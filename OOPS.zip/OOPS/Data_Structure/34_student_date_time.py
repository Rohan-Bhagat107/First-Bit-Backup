import datetime as dt
class student():
    def __init__(self,roll,name,day,month,year):
        self.roll=roll
        self.name=name
        self.dob=dt.date(year,month,day)
    
    def __str__(self):
        return f"Roll: {self.roll} | Name: {self.name} | DOB: {self.dob.day}/{self.dob.month}/{self.dob.year}"
s1=student(101,"Rohan",10,6,2001)
s2=student(102,"Kshitij",10,8,2001)
print(s1)
print(s2)
    