while True:
    try:
        a=int(input("Enter 1st number: "))
    except ValueError as v:
        print(v)
        print("Invalid Integer value")
    else:
        break

while True:
    try:
        b=int(input("Enter 2nd number: "))
        print(f" Division of a and b is: {a/b}")
    except ValueError as x:
        print(x)
        print("Invalid Integer value")
    except ZeroDivisionError as z:
        print(z)
        print("Division with zero is not possible")
    else:
        break