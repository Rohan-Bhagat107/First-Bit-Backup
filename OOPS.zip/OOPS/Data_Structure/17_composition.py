class date_of_joining():
    def __init__(self,dd,mm,yyyy):
        self.date=dd
        self.month=mm
        self.year=yyyy
    
    def __str__(self):
        return (f"{self.date}-{self.month}-{self.year}")

class Employee():
    def __init__(self,name,Doj,salary):
        self.name=name 
        self.Doj=Doj
        self.salary=salary

    def __str__(self):
        return (f"Name: {self.name} | Doj: {self.Doj} | Salary: {self.salary}")

d=date_of_joining(12,3,2021)
e=Employee("Rohan",d,45000)
print(e)




# class date_joining():
#     def __init__(self,day,month,year):
#         self.day=day
#         self.month=month
#         self.year=year
    
#     def __str__(self):
#         return f"{self.day}-{self.month}-{self.year}"
    
# class Employee():
#     def __init__(self,Name,DOJ,Salary):
#         self.Name=Name
#         self.doj=DOJ
#         self.salary=Salary
#     def __str__(self):
#         return f"Name:{self.Name} | Joining Date:{self.doj} | Salary:{self.salary}"


# date=date_joining(12,11,2000)
# Emp=Employee("Rohan",date,50000)
# print(Emp)