#check how many times each element of list a occurs in it

a=[10,20,30,15,20,10,17,12]
b=[]

for x in a:
    if x not in b:
        b.append(x)
print(b)

for x in b:
    print(x,"->",a.count(x))



## Without using inbuilt

# for i in a:
#     if i not in b:
#         b.append(i)

# for x in b:
#     count=0
#     for y in a:
#         if x==y:
#             count+=1
#     else:
#         print(x,"->",count)
    