#whenever there is "yield " keywordd in a function then it will return a "generator" object


import random
def getdata(n):
    for i in range(n):
        yield random.randint(1000,9999)
        #a.append(random.randint(1000,9999))

# n=getdata(5)
for i in range(1,7):
    print(next(getdata(i)))
