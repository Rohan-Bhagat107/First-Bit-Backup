from employee_file_handling import Emp

class EmpMgmt():
    def __init__(self):
        self.emp=[]
    
    def display(self):
        fp=open("Empmgmt.txt","r")
        data=fp.read()
        print(data)
        fp.close()
    def Add_emp(self,e):
        fp=open("Empmgmt.txt","a")
        fp.write(str(e))
        fp.close()
    
    def search_emp(self,id):
        fp=open("Empmgmt.txt","r")
        for  i in fp:
            i.split(",")
            if int(i[0])==id:
                print("Employee if found whose details are: ")
                print(i)
                break
        else:
            print(f"There is no employee with {id} ID")
        fp.close()
    
    def delete_emp(self,id):
        self.emp.clear()
        fp=open("Empmgmt.txt","r")
        for x in fp:
            
            self.emp.append(x)
        fp.close()

        fp=open("Empmgmt.txt","w")
        found=False
        for i in self.emp:
            i.split(",")
            if int(i[0]) !=id:
                fp.write(i)
            else:
                found=True
        fp.close()
        return found
    def update_emp(self,id):
        self.emp.clear()
        fp=open("Empmgmt.txt","r")
        for x in fp:
            
            self.emp.append(x)
        fp.close()
        
        for i in range(len(self.emp)):
            if int(self.emp[i].split(",")[0])==id:
                n=input("Enter new name:  ")
                s=int(input("Enter new salary: "))
                newrecord=f"{id},{n},{s}\n"
                self.emp[i]=newrecord
                break
        print("Employee Updated succesfully...")
        print(self.emp)
        fp.close()
    
                


em=EmpMgmt()

while True:
    print('''
           1)Display all employees
           2)Add employee
           3)search employee
           4)delete employee
           5)update employee
           6)exit''')
    choice=int(input("Enter a number from above menu as per your requirement: "))
    if choice==6:
        break
    elif choice==1:
        em.display()
    elif choice==2:
        id=int(input("Enter ID of an employee: "))
        name=input("Enter name of an employee: ")
        salary=int(input("Enter salary: "))
        e=Emp(id,name,salary)
        em.Add_emp(e)
        print("Employee Added succesfully")
    elif choice==3:
        id=int(input("Enter ID of an employee that you want to search: "))
        em.search_emp(id)
        
    elif choice==4:
        id=int(input("Enter ID of an employee that you want to delete: "))
        res=em.delete_emp(id)
        if res==True:
            print("Employee deleted succesfully ")
    
        else:
            print(f"There is no employee with {id} ID")
    elif choice==5:
        id=int(input("Enter ID of an employee that you want to update: "))
        em.update_emp(id)



           
    