try:
    a=int(input("Enter a number:"))
    b=int(input("Enter a number: "))
except:
    print("Please pass integer value ")

else:
    sum=a+b
    print(sum)


# print(1)
# try:
#     print(hello)
# except:
#     print("There is an error.")
# print(2)
# print(3)

# try:
#     a=int(input("Enter a number:"))
#     b=int(input("Enter a number: "))
# except:
#     print("Please pass integer value. ")

# else:
#     div=a/b
#     print(div)

try:
    a=int(input("Enter a number:"))
    b=int(input("Enter a number: "))
except ValueError:   #specialized handler
    print("Please pass numeric value ")
except ZeroDivisionError:  #specialized handler
    print("Please pass non_zero value for denomintor: ")
except :  #generalized handler
    print("Please pass integer value ")
else:
    sum=a+b
    print(sum)
