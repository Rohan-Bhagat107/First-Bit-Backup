from tkinter import *
window=Tk()
def add():
    n1=int(e1.get())
    n2=int(e2.get())

    a=n1+n2
    
    e1.delete(0,END)
    e2.delete(0,END)
    e3.delete(0,END)

    # e1.insert(0,n1)
    # e2.insert(0,n2)
    e3.insert(0,a)
    
window.geometry("300x500")

l1=Label(text="Enter first number")
e1=Entry()
l2=Label(text="Enter second number")
e2=Entry()
btn=Button(text="Add",command=add)

l3=Label(text="Result")
e3=Entry()
l1.grid(row=1,column=1)
e1.grid(row=1,column=2)
l2.grid(row=2,column=1)
e2.grid(row=2,column=2)
btn.grid(row=3,column=2)
l3.grid(row=4,column=1)
e3.grid(row=4,column=2)
window.mainloop()

# from tkinter import *
# wind=Tk()
# def add():
#     n1=int(e1.get())
#     n2=int(e2.get())
#     a=n1+n2

#     e1.delete(0,END)
#     e2.delete(0,END)
#     e3.delete(0,END)

#     e1.insert(0,n1)
#     e2.insert(0,n2)
#     e3.insert(0,a)


# l1=Label(text="Enter 1st number: ")
# e1=Entry()
# l2=Label("Enter 2nd number: ")
# e2=Entry()
# btn=Button(text="Add",command=add)
# l3=Label(text="Result")
# e3=Entry()

# l1.grid(row=1,column=1)
# e1.grid(row=1,column=2)
# l2.grid(row=2,column=1)
# e2.grid(row=2,column=2)
# btn.grid(row=3,column=2)
# l3.grid(row=4,column=1)
# e3.grid(row=4,column=2)


# wind.mainloop()