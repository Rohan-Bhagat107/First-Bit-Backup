while True:
    try:
        a=int(input("Enter a number: "))
        b=int(input("Enter a number: "))
        print(f" Division of a and b is: {a/b}")
    except ValueError:
        print("Invalid Integer value")
    except ZeroDivisionError:
        print("Division with zero is not possible")
    else:
        break