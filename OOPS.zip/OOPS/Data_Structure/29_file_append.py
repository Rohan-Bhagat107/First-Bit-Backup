fp=open("Abc.txt","a")
fp.write("\nThis is append mode")
fp.close()