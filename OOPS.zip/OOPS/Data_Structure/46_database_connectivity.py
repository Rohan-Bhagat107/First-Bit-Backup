import mysql.connector

mydb=mysql.connector.connect(host="localhost",user="root",password="Pass@123",database="class")
cur=mydb.cursor()
str=''' select * from book '''

cur.execute(str)
record=cur.fetchall()
for i in record:
    print(i)
mydb.close()