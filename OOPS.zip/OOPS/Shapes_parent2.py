#parent class of- (45_child_parent2)

from abc import ABC,abstractmethod
class Shapes(ABC):
    @abstractmethod
    def draw():
        pass

    @abstractmethod
    def paint():
        pass
    