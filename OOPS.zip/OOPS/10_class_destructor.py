class Product():
    def __init__(self,id,name,price):
        self.id=id
        self.name=name
        self.price=price
    def __del__(self):
        print("Uninitializing....")

p=Product(1,"Shirt",999)
print(p.id)
print(p.name)
print(p.price)
print("Thanks!")



