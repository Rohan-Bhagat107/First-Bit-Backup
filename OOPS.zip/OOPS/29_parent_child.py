class Shapes():
    def Displays(self):
        print("This is parent class")
    
class Square(Shapes):
    def Display(self):
        print("This is child class")


s1=Shapes()
s1.Display()

# sq=Square()
# sq.Display()