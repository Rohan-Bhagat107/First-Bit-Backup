from Shapes_parent2 import Shapes
class Rectangle(Shapes):
    def __init__(self,length,breadth,colour):
        self.length=length
        self.breadth=breadth
        self.colour=colour

    def draw(self):
        print(f"Drawing rectangle with length {self.length} unit and breadth of {self.breadth} unit")
    
    def paint(self):
        print(f"Painting rectangle with length {self.length} unit and breadth of {self.breadth} unit with {self.colour} colour")


class    Circle(Shapes):
    def __init__(self,radius,colour):
        self.radius=radius
        self.colour=colour
    
    def draw(self):
        print(f"Drawing circle with radus {self.radius} unit")
    
    def paint(self):
        print(f"Painting circle with radius {self.radius} unit with {self.colour} colour")

r1=Rectangle(2,3,"Red")
c1=Circle(2,"Blue")
r1.draw()
r1.paint()
print("------------------------------------------")
c1.draw()
c1.paint()

