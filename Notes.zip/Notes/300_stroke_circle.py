from turtle import *
radius=200
width=20
t=Turtle()
t.shape("turtle")
t.color("red","green")
screen=Screen()
screen.bgcolor("pink")
t.width(10)
t.penup()
t.goto(0,-radius)
t.pendown()
t.circle(radius
)

done()