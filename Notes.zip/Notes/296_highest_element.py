data=[2,8,6,93,8,7]
for i in range(len(data)):
    for j in range(i+1,len(data)):
        if data[i]>data[j]:
            data[i],data[j]=data[j],data[i]
print(data)
print(data[-1])
print(data[-2])
print(data[0])
print(data[2])