def is_palindrome(num):
    return str(num)==str(num)[::-1]

def next_palindrom(num):
    if is_palindrome(num+1):
        return num+1
    else:
        return next_palindrom(num+1)

print(next_palindrom(121))

# def rev_no(no,rev=0):
#     if no==0:
#         return rev
#     else:
#         return rev_no(no//10,10*rev+no%10)
# n=int(input("Enter range in which you want palindromes: "))
# palindrome=[]
# for i in range(11,n+1):
#     result=rev_no(i)
    
#     if (result)==i:
    
#         palindrome.append(i)
#     else:
#         continue
# print(palindrome)



