sentence="a brown fox jumps over the lazy dog"

count=1
for i in sentence:
    print(i)
    if i==" ":
        count+=1
print(count)


 #          OR

 
# word_list=sentence.split(" ")
# print(word_list)
# for i in word_list:
#     if i=="":
#         word_list.remove("")

#     else:
#         count+=1
# print((word_list))
# print(count)