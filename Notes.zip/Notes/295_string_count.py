
word="a brown fox jumps over the lazy dog"
dict1={}
for i in word:
    count=0
    for j in word: 
        if i==" ":
            continue
        elif i==j:
            count+=1
    dict1[i]=count
print(dict1)

