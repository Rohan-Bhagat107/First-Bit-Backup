data=[2,8,9,6,12]
data2=[2,7,9,12,6]

for i in data:
    if i in data2:
        continue
    else:
        print(i)