from turtle import *

t=Turtle()
t.color("red","green")
t.shape("turtle")
screen=Screen()
screen.bgcolor("pink")
screen.title(
    'My turle'
)

t.forward(100)
t.left(90)
t.forward(200)
t.left(90)
t.forward(100)
t.left(90)
t.forward(200)
t.speed(10)
done()