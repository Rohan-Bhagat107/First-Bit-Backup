#WAP to print sum of series using function 1!+2!+3!...........n!

#with para with return
def factorial(no):                   #function defination

    sum=0
    for i in range(1,no+1):
        fact=1
        for j in range(1,i+1):
            fact*=j
        sum+=fact
    return sum 


a=int(input("Enter a number upto which you want the sum: "))
res=factorial(a)                     #function calling
print("Sum of series upto",a,"is: ",res)