#fun with no parameter and with return value

def factorial():
    no=int(input("Enter a number: "))
    fact=1
    for i in range(no,0,-1):
        fact*=i
    return fact
    
x=factorial()    
print(x)