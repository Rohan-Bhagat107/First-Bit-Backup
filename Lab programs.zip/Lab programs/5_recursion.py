#WAp to print fibonacci series upto "n" terms


def fibonacci_series(n,a,b):
    
    if n==0:
        return
    else:
        c=a+b
        print(c)
        return fibonacci_series(n-1,b,c)


terms=int(input("Enter how many fibo terms you want: "))
res=fibonacci_series(terms,0,1)
