class Employee():
    def __init__(self,id,name,department,salary):
        self.id=id
        self.name=name
        self.department=department
        self.salary=salary
    
    def display_data(self):
        print("Name of employee is",self.name,"from department",self.department,"with salary",self.salary)

e1=Employee(1,"Rohan","IT",48000)
e2=Employee(2,"Kshitij","IT",45000)
e3=Employee(3,"Praful","IT",43000)
e4=Employee(4,"Tushar","IT",40000)

e1.display_data()
e2.display_data()
e3.display_data()
e4.display_data()

        
   