#function with  parameter and return value

def add_num(n):
    sum=0
    for i in range(1,n+1):
        sum+=i
    return sum

x=int(input("Enter number upto which you want sum: "))
y=add_num(x)
print(y)