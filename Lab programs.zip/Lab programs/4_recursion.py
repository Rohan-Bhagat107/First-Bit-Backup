#WAp to print sum of digits of a given number using recursion.

def digit_sum(n):
    if n==0:
        return 0
    else:
        digit=n%10
    return digit+digit_sum(n//10)

no=int(input("Enter a number: "))
res=digit_sum(no)
print("Sum of digits of",no,"is: ",res)
    