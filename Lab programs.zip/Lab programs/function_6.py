#function with no parameter and  with return value

def add_num():
    sum=0
    n=int(input("Enter number upto which you want sum: "))
    for i in range(1,n+1):
        sum+=i
    return sum

x=add_num()
print(x)

