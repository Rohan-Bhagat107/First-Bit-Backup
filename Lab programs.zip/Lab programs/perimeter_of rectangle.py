# date=20-12-23

length=int(input("Enter length of rectangle"))
breadth=int(input("Enter breadth of rectangle"))
perimeter=2*length*breadth
print("perimeter of rectangle is: ",perimeter)