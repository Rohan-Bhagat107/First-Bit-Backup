#fun with parameter and no return

def is_prime(no):
    for i in range(2,no):
        if no%i==0:
            print("Not prime no.")
            break
    else:
        print("It is a prime no.")

is_prime(6)