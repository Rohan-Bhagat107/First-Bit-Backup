#WAP to print sum of series a+a**2/2+a**3/3+a**4/4...a**10/10

def series_sum():                      #function defination
    a=int(input("Enter a number: "))
    sum=0
    for i in range(1,11):
        sum+=(a**i)/i
    print("Sum of series is: ",int(sum))

series_sum()                   #function calling