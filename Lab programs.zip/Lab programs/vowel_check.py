# Author=Rohan
# Date=26-12-23

alphabet=input("Please enter any alphabet in lowercase: ")
if alphabet=="a" or alphabet=="e"  or alphabet=="i" or  alphabet=="o"or alphabet=="u" :
    print("It is a vowel")
else:
    print("It is a consonent")