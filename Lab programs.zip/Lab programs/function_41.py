#check if a given no. is prime or not using function

def prime_number(n):

    
    for i in range(2,n):
        if n%i==0:
            return False
    else:
        return True

n=int(input("enter a number: "))
res=prime_number(n)
if res==True:
    print(n,"is a prime number.")
else:
    print(n,"is not a prime number.")

