def school(roll_no,name,marks=100):
 print(name,roll_no,marks)   
school(name="Rohan",marks=95,roll_no=5)