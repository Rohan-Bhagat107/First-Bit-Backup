#WAP to print snake -ladder pattern

for i in range(10,0,-1):
    x=i*10
    for j in range(0,10):
        if i==1:
            print(x-j,end="  ")
        else:

            print(x-j,end=" ")
         
    print()

