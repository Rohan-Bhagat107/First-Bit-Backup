# Author=Rohan
# Date=23-12-23


#Calculate sum of digits of three digit no.

first_no=int(input("Please enter 1st no.: "))
second_no=int(input("Please enter 2nd no.: "))
third_no=int(input("Please enter 3rd no.: "))

