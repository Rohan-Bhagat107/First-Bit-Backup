# Author=Rohan 
# Date=30-12-23

#print all numbers that are divisible  and not divisible by 3

for x in range(1,7,1):
    if x%3==0:
        print(x,"is divisible by 3.")
    else:
        print(x,"is not divisible by 3.")