# 5 4 3 2 1 
# 5 4 3 2 1
# 5 4 3 2 1
# 5 4 3 2 1
for i in range(1,5):
    for j in range(5,0,-1):
        print(j,end=" ")
    print()