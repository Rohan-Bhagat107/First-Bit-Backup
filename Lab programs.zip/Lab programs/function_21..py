#function with no parameter but with return
#WAP to check   Palindrome

def get_palindrome():
    no=int(input("Enter a number: "))
    rev=0
    org_no=no
    while no!=0:
        rev=rev*10+no%10
        no=no//10
    if rev==org_no:
        return "It is palindrome."
    else:
        return"Not a plindrome"

x=get_palindrome()
print(x)
