#WAP to print sum of even numbers from 1 to n using function

def sum_of_even(n):                 #function defination
    
    sum=0
    for i in range(1,n+1):
        if i%2==0:
            sum+=i     
    return sum

n=int(input("Enter a number upto which you want the sum: "))
res=sum_of_even(n)                         #function calling
print("sum of odd numbers from 1 to",n,"is: ",res)