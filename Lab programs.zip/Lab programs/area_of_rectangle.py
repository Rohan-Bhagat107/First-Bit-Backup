#Author = Rohan
# Date=20-12-23

length=int(input("Enter length of rectangle"))
breadth=int(input("Enter breadth of rectangle"))
area=length* breadth
print("Area of rectangle is: ",area,"units")