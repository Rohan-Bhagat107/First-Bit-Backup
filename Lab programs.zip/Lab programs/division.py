a=int(input("Enter 1st no."))
b=int(input("Eter 2nd no."))
c=int(input("Enter 3rd no."))
d=a+b+c/3
print(d)
