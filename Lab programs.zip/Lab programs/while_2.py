#print first 50 prime numbers


count=0
#while:
for i in range(2,500):
      for x in range(2,500):
       if i%x==0:
         #print("No. is not  prime.")
         break

else:
   print()
        