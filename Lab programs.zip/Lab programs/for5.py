#print odd numbers from 6 to 20

for x in range(6,21,1):
    if x%2==1:
        print(x)