#function with no parameter and with return value

def square():
    no=int(input("enter a number: "))
    c=no**2
    return c


x=square()
print("Sq. of given number is: ",x)