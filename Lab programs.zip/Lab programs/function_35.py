#WAP to print geometric series sum from 1 to n whre  common ratio is 2 using function

def geometric_series():             #function defination
    a=int(input("Enter a number: "))
    n=int(input("Enter a number:"))
    ratio=2
    sum=0
    for i in range(1,n+1):
        sum+=i*ratio
    print("Sum of series is: ",sum)

geometric_series()                      #function calling
