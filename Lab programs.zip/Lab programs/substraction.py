Author=Rohan
date=19-12-23
a=int(input("Enter 1st no."))
b=int(input("Enter 2nd no."))
print(a-b)

