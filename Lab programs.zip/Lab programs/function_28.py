def prime(no):
    for i in range(2,no):
        if no/i==0:
          return False
        break
            
    else:
        return True
    
a=int(input("Enter a number: "))
res=prime(a)
if res==True:
    print(a,"is a prime number.")
else:
    print(a,"is not a prime number.")