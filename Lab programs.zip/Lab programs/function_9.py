#function with no parameter and return value
def square():
    no=int(input("Enter a number: "))
    c=no**2
    return c

x=square()
print("Sq. of a given number is: ",x)



