#print even numbers from 1 to 10

for x in range(1,11,1):
    
    if x%2==0:
        print(x)
    