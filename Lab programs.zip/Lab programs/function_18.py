#function with parameter and with return

def is_prime(no):
    
    for i in range(2,no):
        if no%i==0:
            return False
    else:
        return True

no=int(input("Enter a number."))
x=is_prime(no)
if x==False:
    print("Not prime number")
else:
    print("It is prime number")
