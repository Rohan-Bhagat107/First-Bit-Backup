def fact(n):
    if n==0:
        return 1
    else:
        return n*fact(n-1)
    

no=int(input("Enter a number of which you want the factorial: "))
res=fact(no)
print("Factorial of",no,"is: ",res)