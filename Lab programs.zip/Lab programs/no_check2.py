# Author=Rohan
# Date=26-12-23

# W.A.P to check if a no. is +ve , -ve or zero

no=int(input("Please enter any no.: "))
if no>0:
    print("No. is positive.")
elif no<0:
    print("No. is negitive.")
else:
    print("No. is zero.")