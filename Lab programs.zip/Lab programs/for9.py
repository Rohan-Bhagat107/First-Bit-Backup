#find sum of umbers from 5 to 16


count=0
for x in range(5,17,1):
    count+=x
print("Sum of numbers from 5 to 16 is:",count)
