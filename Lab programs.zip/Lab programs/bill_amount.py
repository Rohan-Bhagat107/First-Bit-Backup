# Author = Rohan
# Date=21-12-23
# task-
# calculate bill amount after purchase of chocolate & biscuit .take input of price & quantity from user

no_of_chocolate=int(input("Enter no. of chocolate purchased : "))
price_of_one_chocolate=int(input("Enter price of  one chocolate  : "))
no_of_biscuit=int(input("Enter no. of biscuit purchased : "))
price_of_one_biscuit=int(input("Enter price of  one biscuit : "))
total=int(no_of_chocolate*price_of_one_chocolate)+(no_of_biscuit*price_of_one_biscuit)

print("Total amount to be paid by customer is: ",total,"/-")