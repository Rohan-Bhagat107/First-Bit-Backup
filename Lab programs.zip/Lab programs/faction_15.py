#fun with parameter and with return

def square(no):
    fact=1
    for i in range(no,0,-1):
        fact*=i
    return fact

x=square(5)
print("factorial of number is: ",x)