class Employee():
    def __init__(self,id,name,salary):
        self.id=id
        self.name=name
        self.salary=salary
    def display_data(self):
        print("Name of employee is",self.name,"with salary",self.salary)

eid=int(input("Enter id of an empmloyee: "))
name=input("Enter name of an employee: ")
salary=int(input("Enter salary of that employee: "))
e1=Employee(eid,name,salary)
e1.display_data()