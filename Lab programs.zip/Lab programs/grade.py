# Author=Rohan
# Date=26-12-23
                          #elif Problem

# take user input of marks of 5 subjects & calculate percentage also give grade as given below-
#     percentage>95===1st division
#     percentage>80 == 2nd Division
#     percentage>65 == 3rd division 
#     percentage<65 ==4th 


# a=int(input("Please enter marks of 1st sub:"))
# b=int(input("Please enter marks of 2nd sub:"))
# c=int(input("Please enter marks of 3rd sub:"))
# d=int(input("Please enter marks of 4th sub:"))
# e=int(input("Please enter marks of 5th sub:"))
# g=int(input("Please enter total marks:"))

percentage=int(input("Enter percentage: "))

if percentage>=95 and percentage<=100:
    print("1st Division")
elif percentage<95 and percentage>=80:
 print("2nd division")
elif percentage<80 and percentage>=65:
      print("3rd division")
elif percentage<65 and percentage>=40:
     print("4th division")
else:
     print("fail")





