n=int(input("Please enter how many fibonacci numbers you have to print: "))
a=1
b=0

for x in range(n):
    c=a+b
    print(c)
    a=b
    b=c