#WAP to print sum of series upto n using function
#1+2+3+4..........n

#with para with return
def sum(no):                     #function defination
    sum=0
    for i in range(1,no+1):
        sum+=i
    return sum

a=int(input("Enter a number upto which you want the sum: "))
res=sum(a)
print("Sum of series upto",a,"is: ",res)


#with para without return

# def sum(no):
    
#     sum=0
#     for i in range(1,no+1):
#         sum+=i
#     print("Sum of series upto",a,"is: ",sum)

# a=int(input("Enter a number upto which you want the sum: "))
# sum(a)



# #without para but with return

# def sum():
#     no=int(input("Enter a number upto which you want the sum: "))
#     sum=0
#     for i in range(1,no+1):
#         sum+=i
#     return sum


# res=sum()
# print("Sum of series upto",a,"is: ",res)



# #with no para and no return
# def sum():
#     no=int(input("Enter a number upto which you want the sum: "))
#     sum=0
#     for i in range(1,no+1):
#         sum+=i
#     print("Sum of series upto",a,"is: ",res)


# sum()






