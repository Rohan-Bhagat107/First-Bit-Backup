#find sum of numbers from 1 to 10
count=0
for i in range(1,11,1):
    count+=i
print("Sum of numbers from 1 to 10 is: ",count)