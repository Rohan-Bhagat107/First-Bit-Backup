print("Hello world")

