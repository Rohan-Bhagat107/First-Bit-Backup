#WAP to check if a given number is a perfect square or not

def perfect_square():
    n=int(input("Enter a number that you  want to check: "))
    for i in range(1,n//2):
        if i*i==n:
            print(n,"is a perfect square.")
            break
    else:
        print(n,"is not a perfect square.")

perfect_square()
