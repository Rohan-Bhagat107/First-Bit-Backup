#WAP to find 2^5 using recursion.

def power_calculator(a):
    
    if a==1:
        return 2
    else:
         return  no*power_calculator(a-1)
   
a=int(input("Enter the power: "))
no=int(input("Enter a number: "))
res=power_calculator(a)
print(a,"power of 2 is",res)