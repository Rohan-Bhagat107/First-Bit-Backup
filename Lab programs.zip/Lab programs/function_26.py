def mult(a,b):
     c=a*b
     return c

x=int(input("Enter a  number: "))
y=int(input("Enter a  number: "))
res=mult(x,y)
print("Sum is: ",res)