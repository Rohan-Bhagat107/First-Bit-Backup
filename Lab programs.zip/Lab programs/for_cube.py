# Author=Rohan 
# date=30-12-23

for x in range(6,12,1):
    print(x**3)