#find factorial of a number

n=int(input("Enter number that you want to factorised: "))
for i in range(1,n,1):
    print("Factorial of are",n*i-1)