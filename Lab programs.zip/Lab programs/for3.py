#print cube of numbers from 6 to 13

for n in range(6,14,1):
    print(n,"x",n,"x",n,"=",n*n*n)