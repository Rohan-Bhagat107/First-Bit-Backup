#WAP to find  pth power of n using recursion

def power(n,p):
    if p==1:
        return n
    else:
        return n*power(n,p-1)

no=int(input("Enter a number: "))
p=int(input("Enter power of that number:"))
res=power(no,p)
print(p,"th power of",no,"is: ",res)