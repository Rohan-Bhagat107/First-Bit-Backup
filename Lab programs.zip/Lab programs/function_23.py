#a function is_armstrong()
def is_armstrong():
    num=int(input("Enter a number: "))
    org_no=num
    count=0
    while num!=0:
        d=num%10
        num=num//10
        count+=1

    num=org_no
    sum=0
    while num!=0:
        x=num%10
        num=num//10
        power=x**count
        sum+=power

    if sum==org_no:
        print(org_no,"is an armstrong number.")
    else:
        print(org_no,"is not a armstrong number.")

is_armstrong()


