#WAP to print the su of series upto n  1^1+2^2+3^3......n^n
def sum(n):               #function defination
   
    sum=0
    for i in range(1,n+1):
        sum+=i**i
    return sum

a=int(input("Enter a number upto which you want the sum: "))
res=sum(a)                                       #function calling
print("Sum of series upto",a,"is: ",res)