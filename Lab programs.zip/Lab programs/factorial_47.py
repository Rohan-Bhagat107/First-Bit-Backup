#wap t find factorial of given number
fact=1
n=int(input("Enter number of which you have to find factorial:  "))
for i in range(n,0,-1):
    fact*=i
print("Factorial of",n,"is: ",fact)
