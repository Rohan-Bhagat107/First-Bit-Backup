#WAP to print sum of all prime numbers from 1 to n

def sum_of_prime(n):
    sum=0
    for i in range(2,n+1):
        for j in range(2,i):
            if i%j==0:
                break
        else:
         sum+=i
    print("Sum of prime numbers from 1 to",n,"is: ",sum)


n=int(input("Enter a number upto which you want the sum of prime numbers: "))
sum_of_prime(n)