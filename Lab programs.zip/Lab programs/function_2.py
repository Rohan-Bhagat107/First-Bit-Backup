#WA function to add two numbers which accept 2 parameters and display their sum


def add(n1,n2):
    print("sum is:",n1+n2)
add(2,3)

#WA function to accept two numbers from user  and display their sum
n1=int(input("ENter first number:"))
n2=int(input("ENter second number:"))
def add(n1,n2):
    print("sum is:",n1+n2)
add(n1,n2)


