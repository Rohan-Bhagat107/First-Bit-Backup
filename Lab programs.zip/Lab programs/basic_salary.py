# Author=Rohan
# Date=26-12-23

# Enter basic salar of employee.If salary>=10000 then hra=10% of basic ,bonus=6000 otherwise hra=1200,ta=4000,bonus=5000.print total salary of employee

ta=0
basic_salary=int(input("Please enter your basic salary: "))  #it is in INR
if basic_salary>=10000:
    hra=basic_salary*10/100   #it is in %
    bonus=6000             #it is in INR

elif basic_salary<10000 :
     hra=1200                #it is in INR
     ta=4000                  #it is in INR
     bonus=5000           #it is in INR
else:
     print("Invalid Amount ")
total_salary=basic_salary+hra+ta+bonus            #it is in INR   
print("Your total salary is: ",int(total_salary),"INR")
