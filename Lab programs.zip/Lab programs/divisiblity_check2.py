# Author=Rohan
# Date=26-12-23

#task-
  #take a no. from user &  print "Divisible" if it is divisible by either 5 or 7.


no=int(input("Please enter any no.: "))
if no%5==0 or no%7==0:
    print("The number you enterd is divisible ")
else:
    print("Not divisible either by 5 or 7")