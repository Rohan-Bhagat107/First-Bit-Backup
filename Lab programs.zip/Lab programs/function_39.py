#WAP to print sum of odd numbers from 1 to n using function


#With para  with return
def sum_of_odd(n):                 #function defination
    
    sum=0
    for i in range(1,n+1):
        if i%2==0:
            continue
        else:
            sum+=i
    return sum

n=int(input("Enter a number upto which you want the sum: "))
res=sum_of_odd(n)                         #function calling
print("sum of odd numbers from 1 to",n,"is: ",res)

#With para without return

# def sum(n):              #function defination
    
#     sum=0
#     for i in range(1,n+1):
#         if i%2==0:
#             continue
#         else:
#             sum+=i
#     print("sum of odd numbers from 1 to",n,"is: ",sum)

# n=int(input("Enter a number upto which you want the sum: "))
# sum(n)                         #function calling


#Without para but with return
# def sum():           #function defination
#     n=int(input("Enter a number upto which you want the sum: "))
#     sum=0
#     for i in range(1,n+1):
#         if i%2==0:
#             continue
#         else:
#             sum+=i
#     return sum


# res=sum()            #function calling
# print("sum of odd numbers from 1 to n is: ",res)


#without parameter and wtihout return
# def sum():            #function defination
#     n=int(input("Enter a number upto which you want the sum: "))

#     sum=0
#     for i in range(1,n+1):
#         if i%2==0:
#             continue
#         else:
#             sum+=i
#     print("sum of odd numbers from 1 to",n,"is: ",res)

# sum()         #function calling
