#Author = Rohan
# Date=21-12-23
# task-
#calculate simple interest 

amt_invested=int(input("Please enter amount that you have to invest : ")) #It is in INR
rate=int(input("Please enter rate of interest : ")) #it is in %
time=int(input("please enter time duration of investment : ")) #it is in year
si=int(amt_invested*rate*time/100)
print("Simple interest on your investment after",time,"year","is : ",si,"INR")