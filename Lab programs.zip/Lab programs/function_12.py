#function with no parameter  and no return
def factorial():
    fact=1
    for i in range(5,0,-1):
        fact*=i
    print("Factorial of given number is: ",fact)

factorial()