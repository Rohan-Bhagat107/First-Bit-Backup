# Write a function-factorial(.....)
# which returns the factorial of a number passed


def factorial(no):
 fact=1
 for i in range(no,0,-1):
    fact*=i
 print("factorial is: ",fact)

factorial(5)
