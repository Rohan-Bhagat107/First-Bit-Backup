#WAP to calculate area of rectangle

#with para with return
def area(l,b):
    area=l*b
    return area

length=int(input("Enter  length of a rectangle: "))
breadth=int(input("Enter  breadth of a rectangle: "))
res=area(length,breadth)
print("Area of rectangle with length of",length,"unit and breadth of",breadth,"unit is: ",res,"Sq unit")


#with para without return

def area(l,b):             #function defination
    area=l*b
    print("Area of rectangle with length of",length,"and breadth of",breadth,"unit is: ",area,"Sq unit")



length=int(input("Enter  length of a rectangle: "))
breadth=int(input("Enter  breadth of a rectangle: "))
area(length,breadth)              #function calling


#without para with return

def area():
    length=int(input("Enter  length of a rectangle: "))
    breadth=int(input("Enter  breadth of a rectangle: "))

    area=length*breadth
    return area


res=area()
print("Area of rectangle with length of",length,"unit and breadth of",breadth,"unit is: ",res,"Sq unit")


#without para without return
def area():
    length=int(input("Enter  length of a rectangle: "))
    breadth=int(input("Enter  breadth of a rectangle: "))

    area=length*breadth
    print("Area of rectangle with length of",length,"unit and breadth of",breadth,"unit is: ",area,"Sq unit")


area()
