# Autho=Rohan
# Date=30-12-23

# print square of numbers from 3 to 19
 
for x in range(3,20):
      print(x*x)