'''Author=Rohan 
Date=18-12-23
program Details-1)In first one we are taking two integers as string'''
#here we are adding two string inputs
a=input("1st no.")
b=input("2nd no.")
print(a+b)
'''2)in this we are adding two integers
here we are adding one integer and one string value'''
a=input("1st no.")
b=input("2nd no.")
print(int(a)+int(b))
