#WAP to print sum of digits in reverse direction i e  5+4+3+2+1

def add(n):
    
    if n==0:
        return 0
    else:
        sum=n+add(n-1)
        return sum

a=int(input("Enter a number upto which you want the sum: "))
res=add(a)
print("Sum of series is: ",res)
        

