#Author = Rohan
# Date=20-12-23

side=int(input("Enter side of square"))
area=side*side
print("Area of square is: ",area,"units")