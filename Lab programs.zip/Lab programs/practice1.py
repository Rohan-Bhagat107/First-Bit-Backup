#create a python program that takes coefficient(a,b,c) of a quadratic equation as input and calculate the roots based on following cases:
# '''1)if discriminant is positive ,print two roots
# 2) if it is negative ,print single real root 
# 3)if it is less than zero print statement "Complex roots" '''

a=int(input("Enter first coefficient: "))
b=int(input("Enter second coefficient: "))
c=int(input("Enter third coefficient: "))

disk=int(b**2-4*a*c)
r1=int(-b+((disk)**0.5))/2*a
r2=int(-b-((disk)**0.5))/2*a
if disk>0:
    
    print("The roots of given quadratic equation are: ",r1,"and",r2)

elif disk==0:
    print("As discriminant is zero so the root is:",r2)

else:
    print("Complex roots.")