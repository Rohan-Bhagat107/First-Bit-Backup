#date=20-12-23

side=int(input("Enter side of a square"))
perimeter=4*side
print("Perimeter of square is: ",perimeter)