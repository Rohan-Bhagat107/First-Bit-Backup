# 1 * 3 * 5 
# 1 * 3 * 5
# 1 * 3 * 5
# 1 * 3 * 5

for i in  range(1,5):
    for j in range(1,6):
        if(j%2==0):
            print("*",end=" ")
        else:
            print(j,end=" ")
    print()