# Author=Rohan
#Date=21-12-23

#sum of digits of three digit no.

a=int(input("Enter 3 digit no.: "))   #suppose no. is 235
b=a//10    #23
c=a%10     #5
# print(b)
# print(c)
d=b%10      #3
e=b//10      #2
# print(d)
print("Sum of digits of your no. is: ",c+d+e)

