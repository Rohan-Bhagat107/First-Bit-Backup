#WAP to print the sum of series x-x^2/3+x^3/5-x^4/7.............n

def series():                #function defination
    x=int(input("Enter a number: "))
    n=int(input("Enter a power of x upto which you want the sum : "))
    sum=0
    for i in range(1,n+1):
        if x%2==0:
            sum-=(x**i)/(2*i)-1

        else:
            sum+=(x**i)/(2*i)-1
    print("Sum of series is: ",sum)

series()                         #function calling
