#date=20-12-23
radius=int(input("Enter radus of circle"))
perimeter=int(2*3.14*radius)
print("Perimeter of circle is: ",perimeter )