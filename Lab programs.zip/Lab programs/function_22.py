#function with parameter and return

def get_palindrome(no):
    org_no=no
    rev=0
    while no!=0:
        rev=rev*10+no%10
        no=no//10
    if rev==org_no:
            return "It is palindrome."
    else:
            return"Not a plindrome"

a=int(input("Enter a number: "))
x=get_palindrome(a)
print(x)
