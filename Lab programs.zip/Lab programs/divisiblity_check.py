# Author=Rohan
# Date=26-12-23

#task-
  #take a no. from user & check if it is divisible by both 2& 3

no=int(input("Please enter any no.: "))
if no%2==0 and no%3==0:
    print("The number you enterd is divisible by both 2 & 3 ")
else:
    print("It is not divisible by 2 & 3")