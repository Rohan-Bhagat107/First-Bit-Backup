#function with  parameter and no return value

def square(no):
    c=no*no
    print("Square of given number is: ",c)

square(5)
