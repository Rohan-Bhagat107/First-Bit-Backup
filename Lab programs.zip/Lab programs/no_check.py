# Author=Rohan
# Date=26-12-23

# W.A.P to check if a no. is +ve or -ve

a=int(input("Please enter a no.: "))
if a>0:
    print("No is positive.")

else:
    print("no.is negative")
    if a==0:
     print("No.is zero. please enter appropriate no.")