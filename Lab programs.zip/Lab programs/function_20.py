#function with parameter and no return
#WAP to check   Palindrome
def get_palindrome(no):
    rev=0
    org_no=no
    while no!=0:
        rev=rev*10+no%10
        no=no//10
    print("Reverse of your number is: ",rev)
    if rev==org_no:
        print("It is palindrome")
    else:
        print("Not palondrome")

a=int(input("Enter a number: "))    
get_palindrome(a)