# Author= Rohan
# Date-21-12-23

# Task-
# take user input of 2 angles of a triangle and write a program to calculate third angle


angle_1=int(input("Please enter first angle : "))#it is in degree
angle_2=int(input("Please enter second angle : "))#it is in degree
angle_3=int((180)-(angle_1+angle_2))#it is in degree
print("Third angle of a triangle is : ",angle_3)