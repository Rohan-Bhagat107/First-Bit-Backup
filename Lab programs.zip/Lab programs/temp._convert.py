# Author=Rohan
# Date=21-12-23

#convert celcius to farenhite

temp=int(input("Please enter temperature in celcius : "))
farenhite=int(temp*9/5)+32
print("Temperature in farenhite is: ",farenhite)
