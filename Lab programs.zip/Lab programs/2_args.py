def add(a,b=1,c=0):
    sum=a+b+c
    print(sum)