# Author=Rohan
# Date=21-12-23
#task-
#sum of digit

a=int(input("please enter your no. : "))

# Author=Rohan
# date=21-12-23

b=a%10
c=a/10
d=a//10
print(b)
print(c)
print(d)

print("Sum of digits is : ",b+d)