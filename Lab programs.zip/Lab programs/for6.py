#take user input and find if the number is prime or not


n=int(input("Enter number you want to check: "))
for x in range(2,n,1):
    if n%x==0:
        print("Not a prime number.")
        break
else:
    print("It is a prime number.")