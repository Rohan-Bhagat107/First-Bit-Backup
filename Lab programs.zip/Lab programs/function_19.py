#fun with no parameter and return value


def get_reverse():
    no=int(input("ENter a number."))
    rev=0
    org_no=no
    while no!=0:
        rev=rev*10+no%10
        no=no//10
    print("reverse of your number is: ",rev)
    if org_no==rev:
        print("It is a palindrome.")
    else:
        print("Not palindrome")
        
get_reverse()

