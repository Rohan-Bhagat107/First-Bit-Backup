#print even numbers from 12 to 31

for x in range(12,32,1):
    if x%2==0:
        print(x)
    