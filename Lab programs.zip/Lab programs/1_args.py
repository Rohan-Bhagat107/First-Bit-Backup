# def add(a,b):
#     sum=a+b
#     print("sum is: ",sum)

# def add(a,b,c):
#     sum=a+b+c
#     print("sum is: ",sum)

# add(1,2)



# def add(a,b,c):
#     sum=a+b+c
#     print("sum is: ",sum)

# add(1,2,3)

def add(a,b):
    sum=a+b
    print("sum is: ",sum)

add("Hello","world")