#Author = Rohan
# Date=20-12-23

base=int(input("Enter base of triangle"))
height=int(input("Enter height of triangle"))
area=int(0.5*base*height)
print("Area of triangle is: ", area,"unit")