#WAP to calculate area of square

def area(side):
    area=side**2
    return area

s=int(input("Enter  side of a square: "))
res=area(s)
print("Area of square with side",s,"unit is: ",res,"Sq unit")


#with para without return
def area(side):
    area=side**2
    print("Area of square with side",s,"unit is: ",area,"Sq unit")

s=int(input("Enter  side of a square: "))
area(s)



#without para with return
def area():
    side=int(input("Enter  side of a square: "))
    area=side**2
    return area


res=area(s)
print("Area of square with side",s,"unit is: ",res,"Sq unit")


#without para without return
def area():
    side=int(input("Enter  side of a square: "))
    area=side**2
    print("Area of square with side",s,"unit is: ",area,"Sq unit")

area()          #function calling

