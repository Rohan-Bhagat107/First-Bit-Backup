#Author = Rohan
# Date=20-12-23

first_no=int(input("Enter first no. "))
second_no=int(input("Enter second no. "))
third_no=int(input("Enter third no. "))
fourth_no=int(input("Enter fourth no. "))
avg=int(first_no+second_no+third_no+fourth_no)/4
print("Avg. of 4 no. is: ",avg)