#fun with no parameter and return value

def is_prime():
    no=int(input("Enter a number: "))
    for i in range(2,no):
        if no%i==0:
            break
    else:
     print(no,"is prime number")        

is_prime()

