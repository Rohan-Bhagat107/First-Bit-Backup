#function with  parameter  and no return
def factorial(no):
    fact=1
    for i in range(no,0,-1):
        fact*=i
    print("Fact is: ",fact)

factorial(5)