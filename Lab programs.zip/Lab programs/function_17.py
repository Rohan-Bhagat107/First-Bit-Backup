#function with no parameter and with return

def is_prime():
    no=int(input("Enter a number: "))
    for i in range(2,no):
        if no%i==0:
            return True
    else:
        return False

x=is_prime()
if x==False:
    print("It is prime")
else:
    print("Not prime number")
