#WAP to calculate area of circle

#with para with return
def area(radius):                     #function defination
    area=3.14*radius**2
    return area

r=int(input("Enter  radius of a circle: "))
res=area(r)
print("Area of cirlce with radius of",r,"unit is: ",res,"Sq unit")


#with para without return

def area(radius):
    area=3.14*radius**2
    print("Area of cirlce with radius of",r,"unit is: ",area,"Sq unit")


r=int(input("Enter  radius of a circle: "))
area(r)


#without para with return
def area():
    r=int(input("Enter  radius of a circle: "))
    area=3.14*r**2
    return area

res=area()
print("Area of cirlce with radius of",r,"unit is: ",res,"Sq unit")


#without para without return

def area():
    r=int(input("Enter  radius of a circle: "))
    area=3.14*r**2
    print("Area of cirlce with radius of",r,"unit is: ",area,"Sq unit")


area()                       #function calling







