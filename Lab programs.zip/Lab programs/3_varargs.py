def multi(*args):
    mul=1
    for a in args:
        mul*=a
    print(mul)
    print(type(args))

multi(2,5,8,9)