#fun with parameter and with return

def square(no):
    c=no**2
    return c

x=square(5)
print("Sq. of a given number is: ",x)
