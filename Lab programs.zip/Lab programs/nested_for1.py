#Accept start and end of range from user and print all prime numbers in that range


start=int(input("Enter start of your range: "))
end=int(input("Enter end of your range: "))

for i in range(start,end+1,1):
    for j in range(2,start,1):
       if i%j==0:
        break
       
    else:
     print(i)
    
    