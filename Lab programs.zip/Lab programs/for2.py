#print square of numbers from 1 to 20

for x in range(1,21,1):
    print(x,"x",x,"=",x*x)