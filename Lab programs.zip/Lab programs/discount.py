# Author = Rohan
# Date=21-12-23
# task-
#Give discount on total bill take discount from user

bill=int(input("Please enter your bill amount : "))
discount=int(input("Please enter discount that you have on your purchase : ","%"))
discount_amt=int((bill)*(discount/100))

print("Disount on your purchase is : ",discount_amt)
print("Total bill amount that you have to pay is ",bill-discount_amt,"/-")