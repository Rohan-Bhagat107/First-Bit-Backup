#Author = Rohan
# Date=20-12-23

radius=int(input("Enter radus of circle"))
area=int(3.14*radius*radius)
print("Area of circle is: ",area,"units")