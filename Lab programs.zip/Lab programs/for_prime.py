# Author=Rohan
# Date=30-12-23

# Check if a number is prime or not.

# n=int(input("Enter a number that you want to check: "))
# for i in range(n):
#      if n%i==0:
#         print("It is not a prime number.")
#         break
# else:
#    print("It is a prime number")

n=int(input("Enter a number that you want to check."))
for i in range(2,n):
    if n%i==0:
        print("Not a prime number.")
        break

else:
    print("It is a prime number.")


