# Author=Rohan
# Date=26-12-23

# Task-
# Enter any character from user & print corresponding colour Name 
#    r=red 
#    w=white
#    p=pink
#    b=blue

print("Welcome to my world ")
colour=(input("Please enter any character in (r,w,p,b):"))
if colour=="r":
    print("As you choosen char r so the colour will be : Red")

elif colour=="w":
    print("As you choosen char w so the colour will be : White")

elif colour=="p":
    print("As you choosen char p so the colour will be : Pink")

elif colour=="b":
    print("As you choosen char b so the colour will be : Blue")

else:
    print("Invalid colour")
