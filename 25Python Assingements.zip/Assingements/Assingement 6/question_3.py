#	Write a program print following patterns:
    #     1
    #    1 1
    #   1 2 1
    #  1 3 3 1




rows = 4

for i in range(0, 4):
    # Print spaces
    for j in range(1, 6-i):
        print(" ", end=" ")

    # Print numbers in each row
    for j in range( 1,i+2):
        if j == 1 or j==i+1 :
            print('1 ', end=" ")
        else:
            print(i," ", end=" ")  
    # Move to the next line after each row
    print()
