#	Write a program print following patterns:

#         A 
#       A B C
#     A B C D E
#   A B C D E F G
# A B C D E F G H I

for i in range(1,6):
    ch=65
    for j in range(1,6-i):
        print(" ",end=" ")
    for j in range(1,i+1):
        print(chr(ch),end=" ")
        ch+=1
    for j in range(2,i+1):
        print(chr(ch),end=" ")
        ch+=1
    print()