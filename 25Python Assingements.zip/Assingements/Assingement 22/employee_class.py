# class Emp():
#     def __init__(self,eid,name,basic):
#         self.eid=eid
#         self.name=name
#         self.basic=basic
#     def __str__(self):
#         return f"{self.eid},{self.name},{self.basic}\n"


class Emp():
    def __init__(self,id,name,basic):
        self.id=id
        self.name=name
        self.salary=basic
    
    def __str__(self):
        return f"{self.id},{self.name},{self.salary}\n"