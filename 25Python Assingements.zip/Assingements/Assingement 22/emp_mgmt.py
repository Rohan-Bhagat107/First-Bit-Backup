# Create a class Emp (eid,ename,basic)
# WAP a menu driven program to perform following operations using 
# files :
# a. Add a record
# b. Search for a record using id
# c. Delete a record using id
# d. Edit a record using id.
# e. Display all records

import pickle
import os

class Emp:
    def __init__(self, eid, ename, basic):
        self.eid = eid
        self.ename = ename
        self.basic = basic

def fetch_data():
    if os.path.exists('employees.abc'):
        with open('employees.abc', 'rb') as fp:
            return pickle.load(fp)
    return []

def save_data(data):
    with open('employees.abc', 'wb') as fp:
        pickle.dump(data, fp)

def add_record():
    eid = input("Enter Employee ID: ")
    data = fetch_data()
    if any(emp.eid == eid for emp in data):
        print("Employee with this ID already exists.")
        return
    ename = input("Enter Employee Name: ")
    basic = float(input("Enter Basic Salary: "))
    emp = Emp(eid, ename, basic)
    data.append(emp)
    save_data(data)
    print("Record added successfully.")

def search_record():
    eid = input("Enter Employee ID to search: ")
    data = fetch_data()
    for emp in data:
        if emp.eid == eid:
            print(f"Employee ID: {emp.eid}, Name: {emp.ename}, Basic Salary: {emp.basic}")
            return
    print("There is no Employee with such ID.")

def delete_record():
    eid = input("Enter Employee ID to delete: ")
    data = fetch_data()
    new_data = [emp for emp in data if emp.eid != eid]
    if len(data) == len(new_data):
        print("There is no Employee with such ID.")
    else:
        save_data(new_data)
        print("Record deleted successfully.")

def edit_record():
    eid = input("Enter Employee ID to edit: ")
    data = fetch_data()
    for emp in data:
        if emp.eid == eid:
            emp.ename = input(f"Enter new name (current: {emp.ename}): ") or emp.ename
            emp.basic = float(input(f"Enter new basic salary (current: {emp.basic}): ") or emp.basic)
            save_data(data)
            print("Record updated successfully.")
            return
    print("Employee not found.")

def display_all_records():
    data = fetch_data()
    if not data:
        print("No records found.")
        return
    for emp in data:
        print(f"Employee ID: {emp.eid}, Name: {emp.ename}, Basic Salary: {emp.basic}")

if __name__=="__main__":
    while True:
        print("\nEmployee Management System")
        print("1. Add a record")
        print("2. Search for a record using ID")
        print("3. Delete a record using ID")
        print("4. Edit a record using ID")
        print("5. Display all records")
        print("6. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            add_record()
        elif choice == '2':
            search_record()
        elif choice == '3':
            delete_record()
        elif choice == '4':
            edit_record()
        elif choice == '5':
            display_all_records()
        elif choice == '6':
            print("Exiting the program.")
            break
        else:
            print("Invalid choice, please try again.")

