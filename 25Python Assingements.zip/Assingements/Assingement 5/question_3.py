# '''	#Accept no. of passengers from user and per ticket cost. Then accept age of each 
#  passenger and then calculate total amount to ticket to travel for all of them based on 
#  following condition :
#  a.	Children below 12 = 30% discount
#  b.	Senior citizen (above 59) = 50% discount
#  c.	Others need to pay full.'''


num=int(input("How many passengers are travelling?: "))
amt_per_ticket=int(input("Enter amount of single ticket: "))
n=1
sum=0
count=0
while n<=num:
    age=int(input("Enter your age: "))  
    if age<12:
            discount=30
            dis_amt=amt_per_ticket*30/100
            total=dis_amt
            sum+=total
            n=n+1
    elif age>59:
            discount=50
            dis_amt=amt_per_ticket/2
            sum+=dis_amt
            n+=1
    else:
            discount=amt_per_ticket
            sum+=discount
            n+=1
print("Your total bill is: ",sum,"INR")




