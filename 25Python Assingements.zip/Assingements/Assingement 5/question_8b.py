#Q 2)=>    N + N^2 + N^3+N^4 …..+N^N (here ^ means exponent)
N=int(input("Enter a numbere of which you want the sum: "))
n=int(input("Enter power of that number upto which you want sum: "))
sum=0
for i in range(1,n+1):
    sum+=N**i
print("Sum of",N,"is: ",sum)