#Q4)  S = a + a2 / 2 + a3 / 3 + …… + a10 / 
#10(a**i/i)
#
a=int(input("Enter a number: "))
s=0
for i in range(1,11):
    s+=a**i/i
print("Sum of series is: ",s)