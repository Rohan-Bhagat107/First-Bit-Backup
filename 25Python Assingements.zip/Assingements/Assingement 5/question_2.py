# Enter number of students from user. For those many students accept marks of 5 
# subject marks from user and calculate percentage. Display all percentage and 
# average percentage of students.


n=int(input("Enter how many students are there : "))
total=int(input("Enter total marks of 5 sub: "))
sum=0
total_student=n  
while n>=1:  
    sub1=int(input("Enter a marks obtained in 1st sub: "))
    sub2=int(input("Enter a marks obtained in 2nd sub  : "))
    sub3=int(input("Enter a marks obtained in 3rd sub : "))
    sub4=int(input("Enter a marks obtained in 4th sub : "))
    sub5=int(input("Enter a marks obtained in 5th sub : "))
    total_marks=sub1+sub2+sub3+sub4+sub5
    percentage1=(total_marks/total)*100
    sum += percentage1
    print(int(percentage1))
    n-=1 

avg=(sum/(total_student))
print('Avrage percentage of student is:',avg)