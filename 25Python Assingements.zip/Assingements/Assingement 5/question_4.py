#	Write a program to check if given number is Armstrong number or not

num=int(input("Enter any number: "))        #589
count=0
org_no=num
while num!=0:                    #589!=0
    digit=num%10                #9
    num=num//10                  #58
    count+=1                           
 
num=org_no
sum=0
while num!=0:
    a=num%10
    num=num//10
    power=a**count
    sum+=power
if sum==org_no:
    print("Number you enterd is AN ARMSTRONG NUMBER.")
else:
    print("Number you enterd is NOT ARMSTRONG NUMBER.")


    
