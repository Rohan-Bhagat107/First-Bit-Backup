# 	Write a program to prompt user to enter userid and password. If Id and 
# password is incorrect give him chance to re-enter the credentials. Let him try 3 
# times. After that program to terminate


user_id=input("Enter your user id for registration: ")
password=input("Enter your registration password: ")

login_id=input("Enter your registerd user id: ")
login_pass=input("Enter your registerd password: ")
  
if user_id!=login_id or password!=login_pass:
    count=1
    while count<=3:
      user_id=input("Please re-enter your user id: ")
      password=input("Please re-enter your password: ")
      count+=1
      if count==3:
       print("Sorry better luck next time .")
       break
elif user_id==login_id and password==login_pass:
    print("Credentials are matched.")
    print("Login is succesfull.")
else:
   print("Invalid credentials.")


