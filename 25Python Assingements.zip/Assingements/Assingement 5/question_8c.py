#Q3.  Find the sum of a geometric series from 1 to n where the common ratio is 2.

#if n is the number of terms then-

n= int(input("enter number of terms upto which you want the sum: "))
ratio = 2
a=1
sum=(1-ratio**n)/1-ratio
print("sum of geometric series from 1 to",n,"terms is: ",sum)


#if n is the number upto which we want the sum of geometric series then-

# n= int(input("enter number upto which you want the sum of geometric series: "))
# ratio = 2
# a=1
# sum=0
# while a<=n:
#     sum+=a
#     a*=ratio
# print("Sum of geometric series is: ",sum)