#	Write a program to print first n prime numbers.


n=int(input("Enter a number upto which you want to print prime numbers:"))
a=2
count=0                   #or we can take count as 1
while count<n:              #so the condition will be count<=n
    for i in range(2,a):
            if a%i==0:
                break
    else:
         count+=1
         print(a)
    a+=1