#Q5)  x - x2/3 + x3/5 - x4/7 + …. to n terms
x=int(input("Enter a number:"))
n=int(input("Enter a number of terms:"))
sum=0

for i in range(1,n):
    if i%2==0:
        sum-=(x**i)/i/(2*i-1)
    else:
        sum+=(x**i)/(2*i-1)
   
print("Sum of series is: ",int(sum))