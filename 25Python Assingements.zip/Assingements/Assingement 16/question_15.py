#Python Program to find larger string without using built-in functions\

str1=input("Enter 1st string: ")
str2=input("Enter 2nd string: ")
str1_count=0
str2_count=0
for i in str1:
    if i==" ":
        continue
    str1_count+=1
for j in str2:
    if j==" ":
        continue
    str2_count+=1

if str1_count > str2_count:
    print("1st string is larger")

elif str1_count<str2_count:
    print("2nd string is larger")

else:
    print("Both string are of equal length.",str1_count)