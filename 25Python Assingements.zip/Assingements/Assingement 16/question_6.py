#. Python Program to Take in a String and Replace Every Blank Space with Hyphen
original_string=input("Enter any string: ")
new_string=original_string.replace(" ","_")
print(new_string)