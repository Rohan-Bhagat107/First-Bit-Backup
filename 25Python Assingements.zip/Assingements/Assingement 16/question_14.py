#Python Program to count the occurrences of each word in a string

original_string=input("Enter any string: ")
list1=original_string.split(" ")
set1=set(list1)

for i in set1:
    count=0
    for j in list1:
        if i==j:
            count+=1
    print(i,"->",count)

