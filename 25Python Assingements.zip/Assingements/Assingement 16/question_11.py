# Python Program to replace every blank space with hyphen in a string.
original_string=input("Enter any string: ")
new_string=original_string.replace(" ","_")
print(new_string)