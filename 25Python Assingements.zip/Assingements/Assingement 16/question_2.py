#Python Program to Remove the nth Index Character from a Non-Empty String
str1=input("Enter any string: ")
index=int(input("Enter index of which you want to remove character: "))
str2=""
if index>=0 and index<len(str1)-1:
    for i in range(len(str1)):
        if i==index:
         continue
        str2+=str(str1[i])
    print(str2)

else:
    print(f"{index} is an invalid index")
         
        