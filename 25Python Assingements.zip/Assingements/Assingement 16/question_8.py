#Python Program to Remove the Characters of Odd Index Values in a String

original_string=input("Enter any string: ")
new_string=""
for i in range(len(original_string)):
    if i%2==0:
        new_string+=str(original_string[i])

print(new_string)
