#Python Program to Count the Number of Vowels in a String
original_string=input("Enter any string: ")
count=0
for i in original_string:
    if i in ("a","e","i","o","u","A","E","I","O","U"):
        count+=1

print(count)