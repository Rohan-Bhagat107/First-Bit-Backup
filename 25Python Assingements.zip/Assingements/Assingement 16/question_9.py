#Python Program to Calculate the Number of Words and the Number of Characters Present in a String
string=input("Enter any string: ")
word_count=1
character_count=0
for i in string:
    if i==" ":
        word_count+=1
    else:
        character_count+=1
print("Number of characters in given string are: ",character_count)
print("Number of words in given string are: ",word_count)