#Python Program to Take in Two Strings and Display the Larger String without Using Built-in Functions

string1=input("Enter 1st string: ")
string2=input("Enter 2nd string: ")
string1_length=0
string2_length=0
for i in string1:
    if i==" ":
        continue
    string1_length+=1
for j in string2:
    if j==" ":
        continue
    string2_length+=1

if string1_length>string2_length:
    print("1st string is larger.| Length:",string1_length)
elif string1_length<string2_length:
    print("2nd string is larger. | Length:",string2_length)
else:
    print("Both strings are of equal length.",string1_length)
