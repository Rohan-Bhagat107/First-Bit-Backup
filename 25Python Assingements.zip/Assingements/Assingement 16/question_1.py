#Python Program to Replace all Occurrences of ‘a’ with $ in a String
str1=input("Enter any string: ")
res=str1.replace("a","$")
print(res )