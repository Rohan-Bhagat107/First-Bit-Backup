#Python Program to count number of digits and letters in a string

original_string=input("Enter any string: ")
digit_count=0
alpha_count=0

for i in original_string:
    if i.isalpha():
        alpha_count+=1
    if i.isdigit():
        digit_count+=1
    
print("Total number of alphabets in given string is: ",alpha_count)
print("Total number of digits in given string is: ",digit_count)
