#Python Program to Detect if Two Strings are Anagrams

string1=input("Enter 1st word: ")
string2=input("Enter 2nd word: ")
str1_set=set()
str2_set=set()
str1_count=0
str2_count=0
for i in string1:
    str1_set.add(i)
    str1_count+=1
print(str1_set)
for j in string2:
    str1_set.add(j)
for k in str1_set:
    if k not in str2_set:
        print("Not")
        break
else:
    print("Anagram")


# if str1_set==str2_set:
#     print("Anagarm")
# else:
    # print('Not')
# for j in string2:
#     str2_list.append(j)
#     str2_count+=1

# if str1_count==str2_count:
#     for k in str1_list:
#         if k not in str2_list:
#             break
#         else:
#             pass
            
#     print(f"'{string1}' and '{string2}' are anagrams")

# else:
#     print(f"{string1} and {string2} are Not anagrams")