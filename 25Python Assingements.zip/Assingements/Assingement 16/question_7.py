# Python Program to Calculate the Length of a String Without Using a Library Function
original_string=input("Enter any string: ")
count=0
for i in original_string:
    count+=1

print("Length of given string is: ",count)