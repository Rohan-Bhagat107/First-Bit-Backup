#Python Program to Form a New String where the First Character and the Last Character have been Exchanged

original_string=input("Enter any string: ")

new_string=original_string[-1]+original_string[1:-1]+original_string[0]
print(new_string)
# print(original_string[0])
# print(original_string[-1])
# print(original_string[1:-1])