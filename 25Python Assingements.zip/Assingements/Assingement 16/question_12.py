#Python Program to count number of lowercase characters in a string

original_string=input("Enter any string: ")
lowered_string=original_string.lower()

count=0
for i in original_string:
    if i in lowered_string:
        if i==" ":
            continue
        count+=1

print("TOtal lowercase characters in given string is:  ",count)