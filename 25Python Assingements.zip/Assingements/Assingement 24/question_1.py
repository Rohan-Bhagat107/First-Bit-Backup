# Calculate the sum of squares of numbers from 1 to 100 using four threads. Divide the 
# range equally among the threads, and each thread calculates the sum of squares for its 
# range. Finally, combine the results to get the total sum of square

import threading

total=[]
def range_1(start,end):
    sum=0
    for i in range(start,end+1):
        sum+=i**2
    total.append(sum)

def range_2(start,end):
    sum=0
    for i in range(start,end+1):
        sum+=i**2
    total.append(sum)

def range_3(start,end):
    sum=0
    for i in range(start,end+1):
        sum+=i**2
    total.append(sum)

def range_4(start,end):
    sum=0
    for i in range(start,end+1):
        sum+=i**2
    total.append(sum)

t1=threading.Thread(name="Thread1",target=range_1,args=(1,25))
t2=threading.Thread(name="Thread2",target=range_2,args=(26,50))
t3=threading.Thread(name="Thread3",target=range_3,args=(51,75))
t4=threading.Thread(name="Thread4",target=range_4,args=(76,100))

t1.start()
t1.join()
t2.start()
t2.join()
t3.start()
t3.join()
t4.start()

sq_sum=0

for i in total:
    sq_sum+=i
print("Sum of your squares from 1 to 100 is: ",sq_sum)


