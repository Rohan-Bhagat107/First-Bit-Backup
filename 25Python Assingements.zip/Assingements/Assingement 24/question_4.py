# Implement a producer-consumer problem with a limited buffer of size 5. Create two 
# producer threads and two consumer threads. Producers produce items, and consumers 
# consume them. Ensure proper synchronization to avoid buffer overflows or underflows


# import threading
# import time
# import random


# def produce(item_list):
#     a=True
#     i=1
#     while True:
        
#         time.sleep(5)
        
#         item_list.append(i)
#         print("Produced:"+str(i))
#         i+=1
#         time.sleep(5)
        

# def consume(item_list):
#     b=True
#     while True:
        
#         time.sleep(6)
        
#         if len(item_list)==0:
#             print("Remaining: No item")
#             continue
#         item=item_list.pop(0)
#         print('Consumed: '+str(item))
        


# item_list=[]
# producer=threading.Thread(target=produce,args=(item_list,))
# consumer=threading.Thread(target=consume,args=(item_list,))


# producer.start()

# consumer.start()



# import threading
# import time



# def produce(item_list):
    
#     i=1
#     while True:
        
#         item_list.append(i)
#         print("Produced:"+str(i))
#         i+=1
        
#         time.sleep(5)
# def consume(item_list):
#     lock1.acquire()
#     while True:
        
#         if len(item_list)==0:
#             print("Remaining: No item")
            
#             continue
#         item=item_list.pop(0)
#         print('Consumed: '+str(item))
#         time.sleep(5)     
        
        
#     lock1.release()


# item_list=[]
# producer=threading.Thread(target=produce,args=(item_list,))
# consumer=threading.Thread(target=consume,args=(item_list,))
# lock1=threading.Lock()

# producer.start()
# consumer.start()





import threading
import time

def print_lowercase():
    for char in range(ord('a'), ord('z') + 1):
        print(chr(char), end=' ', flush=True)
        time.sleep(0.1)  # Simulate some delay

def print_uppercase():
    for char in range(ord('A'), ord('Z') + 1):
        print(chr(char), end=' ', flush=True)
        time.sleep(0.1)  # Simulate some delay

if __name__ == "__main__":
    # Create threads
    lowercase_thread = threading.Thread(target=print_lowercase)
    uppercase_thread = threading.Thread(target=print_uppercase)

    # Start threads
    lowercase_thread.start()
    uppercase_thread.start()

    # Join threads to the main thread to ensure they complete execution
    lowercase_thread.join()
    uppercase_thread.join()



