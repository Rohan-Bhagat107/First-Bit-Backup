# implement two threads to print lowercase and uppercase alphabets concurrently from 
# 'a' to 'z' and 'A' to 'Z'


import threading
import time

def uppercase():
    ch=65
    
    for i in range(1,27):
        print(chr(ch))
        ch+=1
        time.sleep(2)

def lowercase():
    ch=97
    for i in range(1,27):
        print(chr(ch))
        ch+=1
        time.sleep(2)


t1=threading.Thread(name="Thread1",target=lowercase)
t2=threading.Thread(name="Thread2",target=uppercase)

t1.start()
t2.start()



