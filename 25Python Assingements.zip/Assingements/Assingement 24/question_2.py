# Create two threads, one printing even numbers and the other printing odd numbers 
# from 1 to 10. Ensure proper synchronization to alternate between even and odd 
# numbers

import threading
import time

lock1=threading.Lock()
def even_num():
    
    
    for i in range(1,11):
        if i%2==0:
            print(i)
            time.sleep(2)

 
def odd_num():
  
    lock1.acquire()
    for i in range(1,11):

        if i%2==1:
            print(i)
            time.sleep(2)
    lock1.release()

t1=threading.Thread(name="Thread1",target=even_num)
t2=threading.Thread(name="Thread2",target=odd_num)


t2.start()

t1.start()



# import threading

# class EvenOddPrinter:
#     def __init__(self):
#         self.condition = threading.Condition()
#         self.current = 1

#     def print_odd(self):
#         while self.current <= 10:
#             with self.condition:
#                 if self.current % 2 == 0:
#                     self.condition.wait()
#                 if self.current > 10:
#                     self.condition.notify_all()
#                     break
#                 print(self.current)
#                 self.current += 1
#                 self.condition.notify_all()

#     def print_even(self):
#         while self.current <= 10:
#             with self.condition:
#                 if self.current % 2 != 0:
#                     self.condition.wait()
#                 if self.current > 10:
#                     self.condition.notify_all()
#                     break
#                 print(self.current)
#                 self.current += 1
#                 self.condition.notify_all()

# if __name__ == "__main__":
#     printer = EvenOddPrinter()
    
#     odd_thread = threading.Thread(target=printer.print_odd)
#     even_thread = threading.Thread(target=printer.print_even)

#     odd_thread.start()
#     even_thread.start()

#     odd_thread.join()
#     even_thread.join()
