#Author =Rohan Bhagat
# Date=23-12-23

# Task-
# W. A .P to enter P,T,R and calculate compound interest

principle=int(input("Please enter amount that you have to invest: "))   #It is in INR
time=int(input("Please enter time duration: "))  #It is in years
rate=int(input("Please enter rate of interest: "))  #it is in %
number=int(input("please enter number of times interst applied per time period: "))
compound_interest=int(principle*(1+rate/number)**number*time)
print("Compound interest at the rate of",rate,"% for",time,"year is: ",compound_interest,"INR")
