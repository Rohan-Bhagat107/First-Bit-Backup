  #Author =Rohan Bhagat
# Date=23-12-23

# Task-
# W. A .P to enter P,T,R and calculate simple interest

principle=int(input("Please enter amount that you have to invest: "))   #It is in INR
time=int(input("Please enter time duration: "))  #It is in years
rate=int(input("Please enter rate of interest: "))  #it is in %

simple_interest=principle*time*rate/100

print("Simple interest at the rate of",rate,"% for",time,"year is :",simple_interest)
