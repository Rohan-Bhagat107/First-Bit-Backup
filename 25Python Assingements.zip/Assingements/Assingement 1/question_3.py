# Author=Rohan 
# Date=25-12-23

#W.A.P to find quotient and reminder of two numbers


first_no=int(input("please enter first two digit no.: "))
quotient=first_no/10
remender=first_no%10
print("Quotient of first no. is: ",quotient, )
print("Remender of first no. is:",remender)
second_no=int(input("please enter second two digit no.: "))
quotient2=second_no/10
remender2=second_no%10
print("Quotient of second two digit no. is: ",quotient2)
print("Remender of first no. is:",remender2)

