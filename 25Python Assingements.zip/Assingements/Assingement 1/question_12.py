#Author =Rohan Bhagat
# Date=24-12-23

# Task-
#W.A.P to find volum of sphere
radius=int(input("Please enter radius of sphere: ")) #it is in unit
print("Volume of sphere is: ",int((4/3)*3.14*radius*radius*radius),"cubic unit")