# Author=Rohan 
# Date=25-12-23

# W.A.P to convert days into year,week and days     

day=int(input("Please enter number of days: "))
year=day//365
week=(day%365)//7
days=(day%365)%7
print("converted days are:",year,"Year",week,"week",days,"days")

# print("Your converted days are:",year,week,day)
