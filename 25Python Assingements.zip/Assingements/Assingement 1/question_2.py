# Author =Rohan Bhagat
# Date=23-12-23

# Task-
# program to calculate area of rectangle based on length and breadth

length=int(input("Please enter length of rectangle: "))   #accept length
breadth=int(input("Please enter breadth of rectangle: "))  #accept breadth
print("Area of rectangle is: ",int(length*breadth),"sq.unit")