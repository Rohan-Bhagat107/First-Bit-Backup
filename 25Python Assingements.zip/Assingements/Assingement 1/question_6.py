#Author =Rohan Bhagat
# Date=23-12-23

# Task-

#W.A.P to input two angles from user and find third angle of a triangle.

first_angle=int(input("Please enter 1st angle of a triangle: "))  #It is in degree
second_angle=int(input("Please enter 2nd angle of a triangle:"))   #It is in degree
print("Third angle of triangle is :",int(180-(first_angle+second_angle))) #It is in degree