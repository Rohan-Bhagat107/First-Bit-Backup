#Task-
#Find the roots of quadratic equation.

a=int(input("Enter 1st coefficient: "))
b=int(input("Enter 2nd coefficient: "))
c=int(input("Enter 3rd coefficient: "))
disk=int(b**2-4*a*c)

x1=(-b+((disk)**0.5))/2*a
x2=(-b-((disk)**0.5))/2*a

print("First root of quadratic equation is:",(x1))
print("Second root of quadratic equation is:",(x2))
