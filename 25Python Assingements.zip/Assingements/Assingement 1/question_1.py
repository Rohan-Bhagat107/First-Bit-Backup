#Author =Rohan Bhagat
# Date=24-12-23

# Task-
#W.A.P to calculate percentage of student based on marks of 5subjects

total=int(input("Please enter total marks "))
sub_1=int(input("Please enter marks obtained in 1st subject: "))
sub_2=int(input("Please enter marks obtained in 2nd subject: "))
sub_3=int(input("Please enter marks obtained in 3rd subject: "))
sub_4=int(input("Please enter marks obtained in 4th subject: "))
sub_5=int(input("Please enter marks obtained in 5th subject: "))

percentage=((sub_1+sub_2+sub_3+sub_4+sub_5)/total)*100
print("Percentage based on marks of 5 subjects is: ",percentage,"%")