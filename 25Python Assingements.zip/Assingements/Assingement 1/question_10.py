# Author =Rohan Bhagat
# Date=23-12-23

# Task-
#W.A.P to calculate area of equilateral triangle

side=int(input("Please enter side of triangle: "))
print("Area of equilateral triangle is: ",int((3**0.5/4)*side*side))