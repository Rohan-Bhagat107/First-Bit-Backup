#Author =Rohan Bhagat
# Date=23-12-23

# Task-
#W.A.P to enter base and height of triangle to find its area

base=int(input("Plase enter length of base of a triangle: ")) #it is in unit
height=int(input("Plase enter height of a triangle: "))#it is in unit
print("Area of rectangle is : ",int(0.5*base*height),"sq.unit")#it is in sq. unit