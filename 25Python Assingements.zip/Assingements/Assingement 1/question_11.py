#Author =Rohan Bhagat
# Date=24-12-23

# Task-
#W.A.P to calculate area &circumference of circle

radius=int(input("Please enter radius of circle: ")) #it is in unit
print("Area of circle is: ",int(3.14*radius*radius),"sq.unit")
print("Circumference of circle is: ",int(2*3.14*radius),"unit")
