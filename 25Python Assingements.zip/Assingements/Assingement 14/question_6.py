#Write a program to remove duplicates from the list.

data=[]
distinct_data=[]
n=int(input("Enter how many elements you want to add: "))
for i in range(n):
    element=int(input("Enter the element: "))
    data.append(element)
    if element not in distinct_data:
        distinct_data.append(element)
print("Original list is....")
print(data)
print("List with distinct members is......")
print(distinct_data)

