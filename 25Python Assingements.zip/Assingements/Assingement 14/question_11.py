#Write a program to print all numbers which are divisible by m and n in the list.

number=[]
n=int(input("Enter how many elements you want to add in a list: "))
for i in range (n):
    element=int(input("Enter the element: "))
    number.append(element)
print("Original list is: ....")
print(number)
m=int(input("Enter 1st number for divisiblity check: "))
n=int(input("Enter 2nd number for divisibblity check: "))
print(f"Numbers of the above list wich are divisible by {m} and {n} are:-")
for j in number:
    if j%m==0 and j%n==0:
        print(j)
    