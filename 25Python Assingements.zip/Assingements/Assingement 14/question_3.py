# Write a program to find the second largest element in the list.
numbers=[]
n=int(input("How many numbers you want to add in a list: "))
max=0
min=0

for i in range (n):
    element=int(input("Enter the element: "))
    numbers.append(element)
print(numbers)
for i in range(len(numbers)):
    for j in range(i+1,len(numbers)):
        if numbers[i]>=numbers[j]:
            numbers[i],numbers[j]=numbers[j],numbers[i]

second_largest=numbers[len(numbers)-2]
print("Second largest number is: ",second_largest)