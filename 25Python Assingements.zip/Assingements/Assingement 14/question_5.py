#Accept a number from user and check if this element is present in the list or not. Also tell how many times it is present in the list.

number=[]
n=int(input("Enter how many elements you want to add in a list: "))
no_searched=int(input("Enter a number that you want to search: "))
count=0
for i in range(n):
    element=int(input("Enter the element: "))
    number.append(element)
    if element==no_searched:
        count+=1
if count>0:
    print(f"{no_searched} is present in the list {count} time")
else:
    print(f"{no_searched} is not in the list")
    
    


