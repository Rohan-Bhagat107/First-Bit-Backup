#Write a program to print list after removing even numbers
numbers=[]
odd_num=[]
n=int(input("How many numbers you want to add in a list: "))

for i in range (n):
    element=int(input("Enter the element: "))
    numbers.append(element)
    if element%2==1:
        odd_num.append(element)
print("Orginal list is:-")
print(numbers)
print("List after removing all even elements is:-")
print(odd_num)


