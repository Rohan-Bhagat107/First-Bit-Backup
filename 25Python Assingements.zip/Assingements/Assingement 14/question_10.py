#Write a program to remove all occurrences of a given element in the list.
number=[]
removal=[]
n=int(input("Enter how many elements you want to add in a list: "))

for i in range (n):
    element=int(input("Enter the element: "))
    number.append(element)
print("Original list is: ....")
print(number)

removal_num=int(input("Enter a number of which you want to remove all occurances from original list: "))
for j in number:
    if j!=removal_num:
        removal.append(j)
    
print(f"List after removing all occurances of {removal_num} is: .....")
print(removal)

