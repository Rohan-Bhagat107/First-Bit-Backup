#Write a program to create a new list from existing list which contains cube of each number of list.

data=[]
cube_data=[]
n=int(input("Enter how many elements you want to add in a list: "))

for i in range(n):
    element=int(input("Enter the element: "))
    data.append(element)
    
    cube=element**3
    cube_data.append(cube)

print("Original list is..........")
print(data)

print("list  with cube is..........")
print(cube_data)

