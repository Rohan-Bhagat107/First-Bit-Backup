#Write a program to create a duplicate of an existing list. It should not point to same list

data=[]
duplicate_data=[]
n=int(input("Enter how many elements you want to add in a list: "))
for i in range(n):
    element=int(input("Enter the element: "))
    data.append(element)
    duplicate_data.append(element)

print("Original list is:......")
print(data)
print("ID of original list is: ",id(data))
print("Duplicate list is: ....")
print(duplicate_data)
print("ID of duplicate list is: ",id(duplicate_data))
