#Write a program to reverse the list.
numbers=[]
reversed_list=[]
n=int(input("Enter how many numbers you want to add in a list: "))
for i in range(n):
    element=int(input("Enter the element: "))
    numbers.append(element)
print("Original list..........")
print(numbers)
for j in range(len(numbers)-1,-1,-1):
    reversed_list.append(numbers[j])
print("Reversed list is..........")
print(reversed_list)