 # a program to find sum of all elements of list

numbers=[]
n=int(input("How many numbers you want to add in a list: "))
sum=0
for i in range (n):
    element=int(input("Enter the element: "))
    numbers.append(element)
    sum+=element
print("Sum of all elemets of a list is: ",sum)
