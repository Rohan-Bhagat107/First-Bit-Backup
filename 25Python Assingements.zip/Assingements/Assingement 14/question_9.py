# Write a program of having n number of elements in the list and find out even and odd elements in that list and then create two separate lists which will have even elements and other will have odd elements.

number=[]
even_number=[]
odd_number=[]
n=int(input("Enter how many elements you want to add in a list: "))
for i in range (n):
    element=int(input("Enter the element: "))
    number.append(element)
    if element%2==0:
        even_number.append(element)
    else:
        odd_number.append(element)

print("Original list is: ..")
print(number)
print("List with even numbers is: ....")
print(even_number)
print("List with odd number is: ...")
print(odd_number)