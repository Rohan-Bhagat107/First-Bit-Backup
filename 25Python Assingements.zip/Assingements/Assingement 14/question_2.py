# Write a program to find maximum and minimum element in a list.
numbers=[]
n=int(input("How many numbers you want to add in a list: "))
max=0
min=0

for i in range (n):
    element=int(input("Enter the element: "))
    numbers.append(element)
print(numbers)
for i in range(len(numbers)):
    for j in range(i+1,len(numbers)):
        if numbers[i]>=numbers[j]:
            numbers[i],numbers[j]=numbers[j],numbers[i]

max=numbers[len(numbers)-1]
min=numbers[0]
print("Maximum number is: ",max)
print("Minimum number is: ",min)