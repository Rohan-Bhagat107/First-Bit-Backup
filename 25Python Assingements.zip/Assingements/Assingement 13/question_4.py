# Create a class College which has collection of students. Add the 
# following methods :
# a. Parameteried constructor for number of students.
# b. AddStudent
# c. GetStudent
# d. RemoveStudent
# e. Override __str__ Method


class College():
    def __init__(self):
        self.students=[]
    
    def Add_Student(self,s1):
        self.students.append(s1)
    
    def Get_student(self):
        for x in self.students:
            print(f"ID: {x.id} | Name: {x.name}")
    
    def Get_student_by_id(self,id):
        for x in self.students:
            if id==x.id:
                #print(f"Name of student is : {x.name} | ID is: {x.id}")
                print(x)
                break
        else:
            print(f"There is no student with your entered id:{id}")
    def Remove_Student(self,id):
        for x in range(len(self.students)):
            if (self.students[x].id==id):
                index=x
                self.students.pop(index)
                print("The student after deleting  are: ")
                C.Get_student()
                break
    

class Student():
    def __init__(self,id,name):
        self.id=id
        self.name=name
    def __str__(self):
        for x in C.students:
           print(f"Name of student is: {x.name} | ID: {x.id}")

if __name__=="__main__":
    C=College()

    choice=0
    while choice !=6:
        print('''    1)ADD student
                 2)Get student
                 3)Get student by ID
                 4)Remove student
                 5)override __str__ 
                 6)Exit''')
        
        choice=int(input("Enter a number from above menu as per your requirement: "))
        if choice==1:
            id=int(input("Enter ID of a student: "))
            for x in C.students:
                if id==x.id:
                    print("ID that you entered is already exist please enter another one.")
                    break
            else:
                name=input("Enter name of student: ")
                s1=Student(id,name)
                C.Add_Student(s1)
        
        if choice==2:
            C.Get_student()
        
        if choice==3:
            id=int(input("Enter ID of student that you want to search: "))
            C.Get_student_by_id(id)
        
        if choice==4:
            id=int(input("Enter ID of student that you want to remove: "))

            C.Remove_Student(id)
        
        if choice==5:
            s1=Student()
            print(s1)
    
                 

    