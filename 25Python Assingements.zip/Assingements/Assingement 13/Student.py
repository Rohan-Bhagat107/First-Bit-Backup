# Create a class Student with following
# a. data members :
# i. StudentId
# ii. Name
# iii. Age
# iv. Percentage
# b. Add the following methods :
# i. Parameterized constructor
# ii. Display
# iii. Accept
# iv. Method CalculateRank
# v. Override __str__ Method


class Student():
    def __init__(self,StudentId=0,Name="-",Age="-",Percentage=0,Rank="-"):
        self.StudentId=StudentId
        self.Name=Name
        self.Age=Age
        self.Percentage=Percentage
        #self.Rank=Rank
    def Display(self):
        print(f"StudentId: {self.StudentId} | Name: {self.Name} | Age: {self.Age} | Percentage={self.Percentage}% ")
    
    def Accept(self):
        self.StudentId=int(input("Enter student Id: "))
        self.Name=input("Enter name of student: ")
        self.Age=int(input("Enter age of student: "))
        self.Percentage=float(input("Enter percentage of student: "))
    
    def CalculateRank(self):
        if self.Percentage>90.0 and self.Percentage<100.0:
            print("1st Rank")

        elif self.Percentage>70.0 and self.Percentage<=90.0:
            print("2nd Rank")

        elif self.Percentage>50.0 and self.Percentage<=70.0:
            print("3rd Rank")

        elif self.Percentage>40.0 and self.Percentage<=50.0:
            print("4th Rank")

        else:
            print("Fail")
    def __str__(self):
         return (f"StudentId: {self.StudentId} | Name: {self.Name} | Age: {self.Age} |Percentage={self.Percentage}% ")
if __name__=="__main__":       
    s1=Student()
    s1.Accept()
    s1.CalculateRank()
    print(s1)
    s1.Display()




                 #Another way to solve this question

# # Create a class Student with following
# # a. data members :
# # i. StudentId
# # ii. Name
# # iii. Age
# # iv. Percentage
# # b. Add the following methods :
# # i. Parameterized constructor
# # ii. Display
# # iii. Accept
# # iv. Method CalculateRank
# # v. Override __str__ Method

# class Student():
#     def __init__(self=" ",StudentId=0,Name="-",Age="-",Percentage=0,Rank="-"):
#         self.StudentId=StudentId
#         self.Name=Name
#         self.Age=Age
#         self.Percentage=Percentage
#         self.Rank=Rank
#     def Display(self):
#         print(f"StudentId: {self.StudentId} | Name: {self.Name} | Age: {self.Age} | Percentage={self.Percentage}% ")
    
#     def Accept(self):
#         self.StudentId=int(input("Enter student Id: "))
#         self.Name=input("Enter name of student: ")
#         self.Age=int(input("Enter age of student: "))
#         self.Percentage=float(input("Enter percentage of student: "))
    
#     def CalculateRank(self):
#         if self.Percentage>90.0 and self.Percentage<100.0:
#             self.Rank="1st Rank"
#             print(self.Rank)
#         elif self.Percentage>70.0 and self.Percentage<=90.0:
#             self.Rank="2nd Rank"
#             print(self.Rank)
#         elif self.Percentage>50.0 and self.Percentage<=70.0:
#             self.Rank="3rd Rank" 
#             print(self.Rank)
#         elif self.Percentage>40.0 and self.Percentage<=50.0:
#             self.Rank="4th Rank"
#             print(self.Rank)
#         else:
#             self.Rank="Fail"
#             print(self.Rank)
#     def __str__(self):
#          return (f"StudentId: {self.StudentId} | Name: {self.Name} | Age: {self.Age} |Percentage={self.Percentage}% | Rank:{self.Rank}")
        
# s1=Student()
# s1.Accept()

# s1.CalculateRank()
# print(s1)
# s1.Display()




    