# Create a class MedicalStudent inherited from Student with following 
# :
# i. Data members :Specialization
# ii. MarksOfInternship
# b. Add the following methods :
# i. Parameterized constructor
# ii. Display
# iii. Accept
# iv. override Method CalculateRank
# v. Override __str__ Method

from Student import Student
class MedicalStudent(Student):
    def __init__(self,Id=0,Name="-",Age="-",Percentage="0" ,Rank="-",Specialization="-",MarksOfInternship="-"):
        super().__init__(Id,Name,Age,Percentage,Rank)
        self.specialization=Specialization
        self.MarksOfInternship=MarksOfInternship
    def Display(self):
        super().Display()
        # self.specialization=Specialization
        # self.MarksOfInternship
        print(f"StudentId: {self.StudentId} | Name: {self.Name} | Age: {self.Age} | Percentage={self.Percentage}% |Specialization: {self.specialization} | Marks Of Internship: {self.MarksOfInternship} ")

    
    def Accept(self):
        super().Accept()
        self.specialization=input("Enter your specialization: ")
        self.MarksOfInternship=int(input("Enter marks of internship: "))
    
    def CalculateRank(self):
        super().CalculateRank()

    def __str__(self):
        return (f"StudentId: {self.StudentId} | Name: {self.Name} | Age: {self.Age} |Percentage={self.Percentage}% |Branch: {self.Branch} | InternalMarks: {self.InternalMarks} | Specialization: {self.specialization} | Marks Of Internship: {self.MarksOfInternship}")
    
MS=MedicalStudent()
MS.Accept()
MS.CalculateRank()
MS.Display()
