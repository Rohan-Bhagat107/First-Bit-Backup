# Create a derived class from Student as EnggStudent with :
# a. Data members as :
# i. Branch
# ii. InternalMarks
# b. Add the following methods :
# i. Parameterized constructor
# ii. Display
# iii. Accept
# iv. override Method CalculateRank
# v. Override __str__ Method


from Student import Student
class EnggStudent(Student):
    def __init__(self,StudentId=0,Name="-",Age="-",Percentage=0,Branch="-",InternalMarks=0):
        super().__init__(StudentId,Name,Age,Percentage)
        self.Branch=Branch
        self.InternalMarks=InternalMarks
    
    def Display(self):
        super().Display()
        print(f"StudentId: {self.StudentId} | Name: {self.Name} | Age: {self.Age} | Percentage={self.Percentage}% |Branch: {self.Branch} | Internalmarks: {self.InternalMarks} ")

    def Accept(self):
        super().Accept() 
        self.Branch=input("Enter your branch: ")
        self.InternalMarks=int(input("Enter your internal marks: "))
        
    
    def CalculateRank(self):
        super().CalculateRank()
    
    def __str__(self):
         return (f"StudentId: {self.StudentId} | Name: {self.Name} | Age: {self.Age} |Percentage={self.Percentage}% |Branch: {self.Branch} | InternalMarks: {self.InternalMarks} ")


e1=EnggStudent()
e1.Accept()
e1.CalculateRank()
e1.Display()
print(e1)
    