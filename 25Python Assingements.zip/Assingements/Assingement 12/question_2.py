# 2.	Create a class Distance with data members as km,m and cm and add following methods :
# a.	Constructor
# b.	Destructor
# c.	Overload +,-  operator



class Distance():
    def __init__(self,km,m,cm):
        self.km=km
        self.m=m 
        self.cm=cm
    def __add__(self,other):
        dist=Distance(0,0,0)
        dist.km=self.km+other.km
        dist.m=self.m+other.m
        dist.cm=self.cm+other.cm
        print(f"{dist.km} km,{dist.m} m, {dist.cm} cm") 
    
    def __sub__(self,other):
        dist=Distance(0,0,0)
        dist.km=self.km-other.km
        dist.m=self.m-other.m
        dist.cm=self.cm-other.cm
        print(f"{dist.km} km,{dist.m} m, {dist.cm} cm")
        
    
       
    def __del__(self):
        print("Destructor is called")
        print("Uninitialized")

d1=Distance(1,200,500)
d2=Distance(3,600,900)
d1.__add__(d2)
d1.__sub__(d2)




#d3=d1.__add__(d2)
# d3=d1+d2
# print(d3)

