# 1.	Create a class Complex Number with data members as real and imag and add following methods :
# a.	Constructor
# b.	Destructor
# c.	Overload +,-  operator

class Complex_Number():
    def __init__(self,real,imag):
        self.real=real
        self.imag=imag
    def __add__(self,other):
        comp=Complex_Number(0,0)
        comp.real=self.real+other.real
        comp.imag=self.imag+other.imag
        print(f"The parts(real,imginary) of given complex number with + operator:{comp.real},{comp.imag}")
    
    def __sub__(self,other):
        root=Complex_Number(0,0)
        root.real=self.real-other.real
        root.imag=self.imag-other.imag
        print(f"The parts(real,imginary) roots of given complex number with - operator:{root.real},{root.imag}")
    
    def __del__(self):
        print("Destructor is called")
       

    
c1=Complex_Number(2,3)
c2=Complex_Number(3,5)
c1.__add__(c2)
c1.__sub__(c2)