class model_error(Exception):
    def __str__(self):
        return (f"You have enterd an Invalid model number, it is only upto 4 digits")

class screen_error(Exception):
    def __str__(self):
        return (f"You have entered Invalid Screen size, it should be between 12 inch to 70 inch")

class price_error(Exception):
    def __str__(self):
        return (f"You have eneterd invalid price, it should not be more than 5000")