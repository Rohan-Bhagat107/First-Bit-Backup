# Create class television that has members to hold the model number ,screen size and price. Take a member function to take input from user, If more than 4 digits are entered for model number, if screen size is smaller than 12 inches or greater than 70 inches or if the price is negative or greater than 5000 Rs, then throw an exception.
# Write a main() that instantiates an object and allows the user to enter and display 
# data. If exception is caught, replace all data member values with zer

from television_exception import *                                      
class television():
    def __init__(self,model_no,screen_size,price):
        self.model_no=model_no
        self.screen_size=screen_size
        self.price=price
        
        try:
            res=mode_check(model_no)
            if res==False:
                self.model_no=0
                self.screen_size=0
                self.price=0
                raise model_error
            else:
                self.model_no=model_no

        except model_error as m:
            print(m)

        else:
            try:
                if self.screen_size < 12 or self.screen_size>70:
                    self.model_no=0
                    self.screen_size=0
                    self.price=0
                    raise screen_error
                else:
                    self.screen_size=screen_size

            except screen_error as s:
                print(s)

            else:
                
                try:
                    if self.price<0 or self.price>5000:
                        self.model_no=0
                        self.screen_size=0
                        self.price=0
                        raise price_error
                    else:
                        self.price=price
                except price_error as p:
                    print(p)
    def __str__(self):
        return (f"Model_no: {self.model_no} | Screen_size: {self.screen_size} | Price: {self.price}")
        

#model_no=int(input("Enter model number of television: "))
def mode_check(no):
    model_count=0
    while no!=0:
        no%10
        no=no//10
        model_count+=1
    if model_count>4:
       return False
    else:
        return True
try:
    m=int(input("Enter model number: "))
    s=int(input("Enter screen size: "))
    p=int(input("Enter price: "))
except ValueError as v:
    print(v)
    print("Invalid input provided.It should be numeric")
else:
    t=television(m,s,p)
    print(t)
