class Invalidoperatorerror(Exception):
    def __str__(self):
        return (f"Invalid operator is provided")

# class Zero_DivisionError(Exception):
#     def __str__(self):
#         return (f"Division with zero is not possible")

