# Develop a simple calculator program that performs basic arithmetic operations (+, -, *, /) on two numbers provided by the user. The program should ask the user for the numbers and the operator. However, the program should handle the following 
# exceptions:
# a. Invalid Number: If the user enters a number that is not valid, catch the 
# exception and display an error message.
# b. Invalid Operator: If the user enters an operator other than "+", "-", "*", or 
# "/", catch the exception and display an error message.
# c. Division by Zero: If the user tries to divide by zero, catch the exception and 
# display an error message.
# Write a program that performs the requested arithmetic operation and 
# handles the exceptions as described above

from exception import *
choice="Yes"
while choice=="Yes":
    print('''What operation do you want to perform: 
             For addition press (+)
             For Subtraction press (-)
             For Multiplication press (*)
             For Division press(/)
        
               ''')
    
    try:

        choice=(input("Enter operator: "))
        if choice not in ("+","-","*","/"):
            raise Invalidoperatorerror
        
        n1=int(input("Enter 1st number: "))
        n2=int(input("Enter 2nd number: "))
            
    except Invalidoperatorerror as i:
        print(i)
    
    except ZeroDivisionError as z :
        print(z)
        print("Division with zero is not possible")

    except ValueError :
        # print(v)
        print("Invalid Number Please provide Appropriate number")
    
    
    else:
        if choice=="+":    
            Addition=n1+n2
            print(f"Sum of {n1} and {n2} is: {Addition}")
    
        if choice=="-":
            sub=n1-n2
            print(f"Subtraction of {n1} and {n2} is: {sub}")
        if choice=="*":
            mult=n1*n2
            print(f"Multiplication of {n1} and {n2} is: {mult}")
        if choice=="/":
            try:
               division=n1/n2
               if n2==0:
                raise ZeroDivisionError
            except ZeroDivisionError as z:
                print(z)
                print("Division with zero is not possible")
            else:
                print(f"Division of {n1} and {n2} is: {division}")
                
    finally:
        choice=input("Do you want to continue(Yes/No): ")
        if choice  not in ("Yes"):
            print("Thank You!")
            break
            



    


        