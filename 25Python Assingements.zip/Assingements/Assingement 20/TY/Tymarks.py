# Create another package “TY” which has a class TYMarks (Theory, Practical). 

class TYMARKS():
    def __init__(self,Theory,Practical):
        self.Theory=Theory
        self.Practical=Practical

        