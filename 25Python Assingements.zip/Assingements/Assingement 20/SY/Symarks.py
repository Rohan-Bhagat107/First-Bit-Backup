#  create a package “SY” which has class SYMARKS (Computer Total, MathsTotal, ElectronicsTotal). 

class SYMARKS():
    def __init__(self,Computer_Total,Maths_Total, Electronics_Total):
        self.comp=Computer_Total
        self.maths=Maths_Total
        self.entc=Electronics_Total
        