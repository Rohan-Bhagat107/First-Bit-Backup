# Create object of student class (Outside SY & TY package) having roll number, name, SYMakrs and TYMarks. Add the marksof SY and TY Computer subjects and calculate grade ("A" for >=70, "B" for >=60, "C" for >=50, “Pass Class” for >=40 else “Fail”) and display the result of the student in proper format


from SY.Symarks import *
from TY.Tymarks import *

class Student():
    def __init__(self,roll_number,name,symarks,tymarks):
        self.roll = roll_number
        self.name = name
        self.symarks = symarks
        self.tymarks = tymarks

    def grade_calculator(self):
        comp_total = self.symarks.comp + self.tymarks.Theory
        if comp_total >= 70:
            return 'A'
        elif comp_total >= 60:
            return 'B'
        elif comp_total >= 50:
            return 'C'
        elif comp_total >= 40:
            return 'Pass Class'
        else:
            return 'Fail'

        
if __name__ == '__main__':

    student_name=input("Enter Student name here: ")
    std_roll=int(input("Enter roll number of student here: "))

    c=int(input("Enter total marks of compuer subject of SY out of 100: "))
    m=int(input("Enter total marks of maths subject of SY out of 100: "))
    e=int(input("Enter total marks of electronics subject of SY out of 100: "))

    t=int(input("Enter theory marks of TY: "))
    p=int(input("Enter practical marks of TY: "))

    sy = SYMARKS(c,m,e)
    ty = TYMARKS(t,p)

    std = Student(std_roll,student_name,sy,ty)
    grade = std.grade_calculator()

    
    print('Roll Number:',std.roll)
    print('Student Name:',std.name)
    print('Grade:',grade)
