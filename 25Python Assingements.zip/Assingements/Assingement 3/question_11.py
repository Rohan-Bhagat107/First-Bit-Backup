# Author=Rohan
# Date=29-12-23
# Task-

#.11.	Accept age of five people and also per person ticket amount and then calculate total amount to ticket to travel for all of them based on following condition :
# a.	Children below 12 = 30% discount
# b.	Senior citizen (above 59) = 50% discount
# c.	Others need to pay full.


total=0
amt_per_person=100
a1=int(input("Enter age of 1st person: "))   #let the age be 7 years
if a1<12:                                      #true
    dis=amt_per_person+(12/100)
    total+=dis                               
elif a1>59:
    dis=amt_per_person/2
    total+=dis
else:
    total+amt_per_person

a2=int(input("Enter age of 2nd person: "))         #let the age be 61 years
if a2<12:
    dis=amt_per_person+(12/100)
    total+=dis
elif a2>59:                                      #true
    dis=amt_per_person/2
    total+=dis
else:
    total+=amt_per_person

a3=int(input("Enter age of 3rd person: "))          #let the age be 39 years
if a3<12:
    dis=amt_per_person+(12/100)
    total+=dis
elif a3>59:
    dis=amt_per_person/2
    total+=dis
else:                                              #true
    total+=amt_per_person                                   

a4=int(input("Enter age of 4th person: "))
if a4<12:
    dis=amt_per_person+(12/100)
    total+=dis
elif a4>59:
    dis=amt_per_person/2
    total+=dis
else:                                                   
    total+=amt_per_person

a5=int(input("Enter age of 5th person: "))
if a5<12:
    dis=amt_per_person+(12/100)
    total+=dis
elif a5>59:
    dis=amt_per_person/2
    total+=dis
else:
    total+=amt_per_person


print("Your total ticket bill is : ",total)







