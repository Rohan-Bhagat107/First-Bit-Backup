# Author=Rohan
# Date= 28-12-23

#task-
#W.A.P to take input angles of a triangle and check whether  triangle is valid or not

ang_1=int(input("Please enter first angle of triangle."))
ang_2=int(input("Please enter second angle of triangle."))
ang_3=int(input("Please enter third angle of triangle."))

if ang_1+ang_2+ang_3==180:
    print("It  is a triangle.")

else:
    print("It is not a triangle.")