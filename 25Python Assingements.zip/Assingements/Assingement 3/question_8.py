# Author=Rohan
# Date= 28-12-23
#task-
	# Write a program to prompt user to enter userid and password. After verifying userid and password display a 4 digit random number and ask user to enter the same. If user enters the same number then show him success message otherwise failed.

import random

reg_username=input("Please enter your username: ")
reg_password=input("Please enter your password: ")

login_username=input("Please enter your username: ")
login_password=input("Please enter your password: ")
if reg_username==login_username and reg_password==login_password:
   #generate 4 digit OTP(And print it on screen)
   otp=random.randint(1000,9999)
   print("OTP for your login is:",otp)
   #ask user for OTP
   user_otp=int(input("Please enter OTP that we have sent :"))
   #match the otp
   if(otp==user_otp):
      print("OTP matched ")
      print("Login is succesfull")
   else:
      print("Invalid OTP please re-enter")
else:
     print("Invalid Credentials")

