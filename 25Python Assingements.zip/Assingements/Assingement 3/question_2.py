# Author=Rohan
# Date= 28-12-23
 
# W. A. P to take any input of alphabet from user & check it is vowel or consonant 

alphabet=input("Please enter any alphabet in lowercase: ")
if alphabet=="a" or alphabet=="e"  or alphabet=="i" or  alphabet=="o"or alphabet=="u" :
    print("It is a vowel")
else:
    print("It is a consonent")