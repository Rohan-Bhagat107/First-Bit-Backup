# Author=Rohan
# Date= 28-12-23
 
# W.A.P to check whether a triangle is equilateral, isosceles or scalene triangle

side_1=int(input("Please enter first side of triangle."))
side_2=int(input("Please enter second side of triangle."))
side_3=int(input("Please enter third side of triangle."))

if side_1==side_2 and side_2==side_3 and side_1==side_3:
    print("It is an equlateral triangle.")

elif side_1==side_2 or side_2==side_3 or side_1==side_3:
    print("It is an isosceles triangle.")

else:
    print("It is a scalene triangle")