# Author=Rohan
# Date=29-12-23
# Task-

#.	Write a program to check if person is eligible to marry or not (male age >=21 and female age>=18)
gender=input("Please enter your gender (M or F):")

if gender=="M":
     m_age=int(input("Please enter your age: "))
     if m_age>=21:
     
        print("You are eligible to marry.")
     else:
        print("You are not eligible to marry.")

elif gender=="F":
     f_age=int(input("Please enter your age: "))
     if f_age>=18:
      print("You are eligible to marry.")
     else:
      print("You are not eligible to marry.")

else:
   print("Invalid Gender.")      


