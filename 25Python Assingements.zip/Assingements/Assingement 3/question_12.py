# Author=Rohan
# Date=29-12-23
# Task-

#.	Write a program to check if given 3 digit number is a palindrome or not.

no=int(input("Enter 3 digit number: "))
a=no%10
b=no//10
c=b%10
d=b//10

# print(a)
# print(b)
# print(c)
# print(d)

rev_no=a*100+c*10+d*1
if no==rev_no:
    print("Given number is a palindrome.")
else:
    print("It is not a palindrome.")