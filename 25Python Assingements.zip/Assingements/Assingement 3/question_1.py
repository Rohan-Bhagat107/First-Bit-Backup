# Author=Rohan
# Date= 28-12-23

# W.A. P to check if no. is +ve or -ve


no=int(input("Please enter a number."))
if no>0:
    print("Number you have entered is  positive.")

else:
    print("Number you have entered is  negative.")