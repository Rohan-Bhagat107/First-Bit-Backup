# Author=Rohan
# Date=28-12-23
# Task-
# 	Input 5 subject marks from user and display grade(eg.First class,Second class ..)

sub_1=int(input("Please enter marks obtained in first subject: "))
sub_2=int(input("Please enter marks obtained in second subject: "))
sub_3=int(input("Please enter marks obtained in third subject: "))
sub_4=int(input("Please enter marks obtained in fourth subject: "))
sub_5=int(input("Please enter marks obtained in fifth subject: "))
total=int(input("Please enter total marks: "))
marks_obtained=sub_1+sub_2+sub_3+sub_4+sub_5
percentage=(marks_obtained/total)*100

if percentage>=95 and percentage<100:
    print("1st division")
elif percentage>=80 and percentage<95:
    print("2nd Division")
elif percentage>=70 and percentage<80:
    print("3rd Division")
elif percentage >=60 and percentage<70:
    print("4th Division")
else:
    print("Fail")
