# Author=Rohan
# Date= 28-12-23

# W.A.P to check if user has enterd correct userid and password

reg_username=input("Please enter your username for future use.")
reg_pass=input("Please enter your password for future use.")

login_username=input("Please enter your  registerd username. ")
login_pass=input("Please enter your  registerd password. ")

if reg_username==login_username and reg_pass==login_pass:
    print("User-id & password are matched ")
    print("Login is succesfull")

else:
    print("Invalid Credentials")
    print("Please check it and retry.")