# Author=Rohan
# Date=29-12-23
# Task-

#	Write a program to input electricity unit charges and calculate total electricity bill according to the given condition:
# For first 50 units Rs. 0.50/unit
# For next 100 units Rs. 0.75/unit
# For next 100 units Rs. 1.20/unit
# For unit above 250 Rs. 1.50/unit
# An additional surcharge of 20% is added to the bill

charge=0
unit=int(input("Enter your electricity unit: "))
# bill_amt=unit*charge
if unit>=0 and unit<=50:
    charge=0.50
    bill_amt=unit*charge
    percentage=int(bill_amt*(20/100))
    total=bill_amt+percentage
    print("Your total electricity: ",int(total),"INR")
elif unit>50 and unit<=150:
    charge=0.75
    bill_amt=unit*charge
    percentage=int(bill_amt*(20/100))
    total=bill_amt+percentage
    print("Your total electricity: ",int(total),"INR")
elif unit>150 and unit<=250:
    charge=1.20
    bill_amt=unit*charge
    percentage=int(bill_amt*(20/100))
    total=bill_amt+percentage
    print("Your total electricity: ",int(total),"INR")
elif unit<0:
    print("Invalid Input")
else:
    charge=1.50
    bill_amt=unit*charge
    percentage=(bill_amt*(20/100))
    total=bill_amt+percentage
    print("Your total electricity: ",int(total),"INR")



