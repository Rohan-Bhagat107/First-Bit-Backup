# Author=Rohan
# Date= 28-12-23
#task-
# write a program to calculate profit and loss

cost_price=int(input("Please enter cost price of an item."))   # it is in RS
selling_price=int(input("Please enter selling price of that item."))  # it is in RS

profit=selling_price-cost_price  # it is in RS
loss=cost_price-selling_price     #it is in RS

if selling_price>cost_price:
    print("Profit on your item is: ",profit,"INR")  # it is in RS

else:
    print("Loss on your item is: ",loss ,"INR")   # it is in RS