# Author=Rohan
# Date= 28-12-23
 
# W. A. P to take  input of all sides of a triangle and check whether triangle is valid or not

side_1=int(input("Please enter first side of triangle."))
side_2=int(input("Please enter second side of triangle."))
side_3=int(input("Please enter third side of triangle."))

if side_1+side_2>=side_3 and side_1+side_3>=side_2 and side_2+side_3>=side_1:
    print("It is a triangle.")

else:
    print("It is not a triangle")