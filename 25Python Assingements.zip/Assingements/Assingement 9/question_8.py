#	Write a program to check whether a number is prime or not using recursion.


def findPrimeRec(n, f):

    if n == f:
        return True
    else:
        if n % f == 0:
            return False
        else:
            return findPrimeRec(n, f+1)
n=int(input("Enter a number that you want to check: "))
res = findPrimeRec(n, 2)
if res==True:
    print(f"{n} is a prime number.")
else:
    print(f"{n} is not a prime number.")











# def is_prime(n, num=2):
#     if n < 2:
#         return False
#     elif n == 2:
#         return True
#     elif n % num == 0:
#         return False
#     # elif num * num > n:
#     #     return True
#     else:
#         return is_prime(n, num + 1)

# # Taking user input
# num = int(input("Enter a number: "))

# # Checking and displaying the result
# if is_prime(num):
#     print(f"{num} is a prime number.")
# else:
#     print(f"{num} is not a prime number.")
