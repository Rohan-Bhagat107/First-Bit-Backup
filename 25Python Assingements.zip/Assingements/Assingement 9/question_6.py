#Write a program to print Fibonacci series using recursion.
def fibo(term,a,b):
    if term==0:
        return
    else:
        c=a+b
         
        print(c)
        return fibo(term-1,b,c)
    
term=int(input("Enter how many fibonacci terms you want to print: "))
fibo(term,0,1)

