# Write a program to reverse a number using recursion

def rev_no(n,rev):
    if n==0:
        return rev
    else:
        return rev_no(n//10,rev*10+n%10)


no=int(input("Enter a number: "))
res=rev_no(no,0)
print("Reverse of",no,"is: ",res)