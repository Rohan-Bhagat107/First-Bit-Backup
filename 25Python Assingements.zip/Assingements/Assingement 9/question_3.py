#	Write a program to reverse a given number using recursive function.

def reverse_of_number(n,rev):
    if n==0:
        return rev
    else:
        return reverse_of_number (n//10,rev*10+n%10)
    

no=int(input("Enter a number: "))
res=reverse_of_number(no,0)
print("Reverse of",no,"is: ",res)
