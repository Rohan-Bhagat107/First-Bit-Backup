#	Write a program to check if given number is Armstrong or not using recursive function


def power(n):
    count=0
    while n!=0:
        digit=n%10
        n=n//10
        count+=1
    return count

def is_Armstrong(no,org_no):
    i=power(org_no)
    if no==0:
        return 0
    else:
        sum=((no%10)**i)+is_Armstrong(no//10,org_no)
        return sum

no=int(input("Enter your number: "))
org_no=no
res=is_Armstrong(no,org_no) 
if no==res:
    print(no,"is an armstrong number")
else:
    print(no,"is not an armstrong number")

