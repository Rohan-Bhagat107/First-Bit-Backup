#	Write a program to calculate the m to the power n using recursion.

def power_calualtor(no,p):
    if p==0:
        return 1
    else:
        return no*power_calualtor(no,p-1)

no=int(input("Enter a number: "))
p=int(input("Enter  power: "))
res=power_calualtor(no,p)
print(no,"to the power",p,"is: ",res)