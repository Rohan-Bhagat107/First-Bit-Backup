# Write a program to find factorial using recursion.
def factorial(n):
    if n==1:
        return 1
    else:
        return n*factorial(n-1)

no=int(input("Enter a number of which you want the factorial: "))
res=factorial(no)
print("Factorial of given number is: ",res)