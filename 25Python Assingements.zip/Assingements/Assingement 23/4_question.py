#  Quiz Game: Create an interactive quiz game with multiple-choice questions. Display 
# questions one at a time and allow the user to select an answer. Provide feedback on 
# whether the selected answer is correct or incorrect.

from tkinter import *
from tkinter import messagebox

class Game:
    def __init__(self, window):
        self.window = window
        self.window.title("Quiz Game")

        self.questions = [
            {
                "question": "A group of three powerful people?",
                "options": ["Trio", "Tritium", "Trivet", "Triumvirate"],
                "answer": "Triumvirate"
            },
            {
                "question": "A place where birds are kept?",
                "options": ["Apiary", "Aviary", "Nursery", "Extempore"],
                "answer": "Aviary"
            },
            {
                "question": "A building where dead bodies are kept?",
                "options": ["Aviary", "Hospital", "Zoo", "Mortuary"],
                "answer": "Mortuary"
            },
            {
                "question":" One who is not easily pleased by anything?",
                "options": ["Maiden","Pessimist","Vulnerable"," Fastidious"],
                "answer":" Fastidious"
            },
            {
                "question":"A person who regards the whole world as his country",
                "options":["Cosmopolitan","Nationalist","Patriot","Metropolitan"],
                "answer":"Cosmopolitan"

            }
        ]

        self.current_question_index = 0
        self.score = 0

        self.question_label =Label(self.window, text="")
        self.question_label.pack()

        self.option_buttons = []
        for i in range(4):
            button =Button(self.window, text="", command=lambda a=i: self.check_answer(a))
            button.pack(fill=X, padx=10, pady=5)
            self.option_buttons.append(button)

        self.next_question()

    def next_question(self):
        if self.current_question_index < len(self.questions):
            question_data = self.questions[self.current_question_index]
            self.question_label.config(text=question_data["question"])
            for i, option in enumerate(question_data["options"]):
                self.option_buttons[i].config(text=option)
        else:
            messagebox.showinfo("Quiz Completed", f"Your score is {self.score}/{len(self.questions)}")
            self.window.destroy()

    def check_answer(self, selected_option):
        correct_answer = self.questions[self.current_question_index]["answer"]
        if self.option_buttons[selected_option].cget("text") == correct_answer:
            self.score += 1
            messagebox.showinfo(f"Your answer is correct!")
        else:
            messagebox.showerror("Incorrect", f"Sorry, the correct answer is {correct_answer}.")

        self.current_question_index += 1
        self.next_question()

    

if __name__ == "__main__":
    wind =Tk()
    QG = Game(wind)
    wind.mainloop()
    
