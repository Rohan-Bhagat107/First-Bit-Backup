# Develop a simple login system with a username and password field. Implement user 
# authentication, and show a success message if the login is successful, or an error 
# message if the login fails

from tkinter import *
from tkinter import messagebox


wind =Tk()
wind.geometry("400x400")
wind.title("Login page")

login_details = ['localhost','pass@123']

def verify(username, password):
    if username in login_details and password in login_details:
        return True
    else:
        return False

def login():
    username = username_entry.get()
    password =password_entry.get()

    if verify(username, password):
        messagebox.showinfo("Success", "Login successful!")
    else:
        messagebox.showerror("Error", "Invalid username or password")




label_username = Label(wind, text="Username")
username_entry = Entry(wind)

label_password = Label(wind, text="Password")
password_entry = Entry(wind, show="*")

btn = Button(wind, text="Login", command=login)



label_username.grid(row=1,column=1)
username_entry.grid(row=1,column=2)
label_password.grid(row=2,column=1)
password_entry.grid(row=2,column=2)
btn.grid(row=3,column=2)

wind.mainloop()