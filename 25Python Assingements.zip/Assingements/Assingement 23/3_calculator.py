from tkinter import *

wind =Tk()
wind.title("Calculator")
wind.geometry("400x400")

def calculate():
    first_number = float(first_number_entry.get())
    second_number = float(second_number_entry.get())
    operation = operator.get()

    if operation == "+":
        result = first_number + second_number
    elif operation == "-":
        result = first_number - second_number
    elif operation == "*":
        result = first_number * second_number
    elif operation == "/":
        result = first_number / second_number
    else:
        result = "Invalid Operation"

    result_label.config(text="Result: " + str(result))



first_number = Label(wind, text="First Number")


first_number_entry = Entry(wind)


second_number = Label(wind, text="Second Number")

second_number_entry = Entry(wind)

operator = StringVar()
operator.set("+")

addition = Radiobutton(wind, text="+", variable=operator, value="+")

subtraction = Radiobutton(wind, text="-", variable=operator, value="-")

multiplication = Radiobutton(wind, text="*", variable=operator, value="*")

division = Radiobutton(wind, text="/", variable=operator, value="/")

calculate = Button(wind, text="Calculate", command=calculate)

result_label = Label(wind, text="Result:")

first_number.grid(row=0, column=0)
first_number_entry.grid(row=0, column=1)
second_number.grid(row=1, column=0)
second_number_entry.grid(row=1, column=1)
addition.grid(row=2, column=0)
subtraction.grid(row=2, column=1)
multiplication.grid(row=3, column=0)
division.grid(row=3, column=1)
calculate.grid(row=4, column=0, columnspan=2, pady=10)
result_label.grid(row=5, column=0, columnspan=2)


wind.mainloop()
