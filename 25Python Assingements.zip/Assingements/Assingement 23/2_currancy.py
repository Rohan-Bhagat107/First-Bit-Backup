# Build a currency converter application that converts between different currencies. The 
# user should be able to enter an amount, select the input currency, select the output 
# currency, and see the converted amount.



import tkinter as tk
from tkinter import ttk


# class CurrencyConverter:
#     def __init__(self, root):
#         self.root = root
#         self.root.title("Currency Converter")
#         self.root.geometry("300x150")
        
#         self.from_currency = tk.StringVar()
#         self.to_currency = tk.StringVar()
#         self.amount = tk.StringVar()
#         self.converted_amount = tk.StringVar()
        
#         self.from_currency_label = ttk.Label(self.root, text="From Currency:")
#         self.from_currency_label.grid(row=0, column=0, padx=5, pady=5)
#         self.from_currency_entry = ttk.Entry(self.root, textvariable=self.from_currency)
#         self.from_currency_entry.grid(row=0, column=1, padx=5, pady=5)
        
#         self.to_currency_label = ttk.Label(self.root, text="To Currency:")
#         self.to_currency_label.grid(row=1, column=0, padx=5, pady=5)
#         self.to_currency_entry = ttk.Entry(self.root, textvariable=self.to_currency)
#         self.to_currency_entry.grid(row=1, column=1, padx=5, pady=5)
        
#         self.amount_label = ttk.Label(self.root, text="Amount:")
#         self.amount_label.grid(row=2, column=0, padx=5, pady=5)
#         self.amount_entry = ttk.Entry(self.root, textvariable=self.amount)
#         self.amount_entry.grid(row=2, column=1, padx=5, pady=5)
        
#         self.convert_button = ttk.Button(self.root, text="Convert", command=self.convert)
#         self.convert_button.grid(row=3, column=0, columnspan=2, padx=5, pady=5)
        
#         self.converted_amount_label = ttk.Label(self.root, textvariable=self.converted_amount)
#         self.converted_amount_label.grid(row=4, column=0, columnspan=2, padx=5, pady=5)
        
#     def convert(self):
#         from_curr = self.from_currency.get().upper()
#         to_curr = self.to_currency.get().upper()
#         amount = float(self.amount.get())
        
#         url = f"https://api.exchangerate-api.com/v4/latest/{from_curr}"
#         response = requests.get(url)
#         data = response.json()
        
#         exchange_rate = data["rates"][to_curr]
#         converted_amount = amount * exchange_rate
        
#         self.converted_amount.set(f"{amount} {from_curr} = {converted_amount} {to_curr}")

# if __name__ == "__main__":
#     root = tk.Tk()
#     converter = CurrencyConverter(root)
#     root.mainloop()

# from tkinter import *
# from forex_python.converter import CurrencyRates

# def convert_currency():
#     input_amount = float(amount_entry.get())
#     input_curr = input_currency.get()
#     output_curr =output_currency.get()

#     c = CurrencyRates()
#     converted_amount = c.convert(input_curr, output_curr, input_amount)
#     result.config(text=f"{converted_amount:.2f} {output_curr}")

# # Create the main window
# wind = Tk()
# wind.title("Currency Converter")

# # Create input frame
# input_frame =Frame(wind)
# input_frame.pack(pady=10)

# # Amount label and entry
# amount = Label(input_frame, text="Amount:")

# amount_entry = Entry(input_frame)
# amount_entry.grid(row=0, column=1)

# # Input currency dropdown
# input_currency = StringVar()
# input_currency.set("USD")  # Default value
# input_currency_label =Label(input_frame, text="From:")
# input_currency_label.grid(row=0, column=2)
# input_currency_menu = OptionMenu(input_frame, input_currency,"USD", "EUR", "GBP")
# input_currency_menu.grid(row=0, column=3)

# # Output currency dropdown
# output_currency =StringVar()
# output_currency.set("EUR")  # Default value
# output_currency_label =Label(input_frame, text="To:")
# output_currency_label.grid(row=0, column=4)
# output_currency_menu =OptionMenu(input_frame, output_currency,"USD","EUR","GBP" )
# output_currency_menu.grid(row=0, column=5)

# # Convert button
# btn = tk.Button(input_frame, text="Convert", command=convert_currency)
# btn.grid(row=0, column=6)

# # Result label
# result =Label(wind, text="")
# result.pack(pady=10)



# wind.mainloop()
# from tkinter import *
# from forex_python.converter import CurrencyRates

# def convert_currency():
#     input_amount = float(amount_entry.get())
#     input_currency = input_curr.get()
#     output_currency = output_curr.get()

#     c = CurrencyRates()
#     converted_amount = c.convert(input_currency, output_currency, input_amount)
#     lbl_result.config(text=f"{converted_amount:.2f} {output_currency}")

# wind = Tk()
# wind.title("Currency Converter")


# input_frame =Frame(wind)
# input_frame.pack(pady=10)


# amount_label = Label(input_frame, text="Amount:")
# amount_entry = Entry(input_frame)

# input_curr = StringVar()
# input_curr_label = Label(input_frame, text="From:")
# input_curr_menu = OptionMenu(input_frame, input_curr, "USD", "EUR", "GBP")

# output_curr =StringVar()
# output_cur_label = Label(input_frame, text="To:")
# output_curr_menu = OptionMenu(input_frame, output_curr, "USD", "EUR", "GBP")

# btn =Button(input_frame, text="Convert", command=convert_currency)
# result = Label(wind, text="")
# result

# # amount_label.grid(row=1, column=1)
# # amount_entry.grid(row=1, column=2)
# # input_curr_label.grid(row=2, column=2)
# # input_curr_menu.grid(row=3, column=2)
# # output_cur_label.grid(row=4, column=2)
# # output_curr_menu.grid(row=5, column=2)
# # btn.grid(row=6, column=2)
# # result.pack(pady=10)


# amount_label.grid(row=0, column=0)
# amount_entry.grid(row=0, column=1)
# input_curr_label.grid(row=0, column=2)
# input_curr_menu.grid(row=0, column=3)
# output_cur_label.grid(row=0, column=4)
# output_curr_menu.grid(row=0, column=5)
# btn.grid(row=0, column=6)
# result.pack(pady=10)


# wind.mainloop()

# from tkinter import *
# from forex_python.converter import CurrencyRates

# def currency_converter():
#     input_amount = float(amount_entry.get())
#     input_currency = input_curr.get()
#     output_currency = output_curr.get()

#     c = CurrencyRates()
#     converted_amount = c.convert(input_currency, output_currency, input_amount)
#     lbl_result.config(text=f"{converted_amount:.2f} {output_currency}")

# wind = tk.Tk()
# wind.title("Currency Converter")

# input_frame =Frame(wind)
# input_frame.pack(pady=10)


# amount_label = Label(input_frame, text="Amount:")
# amount_entry =Entry(input_frame)

# input_curr = StringVar()
# input_curr_label = Label(input_frame, text="From:")
# input_curr_menu = OptionMenu(input_frame, input_curr, "USD", "EUR", "GBP")


# output_curr = StringVar()
# output_curr_label = Label(input_frame, text="To:")
# output_curr_menu = OptionMenu(input_frame, output_curr, "USD", "EUR", "GBP")


# btn = Button(input_frame, text="Convert", command=currency_converter)
# result = Label(wind, text="")
# result.pack(pady=10)


# amount_label.grid(row=0, column=0)
# amount_entry.grid(row=0, column=1)
# input_curr_label.grid(row=0, column=2)
# input_curr_menu.grid(row=0, column=3)
# output_curr_label.grid(row=0, column=4)
# output_curr_menu.grid(row=0, column=5)
# btn.grid(row=0, column=6)

# wind.mainloop()


from tkinter import *
from forex_python.converter import CurrencyRates

def convert_currency():
    input_amount = float(amount_entry.get())
    input_currency = input_curr.get()
    output_currency = output_curr.get()

    c = CurrencyRates()
    converted_amount = c.convert(input_currency, output_currency, input_amount)
    lbl_result.config(text=f"{converted_amount:.2f} {output_currency}")

wind = Tk()
wind.title("Currency Converter")


input_frame =Frame(wind)
input_frame.pack(pady=10)


amount_label = Label(input_frame, text="Amount:")
amount_entry = Entry(input_frame)

input_curr = StringVar()
input_curr.set("USD")  
input_curr_label =Label(input_frame, text="From:")
input_curr_menu = OptionMenu(input_frame, input_curr, "USD", "EUR", "GBP")


output_curr=StringVar()
output_curr.set("EUR") 
 
output_curr_label = Label(input_frame, text="To:")
output_curr_menu = OptionMenu(input_frame, output_curr, "USD", "EUR", "GBP")


btn = Button(input_frame, text="Convert", command=convert_currency)
result = Label(wind, text="")
result.pack(pady=10)


amount_label.grid(row=0, column=0)
amount_entry.grid(row=0, column=1)
input_curr_label.grid(row=0, column=2)
input_curr_menu.grid(row=0, column=3)
output_curr_label.grid(row=0, column=4)
output_curr_menu.grid(row=0, column=5)
btn_convert.grid(row=0, column=6)


wind.mainloop()
