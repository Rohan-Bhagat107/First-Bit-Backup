#	Write a program to check if entered number is a palindrome or not.

def is_palindrome(n):
    org_no=n
    rev=0
    while n!=0:
        rev=rev*10+n%10
        n=n//10
    if rev==org_no:
        return True
    else:
        return False


no=int(input("Enter a number: "))
res=is_palindrome(no)
if res==True:
    print(no,"is a plaindrome.")
else:
    print(no,"is not a palindrome.")