#	Write a program to calculate area of rectangle

#With para with return

def area(length,breadth):
    area=length*breadth
    return area


l=float(input("Enter length of rectangle: "))
b=float(input("Enter breadth of rectangle: "))
res=area(l,b)
print("Area of rectangle having length",l,"unit and breadth of",b,"unit is: ",int(res),"sq unit")
    