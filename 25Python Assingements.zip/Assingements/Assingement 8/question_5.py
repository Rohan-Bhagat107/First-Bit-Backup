# Sum of all prime numbers between 1 to n

#with para with return

def sum_of_prime(n):
    sum=0
    for i in range(2,n+1):
        for j in range(2,i):
            if i%j==0:
                break
        else:
            sum+=i
    return sum

no=int(input("Enter a number upto which you want sum: "))  
res=sum_of_prime(no)
print("Sum of all prime numbers from 1 to",no,"is: ",res)

