# Write a program to calculate area of circle

#With para with return

def area_of_circle(r):
    return 3.14*r*r


radius=float(input("Enter radius of circle: "))
res=area_of_circle(radius)
print("Area of circle having radius",radius,"unit is: ",int(res),"sq unit")