#	Write a program to  print the following Fibonacci series using functions:
#       1  1  2  3 5 8  n terms

def fibo(n,a,b):
    
    for i in range(1,n+1):
      c=a+b
      print(c)
      a=b
      b=c


term=int(input("Enter a number of term upto which you want the fibonacci series: "))  
fibo(term,1,0)


