#Write a program to check if entered year is a leap year or not.

def is_leap_year(y):
    if y%4==0:
        if y%100==0:
            if y%400==0:
                return True
            else:
                return False
        else:
            return True
        
    else:
        return False
    
year=int(input("Enter year: "))
res=is_leap_year(year)
if res==True:
    print(year,"is a leap year.")
else:
    print(year,"is not a leap year.")
        