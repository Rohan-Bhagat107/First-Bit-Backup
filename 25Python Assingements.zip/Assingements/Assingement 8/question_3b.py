# Write a program to find sum of following series using functions :
#	1!+ 2! + 3! + 4!+….. + n!

#With para with return

def sum_of_series(n):
    sum=0
    for i in range(1,n+1):
        fact=1
        for j in range(1,i+1):
            fact=fact*j
        sum+=fact    
    return sum


no=int(input("Enter a number upto which you want sum of factorials: "))
res=sum_of_series(no)
print("Sum of factorial from 1 to",no,"is: ",res)