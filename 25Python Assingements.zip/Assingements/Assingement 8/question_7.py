#Write a program to find sum of digits of a number.

def sum_of_digit(n):
    sum=0
    while n!=0:
            digit=n%10
            sum=sum+digit
            n=n//10
    return sum


no=int(input("Enter a number: "))
res=sum_of_digit(no)
print("Sum of digits of",no,"is: ",res)