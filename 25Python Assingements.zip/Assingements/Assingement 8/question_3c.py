# Write a program to find sum of following series using functions :
#	1^1 + 2^2 + 3^3+ …… n^n

#With para with return

def sum_of_series(n):
    
    sum=0
    for i in range(1,n+1):
        sum+=i**i
        
    return sum


no=int(input("Enter a number upto which you want sum: "))
res=sum_of_series(no)
print("Sum of series from 1 to",no,"is: ",res)