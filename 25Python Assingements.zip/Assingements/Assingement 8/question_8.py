# Write a program find reverse of a number
def reverse_of_number(n):
    rev=0
    while n!=0:
        rev=rev*10+n%10
        n=n//10
    return rev

no=int(input("Enter a number: "))
res=reverse_of_number(no)
print("Reverse of",no,"is: ",res)