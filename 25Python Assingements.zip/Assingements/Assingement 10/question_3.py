#Create a class "Shirt" with members as sid,sname,type(formal etc..),price and size(small,large.etc) 
#Also Add following methods-
#1)constructor (supports both parameterised and non parameterised)
#2)Destructor
#3)Showshirt

class Shirt():
    def __init__(self,id=0,name="-",type="-",price=0,size=" "):
        self.sid=id
        self.sname=name
        self.type=type
        self.price=price
        self.size=size
    def showshirt(self):
        print(f"Name of shirt is: {self.sname} | Type: {self.type} | Price: {self.price} | Size: {self.size}")
    
    def __del__(self):
        print("Destructor is called")
        print("Uninitialized")

    
s1=Shirt(289,"Half Slevs","Formal",999,"Medium")
s2=Shirt(226,"Full Sleevs","Western",1500,"Long")
s3=Shirt(101,"Half Sleevs","Casual",1110,"Small")

s1.showshirt()
del(s1)
print("------------------------------")
s2.showshirt()
del(s2)
print("------------------------------")
s3.showshirt()

