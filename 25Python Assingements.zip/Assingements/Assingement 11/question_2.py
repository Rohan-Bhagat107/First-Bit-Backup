# 2.	Create a class Product with members as pid,pname,price and quantity .Add following methods: 
# e.	Constructor (Support both parameterized and parameterless) 
# f.	Destructor  
# g.	ShowBook 
# h.	Add static member discount. 
# i.	Provide methods for applying discount on price of product.

class Product():
    discount=0.9
    def __init__(self,id,name,price,quantity):
        self.pid=id
        self.pname=name
        self.price=price
        self.quantity=quantity
    
    def ShowProduct(self):
        print(f"Name of product is: {self.pname},price of product is: {self.price} INR,Quantity of product: {self.quantity}")
    
    def discount(self):
        amount=self.price*Product.discount
        print(f"price of product after 10% discount is: {amount} INR")
    
    def __del__(self):
        print("Destructor is called")
        print("Uninitialized")
     
p1=Product(1,"Jacket",999,2)
p1.ShowProduct()

p2=Product(2,"T-shirt",500,3)
p2.ShowProduct()