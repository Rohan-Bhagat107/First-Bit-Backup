# 3.	Create a class Shirt  with members as sid,sname,type(formal etc), price and size(small,large etc) .Add following methods: 
# j.	Constructor (Support both parameterized and parameterless) 
# k.	Destructor  
# l.	ShowBook 
# m.	For each size of shirt price should change by 10%.
# (eg. If 1000 is price then small price = 1000, medium = 1100,large=1200 and xlarge=1300) Use static concept.

class Shirt():
    increase=0
    def __init__(self,id,name,type,price,size):
        self.sid=id
        self.sname=name
        self.stype=type
        self.price=price
        self.size=size
        
    def ShowShirt(self):

        #conditions for size check
        if self.size=="Small":
          Shirt.increase+= self.price*1
        elif self.size=="Medium":
          Shirt.increase+=self.price*1.1
        elif self.size=="Large":
          Shirt.increase+=self.price*1.3
        elif self.size=="Xlarge":
            Shirt.increase+=self.price*1.4
        else:
            print("Invalid size")
            
            #cheking the condition for printing
        if self.size=="Small" or self.size=="Medium" or self.size=="Large" or self.size=="Xlarge":
          print(f"Name of product is: {self.sname} | Type: {self.stype} | Size: {self.size} | Price: {Shirt.increase} INR")
        else:
          print("Try next time....")

          #Destructor
    def __del__(self):
         print("Destructor is called")
         print("Uninitialized")
     

s1=Shirt(1,"Shirt","Formal",1000,"large")
s1.ShowShirt()
print("------------------------------------------------")

s2=Shirt(2,"T-shirt","Western",1500,"Small")
s2.ShowShirt()
print("------------------------------------------------")

s3=Shirt(3,"Shirt","Half-sleeves",750,"Medium")
s3.ShowShirt()