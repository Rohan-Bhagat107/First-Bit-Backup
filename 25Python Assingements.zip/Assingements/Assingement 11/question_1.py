# 1.	Create a class Book with members as bid,bname,price and author.Add following methods: 
# a.	Constructor (Support both parameterized and parameterless) 
# b.	Destructor  
# c.	ShowBook 
# d.	Add static variable count and also maintain count of objects created.

class Book():
    count=0
    def __init__(self,id=0,name="-",price=0,author="-"):
        self.bid=id
        self.bname=name
        self.price=price
        self.author=author
        Book.count+=1
    def ShowBook(self):
        print(f"Name of book is: {self.bname} which has price of RS: {self.price} and the name of author is: {self.author}")
    def __del__(self):
        print("Destructor is called ")
        print("Uninitialized")
    
b1=Book(1,"ABC",250,"XYZ")
b2=Book(3,"PQR",999,"ABC")

b1.ShowBook()
print("------------------------")
b2.ShowBook()
print("--------------")
