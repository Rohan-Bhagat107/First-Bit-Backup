# Write a generator function that mimics the behavior of the built-in 
# range() function. The generator should take start, stop, and step 
# arguments and yield numbers within the specified range

def my_range(start, stop, step=1):
    a = start
    while a < stop:
        yield a
        a += step


start=int(input("Enter start of your range: "))
stop=int(input("Enter stop of your range: "))
res=my_range(start,stop)
print(res)
for i in res:
    print(i)

