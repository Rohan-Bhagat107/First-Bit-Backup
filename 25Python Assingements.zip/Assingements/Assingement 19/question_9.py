# Implement a generator function that yields palindrome numbers. Palindromes are numbers that read the same backward as forward 
# (e.g., 121, 1331). Generate palindromes lazily and infinitely


def get_palindrome(start,end):
      for i in range(start,end+1):
        org_no=i
        rev=""
        while i>0:
            digit=i%10
            i=i//10
            rev=rev+str(digit)
        if rev==str(org_no):
            yield org_no
    
start=int(input("Enter start of your range: "))
end=int(input("Enter End of your range: "))
res=get_palindrome(start,end)
for i  in res:
    print(i)