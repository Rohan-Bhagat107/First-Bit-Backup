# Use a nested list comprehension to find all of the numbers from 1–1000 that are divisible by any single digit.
num2=[]
num=[x for x in range(1,1001) for y in range(1,10) if x%y==0 ]

for i in num:
    if i not in num2:
        num2.append(i)
    else:
        continue
print(num2)
