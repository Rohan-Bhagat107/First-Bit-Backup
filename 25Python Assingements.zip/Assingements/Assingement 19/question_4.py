#Remove all of the vowels in a string (take input from user)

string=input("Enter any string: ")
remove=[x for x in string if x not in ("a","e","i","o","u","A","E","I","O","U")]
for i in remove:
    print(i,end="")