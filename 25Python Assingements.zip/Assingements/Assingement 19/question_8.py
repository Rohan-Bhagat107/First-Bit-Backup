# We want to generate Fibonacci numbers up to a certain limit. Instead of computing and storing the entire sequence in memory, create generator to yield Fibonacci numbers one by one,  conserving memory and allowing for easy iteration.
def fibo():
    a,b=0,1
    while True:
        c=a+b
        yield c
        a,b=b,c

f=fibo()
print(f)

n=int(input("How many fibbo terms you want: "))
for x in range(n):
    print(next(f))