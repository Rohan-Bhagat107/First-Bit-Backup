#Use a dictionary comprehension to count the length of each word in a sentence (take input from user)

string =input("Enter any string: ")
str_list=string.split(" ")

str_dict={i:len(i) for i in str_list}
print(str_dict)
