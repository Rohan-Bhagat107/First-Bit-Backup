#Count the number of spaces in a string (take input from user)
string=input("Enter any string: ")
count=[x for x in string if x==" " ]
print("Total number of space is: ",len(count))