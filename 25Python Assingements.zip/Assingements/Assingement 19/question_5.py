#Find all of the words in a string that are less than 5 letters (take input from user)
string =input("Enter any string: ")
splited_words=string.split(" ")

words=[x for x in splited_words if len(x)<5 ]
print (words)