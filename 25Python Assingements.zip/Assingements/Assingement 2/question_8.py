# Author=Rohan
# Date=26-12-23

# Task-
#   	Write a program to swap two numbers using third variable
first_no=int(input("Please enter 1st no.: "))
second_no=int(input("Please enter 2nd no.: "))
 
third_no=first_no
first_no=second_no
second_no=third_no
print("Swaped numbers are :",first_no,second_no)
