# Autor=Rohan
# Date=25-12-23

#  convert time entered in hh,min,and sec into seconds
time=int(input("Enter time in hr: ")) #it is in hr
sec=time*3600           #it is in sec
print("converted time from",time,"hr","into second is: ",sec,"seconds")
min=int(input("Enter time in min: "))   #it is in min
sec2=min*60
print("converted time from",min,"min","into second is: ",sec2,"seconds")
