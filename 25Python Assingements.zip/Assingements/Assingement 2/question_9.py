# Author=Rohan
# Date=26-12-23

# Task-
#  	Write a program to swap two numbers without using third variable.

a=int(input("Please enter first no.: "))
b=int(input("Please enter second no.: "))
a,b=b,a
print("Swaped numbers without third variable are :",a,b)