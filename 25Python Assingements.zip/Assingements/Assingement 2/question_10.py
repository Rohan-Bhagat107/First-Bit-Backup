# Author=Rohan
# Date=26-12-23
                #this logic is applicable for 3 digit no. only

# Task-
#  	Write a program to reverse three-digit number

no=int(input("Please enter three digit number: "))
a=no%10
b=no//10
c=b%10
d=b//10
print("Reverse number of",no,"is: ",(a*100+c*10+d*1))