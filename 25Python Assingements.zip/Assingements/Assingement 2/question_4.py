# Author=Rohan
# Date=26-12-23

# Task-
# 	WAP to calculate area of triangle and rectangle 

base=int(input("Plase enter base of triangle : ")) #it is in unit
height=int(input("Pleae enter height of triangle : "))  #it is in unit
area=0.5*base*height

print("Area of triangle is: ",int(area),"sq.unit")

length=int(input("Plase enter length of rectangle : "))  #it is in unit
breadth=int(input("Please enter breadth of rectangle : "))  #it is in unit
area=length*breadth

print("Area of triangle is: ",int(area),"sq.unit")

