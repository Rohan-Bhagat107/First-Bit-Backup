# Author=Rohan
# Date=26-12-23

# Task-
#  	WAP to calculate total salary of employee based on basic, da=10% of basic, ta=12% of basic, hra=15% of basic


basic=int(input("Please enter basic amount: "))
da=basic*10/100
ta=basic*12/100
hra=basic*15/100

total_salary=basic+da+ta+hra
print("Total salary of employee based on basic is: ",total_salary)