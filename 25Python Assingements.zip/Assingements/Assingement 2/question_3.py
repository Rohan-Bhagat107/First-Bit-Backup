# Autor=Rohan
# Date=25-12-23

#.	convert distance given in feet and incesh into meter and centimeter

dis_feet=int(input("Please enter distance in feet: "))
dis_meter=0.3*dis_feet
dis_centi=30*dis_feet

print("Converted distance from",dis_feet,"feet","into meter is:",dis_meter,"m")
print("Converted distance from",dis_feet,"feet","into centimeter is:",dis_centi,"cm")

dis_inch=int(input("Please enter distance in inch: "))
dis_meter2=0.025*dis_inch
dis_centi2=2.54*dis_inch

print("Converted distance from",dis_inch,"inch","into meter is:",dis_meter2,"m")
print("Converted distance from",dis_inch,"inch","into centimeter is:",dis_centi2,"cm")


