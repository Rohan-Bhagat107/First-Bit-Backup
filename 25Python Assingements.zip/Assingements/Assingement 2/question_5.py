# Author=Rohan
# Date=26-12-23

# Task-
#    	WAP to calculate selling price of book based on cost price and discount

price=int(input("Please enter price of book: "))  #it is INR
discount=int(input("Please enter discount applicable for book: "))  #It is in %
selling_price=price-(price*discount/100) #It is in INR
print("Selling of price of book is: ",int(selling_price),"INR")  #It is in INR