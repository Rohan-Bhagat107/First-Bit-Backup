#Write a program to print list after removing even numbers.

data=[]
odd_data=[]
n=int(input("Enter how many elements you want to add in a list:"))
for i in range(n):
    element=int(input("Enter the element: "))
    data.append(element)
    if element%2==1:
        odd_data.append(element)
print("List with even numbers is:-") 
print(data)
print("List after removing even numbers is:-") 
print(odd_data)

