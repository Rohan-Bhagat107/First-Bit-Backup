# Write a program to create three lists of numbers, their squares and cubes

data=[]
square_data=[]
cube_data=[]
n=int(input("Enter how many elements you want to add in a list: "))
for i in range(n):
    element=int(input("Enter the element: "))
    data.append(element)
    square=element**2
    square_data.append(square)
    cube=element**3
    cube_data.append(cube)

print("Original list is..........")
print(data)
print("list with square is..........")
print(square_data)
print("list  with cube is..........")
print(cube_data)
