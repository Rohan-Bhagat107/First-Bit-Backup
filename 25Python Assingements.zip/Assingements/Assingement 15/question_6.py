#Python Program to Find the Union of two Lists
data1=[]
data2=[]
merged_data=[]
union_data=[]

n_data1=int(input("Enter how many elements you want to add in 1st list:"))
for i in range(n_data1):
    element=int(input("Enter the element: "))
    data1.append(element)
    merged_data.append(element)

n_data2=int(input("Enter how many elements you want to add in 2nd list:"))
for i in range(n_data2):
    element=int(input("Enter the element: "))
    data2.append(element)
    merged_data.append(element)

for i in merged_data:
    if i not in union_data:
        union_data.append(i)
print("1st list is:-")   
print(data1)
print()
print("2nd list is:- ")
print(data2)
print()
print("Union of 2  list is:- ")
print(union_data)
