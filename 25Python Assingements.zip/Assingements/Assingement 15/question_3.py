l=[[2,1,3],[4,5,6],[8,4,9]]

print("Sorted list in ascending order is: ")
for i in range(len(l)):
    for j in range(len(l)):
        if l[i][1]<l[j][1]:
            l[i],l[j]=l[j],l[i]
print(l)
print("Sorted list in descending order is: ")
for i in range(len(l)):
    for j in range(len(l)):
        if l[i][1]>l[j][1]:
            l[i],l[j]=l[j],l[i]
print(l)
