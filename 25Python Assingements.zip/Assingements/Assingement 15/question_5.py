#Python Program to Sort a List According to the Length of the Elements within the list.

library=[]
n=int(input("Enter how many string elements you want to add in a list: "))
for i in range(n):
    element=input("Enter the string element: ")
    library.append(element)

print(library)


for j in range(len(library)):
    
    for k in range(j+1,len(library)):
    
        if len(library[j])>len(library[k]):
            library[j],library[k]=library[k],library[j]
print("Sorted list is:- ")
print(library)
