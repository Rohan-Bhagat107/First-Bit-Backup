# Python Program to Put Even and Odd elements of a List into two Different Lists

number=[]
even_number=[]
odd_number=[]
n=int(input("Enter how many elements you want to add in a list: "))
for i in range (n):
    element=int(input("Enter the element: "))
    number.append(element)
    if element%2==0:
        even_number.append(element)
    else:
        odd_number.append(element)

print("Original list is: ..")
print(number)
print("List with even numbers is: ....")
print(even_number)
print("List with odd number is: ...")
print(odd_number)