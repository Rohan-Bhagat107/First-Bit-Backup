#Python Program to Find the Intersection of Two Lists

data1=[]
data2=[]
intersection_data=[]
n=int(input("Enter how many elements you want to add in 1st list: "))
for i in range(n):
   element=int(input("Enter the element: "))
   data1.append(element)

n=int(input("Enter how many elements you want to add in 2nd list: "))
for i in range(n):
   element=int(input("Enter the element: "))
   data2.append(element)

for j in data1:
    if j in data2:
        intersection_data.append(j)
print("1st list is:-")
print(data1)
print("2nd list is:-")
print(data2)
print("Intersection list is:-")
print(intersection_data)

