# Python Program to Find the Second Largest Number in a List Using Bubble Sort

numbers=[]
n=int(input("Enter how many elements you want to add in a list:"))
for i in range(n):
    element=int(input("Enter the element: "))
    numbers.append(element)
    
print(numbers)

for j  in range(len(numbers)):
    for k in range(j+1,len(numbers)):
        if numbers[j]>numbers[k]:
            numbers[j],numbers[k]=numbers[k],numbers[j]

print("Sorted list is:- ",numbers)
print("Second largest number in the list is: ",numbers[len(numbers)-2])
