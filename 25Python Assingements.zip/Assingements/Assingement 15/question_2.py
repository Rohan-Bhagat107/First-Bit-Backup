# Python Program to Merge Two Lists and Sort it

list1=[]
list2=[]
list3=[]
list1_num=int(input("Enter how many elements you want to add in 1st list: "))
for i in range(list1_num):
    list1_element=int(input("Enter the element: "))
    list1.append(list1_element)
print("1st list is:-")
print(list1)

list2_num=int(input("Enter how many elements you want to add in 2nd list: "))
for i in range(list2_num):
    list2_element=int(input("Enter the element: "))
    list2.append(list2_element)
print("2nd list is:-")
print(list2)

for j in list1:
    list3.append(j)
for j in list2:
    list3.append(j)
print("Merged list is:-")
print(list3)

for i in range(len(list3)):
    for j in range(i+1,len(list3)):
        if list3[i]>=list3[j]:
            list3[i],list3[j]=list3[j],list3[i]
        
print("Ascending order of merged list is: ")
print(list3)

for i in range(len(list3)):
    for j in range(i+1,len(list3)):
        if list3[i]<=list3[j]:
            list3[i],list3[j]=list3[j],list3[i]
        
print("descending order of merged list is: ")
print(list3)
    
    

