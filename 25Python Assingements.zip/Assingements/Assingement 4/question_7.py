#Author=Rohan
#date=2-1-24
#WAP to print integers upto n that are not divisible by 2 or 3
count=0
n=int(input("Enter number upto which you have to print: "))
for x in range(1,n+1,1):
    if x%2!=0 and x%3!=0:
        # continue
     print(x)
