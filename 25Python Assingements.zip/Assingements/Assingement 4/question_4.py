#Author=Rohan
#date-2-1-24
#WAP to print factorial of a number

fact=1
n=int(input("Enter number to find factorial: "))
for i in range(1,n+1,1):
    fact*=i
print("Factorial of",n,"is: ",fact)