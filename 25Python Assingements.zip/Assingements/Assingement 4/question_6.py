#Author=Rohan
#date=2-1-24

n=int(input("Enter number you want to check: "))
for i in range(2,n,1):
    if n%i==0:
        print("It is not a prime number.")
        break
else:
    print("It is prime number")