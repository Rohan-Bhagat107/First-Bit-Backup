#Author=Rohan
#date-2-1-24

#WAP to print Fibonacci series

n=int(input("Enter number upto which you have to print Fibonacci series: "))
a=1
b=0
for i in range(n):
    c=a+b
    print(c)
    a=b
    b=c