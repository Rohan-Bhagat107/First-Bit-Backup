#Author=Rohan
#date=2-1-24
#WAP to print all numbers in a range that are divisible by a given number

n=int(input("Enter number that you want to check divisiblity: "))
s=int(input("Enter starting of range: "))
e=int(input("Enter starting of range: "))

for i in range (s,e+1,1):
    if i%n==0:
        print(i)
