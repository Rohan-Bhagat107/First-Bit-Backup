# Author=Rohan
# Date=1-1-24
# Task-
# WAP to print all even numbers until n.
n=int(input("Enter number upto which you have to print even numbers."))
for x in range(1,n+1,1):
    if x%2==0:
        print(x)
        
    
    

