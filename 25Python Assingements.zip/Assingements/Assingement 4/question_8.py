#Author=Rohan
#date=2-1-24
#WAP to find which numbers are divisible by 7 and multiple of 5 in given range

s=int(input("Enter start of your range: "))
e=int(input("Enter end of your range: "))
for i in range(s,e+1,1):
    if i%7==0 and i%5==0:
        print(i)