#Author=Rohan
#date=-1-24
#WAP to print sum of series upto n.

sum=0
n=int(input("Enter number upto which you have to print numbers: "))
for x in range(n+1):
    sum+=x
print("Sum of your numbers till",n,"is:",sum)