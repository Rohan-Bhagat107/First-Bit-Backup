#Author=Rohan
#date=2-1-24
#WAP to check if a given number is perfect number or not
#a perfect number is that in which sum of its factors is equal to number itself
add=0
mult=1
n=int(input("Enter number that you want check: "))
for i in range(1,n,1):
    if n%i==0:
        add+=i
       
if n==add: 
 print("It is a perfect number.")
else:
    print("It is not a perfect number.")
