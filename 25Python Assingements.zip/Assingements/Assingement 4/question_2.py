# Author=Rohan
# Date=1-1-24
#WAP to print all odd numbers until n.

n=int(input("Enter number upto which you have to print odd numbers"))
for i in range(1,n+1,1):
    if i%2==1:
        print(i)