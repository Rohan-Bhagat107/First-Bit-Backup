#Python Program to Multiply All the Items in a Dictionary
data={}
data2={}
n=int(input("How many key_value pairs you want to add in a dictionary: "))
for i in range(n):
    key=int(input("Enter key: "))
    value=int(input("Enter values:"))
    data[key]=value
multiplier=int(input("Enter multiplier for key: "))
print("Original dictionary is: ")
print(data)
for k ,i in data.items():
    x=i*multiplier
    y=k*multiplier
  
    data2[x]=y

print("Modified dictionary after multiplication: ")
print(data2)