#Python Program to Sum All the Items in a Dictionary

data={}
sum=0
n=int(input("How many key_value pairs you want to add in a dictionary: "))
for i in range(n):
    key=int(input("Enter key: "))
    value=int(input("Enter values:"))
    data[key]=value
for i,j in data.items():
    sum+=i
    sum+=j
print("Sum of all values/items in dictionary is: ",sum)