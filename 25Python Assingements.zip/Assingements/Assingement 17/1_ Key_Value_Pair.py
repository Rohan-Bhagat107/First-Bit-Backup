#Python Program to Add a Key-Value Pair to the Dictionary

data={}
n=int(input("How many key_value pairs you want to add in a dictionary: "))
for i in range(n):
    key=input("Enter key: ")
    value=input("Enter values:")
    data[key]=value
print(data)