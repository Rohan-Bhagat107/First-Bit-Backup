#Python Program to Generate a Dictionary that Contains Numbers (between 1 and n) in the Form (x,x*x).

data={}
n=int(input("How many key:value pairs you want to add in a dictionary: "))
for i in range(n):
    key=int(input("Enter integer key: "))
    data[key]=key*key
print(data)
