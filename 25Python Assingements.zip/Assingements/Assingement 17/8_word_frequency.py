#Python Program to Count the Frequency of Words Appearing in a String Using a Dictionary
data={}
data2=set()
sentence=(input("Enter any sentence: "))
list1=sentence.split(" ")

for i in list1:
    if i not in data2:
        data2.add(i)
for j in data2:
    for k in list1:
        count=1
        if j==k:
            count+=1
    data[j]=count
print("Given dictionary contains words as key while their frequency as value:")
print(data)   
