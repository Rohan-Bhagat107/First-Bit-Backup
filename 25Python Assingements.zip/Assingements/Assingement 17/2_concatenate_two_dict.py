#Python Program to Concatenate Two Dictionaries Into One
data1={}
data2={}

data1_pair=int(input("How many key_value pairs you want to add in 1st dictionary: "))
for i in range(data1_pair):
    key=input("Enter key: ")
    value=input("Enter value:")
    data1[key]=value
print("1sr dictionary is:-")
print(data1)
data2_pair=int(input("How many key_value pairs you want to add in 2nd dictionary: "))
for i in range(data2_pair):
    key=input("Enter key: ")
    value=input("Enter value:")
    data2[key]=value
print("2nd dictionary is:-")
print(data2)
print("Concatenated dictionary is:- ")
data1.update(data2)
print(data1)
