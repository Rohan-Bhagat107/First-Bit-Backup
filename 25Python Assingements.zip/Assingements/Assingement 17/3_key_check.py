#Python Program to Check if a Given Key Exists in a Dictionary or Not
data={}
n=int(input("How many key_value pairs you want to add in a dictionary: "))
for i in range(n):
    key=input("Enter key: ")
    value=input("Enter values:")
    data[key]=value
key_searched=input("Which key you want to search in a dictionary: ")
for j in data.keys():
    if j ==key_searched:
        print("Given key exists in dictionary")
        break
else:
    print(f"{key_searched} is an invalid key.It is not present in the dictionary")