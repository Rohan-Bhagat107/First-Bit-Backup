#Python Program to Remove the Given Key from a Dictionary

data={}
n=int(input("How many key_value pairs you want to add in a dictionary: "))
for i in range(n):
    key=input("Enter key: ")
    value=input("Enter values:")
    data[key]=value
print("dictionary with all keys: ")
print(data)
del_key=input("Enter which key you want to remove: ")
if del_key in data:
    print(f"dictionary after removing {del_key} key is: ")

    del data[del_key]
    print(data)
else:
    print(f"{del_key} key is not exists")