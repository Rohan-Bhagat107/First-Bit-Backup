#Write a Python program to find all the anagrams and group them together from a given list of strings.

data=[]
anagram_data={}
n=int(input("How many string elements you want to add in a list: "))
for i in range(n):
    element=input("enter string element: ")
    data.append(element)
for i in data:
    string=str(sorted(i))
    if string in anagram_data:
        anagram_data[string].append(i)
    else:
        anagram_data[string]=[i]
print(list(anagram_data.values()))
