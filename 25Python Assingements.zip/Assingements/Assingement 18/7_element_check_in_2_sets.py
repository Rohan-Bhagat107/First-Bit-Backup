# Given two sets of numbers, write a Python program to find the missing numbers in the second set as compared to the first and vice versa. Use the Python set.

data=set()
data2=set()
n=int(input("How many elements yow want to add in 1st set: "))
for i in range(n):
    element=int(input("Enter the element: "))
    data.add(element)
print(data)

n=int(input("How many elements yow want to add in 2nd set: "))
for i in range(n):
    element=int(input("Enter the element: "))
    data2.add(element)
print(data2)

print("Elements from set 1 which are missing/not in set 2 are: ")
for i in data:
        if i not in data2:
            print(i)

print("Elements from set 2 which are missing/not in set 1 are: ")
for j in data2:
        if j not in data:
            print(j)