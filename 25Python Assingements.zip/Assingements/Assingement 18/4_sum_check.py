#Write a Python program that finds all pairs of elements in a list whose sum is equal to a given value

data=set()

pair=[]
n=int(input("How many elements yow want to add in a list: "))
for i in range(n):
    element=int(input("Enter the element: "))
    data.add(element)
print(data)

num=int(input("Enter any number :"))
print("Pair of elements from given set whose sum is",num,"are-")
for i in data:
    for j in data:
        if i+j==num:
            if {i,j} not in pair:
                pair.append({i,j})
            else:
                continue
            print(pair)
            #    pair[i]=j

            
           
# print(pair)