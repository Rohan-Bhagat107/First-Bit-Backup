#Write a Python program to find elements in a given set that are not in another set.

data=set()
data2=set()
n=int(input("How many elements you want to add in 1st set: "))
for i in range(n):
    element=input("Enter element: ")
    
    data.add(element)

print(data)

n=int(input("How many elements you want to add in  2nd  set: "))
for i in range(n):
    element=input("Enter element: ")
    
    data2.add(element)
print(data2)
print("Elelments of set 1 that are not in set 2 are:")
for i in data:
    if i not in data2:
        print(i)