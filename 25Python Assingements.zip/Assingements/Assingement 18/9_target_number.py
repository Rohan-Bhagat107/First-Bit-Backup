# Write a Python program to find all the unique combinations of 3 numbers from a given list of numbers, adding up to a target number

data=[]
unique_data=[]
n=int(input("Enter how many elements you want to add in a list: "))
target=int(input("Enter a number that you want: "))
for i in range(n):
    element=int(input("Enter the element: "))
    data.append(element)

print(data)

print("The pair of elements from list which on adding gives sum :",target)
for j in data:
    for k in data:
        for l in data:
            if (j+k+l)==target:
                if {j,k,l} not in unique_data:
                    unique_data.append({j,k,l})
                else:
                    continue
                print(j,",",k,",",l)
