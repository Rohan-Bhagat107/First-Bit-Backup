# Write a Python program to find the longest common prefix of all 
# strings. Use the Python set


str_list=[]
longest=""
n=int(input("How many elements you want to add in a list: "))
for j in range(n):
    element=input("Enter string element: ")
    str_list.append(element)


min_length=min(len(i) for i in str_list)

for i in range(min_length):
    ch=str_list[0][i]
    # for j in str_list:
    if all(j[i]==ch for j in str_list):
        longest+=ch
print("Longest common prefix is: ",longest)


    

