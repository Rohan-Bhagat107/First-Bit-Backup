# Write a Python program to find all the unique words and count the frequency of occurrence from a given list of strings. Use Python "set" data type.

string=input("Enter any string: ")
list1=(string.split())
data=set(list1)

dict_data={}

for i  in data:
    
    count=0
    for j in list1:

        if i ==j:
            count+=1
            dict_data[i]=count
print("Below is the dictionary that contains elements in list as key while there occurance frequency as value: ")
print(dict_data)

    