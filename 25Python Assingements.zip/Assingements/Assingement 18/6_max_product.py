# Write a Python program to find the two numbers whose product is maximum among all the pairs in a given list of numbers. Use the Python set

data=set()
n=int(input("How many elements yow want to add in a set: "))
for i in range(n):
    element=int(input("Enter the element: "))
    data.add(element)
print(data)
print("Pair of elements from given set whose product is maximum is -")
e1,e2=0,0
for i in data:
    for j in data:
        if i*j>e1*e2:
            e1,e2=i,j
print(i,j)