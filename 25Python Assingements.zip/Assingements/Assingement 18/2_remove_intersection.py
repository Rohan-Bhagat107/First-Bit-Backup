#Write a Python program to remove the intersection of a second set with a first set.

data=set()
data2=set()
n=int(input("How many elements you want to add in 1st set: "))
for i in range(n):
    element=input("Enter element: ")
    
    data.add(element)

print(data)

n=int(input("How many elements you want to add in  2nd  set: "))
for i in range(n):
    element=input("Enter element: ")
    
    data2.add(element)
print(data2)
data.update(data2)
print("Set after removing intersections:-")
print(data)