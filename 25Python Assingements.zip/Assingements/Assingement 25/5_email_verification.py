# Write a Python function that takes an email address as input and uses a regular 
# expression to validate if it is a valid email address. The function should return True for 
# valid emails and False for invalid ones

import re

def verify_email(email):
    pattern = r'^\S+@\S+\.\S+$'
    return bool(re.match(pattern, email))

n=int(input("How many emails are there?: "))
for i in range(1,n+1):
    e=input("Enter your email here: ")
    result=verify_email(e)
    if result==True:
        print(f"{e} is a vaild email")
    else:
        print(f"{e} is an invalid email")
