# Create a function that extracts all the dates from a given text using regular expressions. 
# Dates can be in various formats like MM/DD/YYYY, DD-MM-YYYY, or written out like 
# January 1, 2023. Extract all such date occurrences.


import re
from datetime import datetime

def find_dates(text):
    date_patterns = [
        r'\b\d{1,2}/\d{1,2}/\d{4}\b',  # MM/DD/YYYY
        r'\b\d{1,2}-\d{1,2}-\d{4}\b',  # DD-MM-YYYY
        r'\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},\s+\d{4}\b'  # Written out dates like "January 1, 2023"
    ]

    dates = []
    for pattern in date_patterns:
        
        matches = re.findall(pattern, text)
       
        for match in matches:
            dates.append(match)
    return dates

sentence = input("Enter your  text here: ")
all_dates = find_dates(sentence)
print(all_dates)



















# import re
# from datetime import datetime

# def find_dates(a):
    
#     date_patterns = [r'\b\d{1,2}/\d{1,2}/\d{4}\b',   r'\b\d{1,2}-\d{1,2}-\d{4}\b',  r'\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},\s+\d{4}\b'  ]
    
#     all_dates = []
#     for i in date_patterns:
#         # Find all occurrences of dates matching the pattern
#         matches = re.findall(i, a)
#         # Parse the matched dates into datetime objects and append to the result list
#         for j in matches:
            
#                 date = datetime.strptime(j, '%m/%d/%Y') if '/' in j else \
#                        datetime.strptime(j, '%d-%m-%Y') if '-' in j else \
#                        datetime.strptime(j, '%B %d, %Y')
#                 all_dates.append(date)
            
#     return all_dates

# # Example usage:
# sentence = input("Enter a text here: ")
# dates = find_dates(sentence)
# print(dates)



# import re
# from datetime import *

# def extract_dates(text):
#     # Define regular expression patterns for different date formats
#     date_patterns = [
#         r'\b\d{1,2}/\d{1,2}/\d{4}\b',  # MM/DD/YYYY
#         r'\b\d{1,2}-\d{1,2}-\d{4}\b',  # DD-MM-YYYY
#         r'\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},\s+\d{4}\b'  # Written out dates like "January 1, 2023"
#     ]

#     all_dates = []
#     for pattern in date_patterns:
#         # Find all occurrences of dates matching the pattern
#         matches = re.findall(pattern, text)
#         # Parse the matched dates into datetime objects and append to the result list
#         for match in matches:
                # if '/' in match:
                #     d = date(match, '%m/%d/%Y') 
                #     all_dates.append(d)

                # elif '-' in match: 
                #     date(match, '%d-%m-%Y')  
                #     all_dates.append(d)

                # else:
                #     date(match, '%B %d, %Y')
                #     all_dates.append(d)

           
#     return all_dates

# # Example usage:
# text = "The event will be held on 05/20/2024, and another event on January 1, 2023."
# dates = extract_dates(text)
# print(dates)



# import re
# from datetime import datetime

# def extract_dates(text):
#     # Define regular expression patterns for different date formats
#     date_patterns = [
#         r'\b\d{1,2}/\d{1,2}/\d{4}\b',  # MM/DD/YYYY
#         r'\b\d{1,2}-\d{1,2}-\d{4}\b',  # DD-MM-YYYY
#         r'\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},\s+\d{4}\b'  # Written out dates like "January 1, 2023"
#     ]

#     all_dates = []
#     for pattern in date_patterns:
        
#         matches = re.findall(pattern, text)
       
#         for match in matches:
#             all_dates.append(match)
            # try:
            #     if '/' in match:
            #         x = datetime.strptime(match, '%m/%d/%Y')
            #         d=x.date()
            #         m=x.strftime("%m")
            #         y=x.strftime("Y")
            #         date=f"{d}/{m}/{y}"
                        
            #         all_dates.append(date)
            #     elif '-' in match:
            #         x=datetime.strptime(match, '%d-%m-%Y')
            #         d=x.date()
            #         m=x.strftime("%m")
            #         y=x.strftime("Y")
            #         date=f"{d}/{m}/{y}"
            #         all_dates.append(date)
            #     else:
            #         x=datetime.strptime(match, '%B %d, %Y')
            #         d=x.date()
            #         m=x.strftime("%B")
            #         y=x.year()
            #         date=f"{d}/{m}/{y}"
            #         all_dates.append(date)

            # except ValueError:
            #     # If parsing fails, skip and continue to the next match
            #     continue
#     return all_dates

# # Example usage:
# text = "The event will be held on 05/20/2024, and another event on January 1, 2023."
# dates = extract_dates(text)
# print(dates)

