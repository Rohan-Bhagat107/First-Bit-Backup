# Write a function that extracts all the URLs from a given text using regular expressions. 
# Return a list of URLs found in the input text.

import re

def url_finder(text):
    url_pattern = r'(https?://\S+)'
    url = re.findall(url_pattern, text)
    return url

text = input("Enter your text here: ")
urls = url_finder(text)
print(urls)
