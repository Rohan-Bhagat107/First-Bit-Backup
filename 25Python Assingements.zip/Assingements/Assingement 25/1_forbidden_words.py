#  Develop a function that takes a text and a list of forbidden words. Replace all 
# occurrences of these forbidden words with asterisks (*) using regular expressions.

import re

def word_remover(text, forbidden_words):
    for i in forbidden_words:
        pattern = re.compile(r'\b' + re.escape(i) + r'\b', re.IGNORECASE)
        text = re.sub(pattern, '*' * len(i), text)
    return text

sentence = input("Enter a text here: ")
forbidden_words = []

num=int(input("Enter how many forbidden words are there in your text: "))
for i in range(1,num+1):
    word=input("Enter forbidden word : ")
    forbidden_words.append(word)

new_text= word_remover(sentence, forbidden_words)
print(new_text)
