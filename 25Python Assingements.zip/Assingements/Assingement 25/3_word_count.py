# Develop a function that counts the occurrences of each word in a given text. Use regular 
# expressions to split the text into words and then count the frequency of each word.

import re
from collections import Counter

def occurrence_calculator(text):
    word_list1=re.split(",| ",text)
    counts = Counter(word_list1)
    return counts

sentence = input("Enter your text here: ")
occurrences = occurrence_calculator(sentence)
print(occurrences)



# import re

# occurrences={}
# list1=[]
# def occurrence_calculator(text):
#     words=re.split(" \s*",text)
#     for i in words:
#         if i not in list1:
#             list1.append(i)
    
#     for i in list1:
#         count=0
#         for j in words:
#             if i==j:
#                count+=1
#         occurrences[i]=count
#     return occurrences

# # return occurrences
# sentence=input("Enter your text here: ")
# #occurrence_calculator(sentence)
# data=occurrence_calculator(sentence)
# print(data)



