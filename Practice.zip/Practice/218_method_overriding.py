class Parent():
    def display(self):
        print("This is Parents implementation")

class Child(Parent):
    # def display(self):
    #     super().display()
    # def display(self):
    #     print("This is Childs implementation")
    def display(self):
        super().display()
        print("This is Childs implementation")

C=Child()
C.display()