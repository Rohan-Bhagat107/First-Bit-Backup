#WAP to create a copy of list that contains square and cubes of existing list

number=[]
new_square_list=[]
new_cube_list=[]
n=int(input("How many elements you want to add in a list: "))
for i in range(n):
    element=int(input("Enter element: "))
    number.append(element)
    sq=element**2
    new_square_list.append(sq)
    cube=element**3
    new_cube_list.append(cube)
print("Existing list....")
print(number)
print("New list containing squares ..........")
print(new_square_list)
print("New list containing cubes ..........")
print(new_cube_list)
