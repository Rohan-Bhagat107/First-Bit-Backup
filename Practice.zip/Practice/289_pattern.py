for i in range(1,6):
    no=65
    for j in range(1,7-i):
        print(" ",end=" ")
    for j in range(1,i+1):
        print(chr(no),end=" ")
        no+=1
    for j in range(i+1,2*i):
        print(chr(no),end=" ")
        no+=1
    print()
       