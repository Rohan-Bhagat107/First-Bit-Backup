#WAP to check if a given number is strong number or not

n=int(input("Enter a nunber that you want to check: "))   #145
sum=0
number=n
while n!=0:                  #145!=0
    digit=n%10             #5
    fact=1
    for i in range(2,digit+1):                  #ex= range goes from (2 to 5+1)
        fact*=i
    sum+=fact
    n=n//10                         #14 again from this it will go to line no.6 and check condition
if number==sum:
    print(number,"is a strong number.")
else:
    print(number,"is not strong number.")

# n=int(input("Enter a number: "))
# org_no=n
# sum=0
# while n>0:
#     digit=n%10
#     fact=1
#     for i in range(2,digit+1):
#         fact*=i
#     sum+=fact
#     n=n//10
# if sum==org_no:
#     print(org_no,"is a strong number")
# else:
#     print(org_no,"is not an strong number")


