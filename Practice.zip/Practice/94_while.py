#WAP to accept 5 numbers from user and print how many times 10  was entered
# a=1
# count=0
# while a<=5:
#     no=int(input("Enter a number: "))
#     if no==10:
#         count+=1
#     a+=1
# print("User has entered 10: ",count,"time")


a=1
count=0
while a<=5:
    num=int(input("Enter a number: "))
    if num is 10:
        count+=1
        a+=1
    else:
        a+=1
print(count)