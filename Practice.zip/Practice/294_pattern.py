# for i in range(1,6):
#     for j in range(1,i+1):
#         print("*",end=' ')
#     print()
list1=[x for x in range(1,16) if x%2==0 ]
print(list1)

