# Armstrong
n=int(input("Enter a number that you want to check: "))
org_no=n
count=0
while n!=0:
    digit=n%10
    n=n//10
    count+=1

n=org_no
sum=0
while n!=0:
    digit2=n%10
    fact=1
    
    for i in range(1,n+1):
        fact*=i
        power=digit**count
        sum+=power
        n=n//10
n=org_no
if sum==org_no:
    print(n,"is a armstrong number.")
else:
    print(n,"is not an armstrong number.")
