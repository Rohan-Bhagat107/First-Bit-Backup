for i in range(1,6):
    for j in range(1,i+1):
        if j==i:
            print("1",end=' ')
        else:
            print(j,end=" ")
    print()