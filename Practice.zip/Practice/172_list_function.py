data=[1,5,4,6,8,2,5,3]
data2=[5,8,5,3,9,5,9,77]
#to insert any element at particular index we use-
data.insert(-2,11)
print(data)
#to pop last item of list we use-
print(data.pop())
#to pop particular index element we pass index to pop-
print(data.pop(2))
#to count occurance of a particular element in list-
print(data.count(5))
#to merge/update two list we use extend-
data.extend(data2) 
print(data)
#to sort list in ascending order we have-
data.sort()
print(data)
#to sort list in ascending order we have-
data.sort(reverse="True")
print(data)
print(data2.clear())

#next-
print(range(5))
