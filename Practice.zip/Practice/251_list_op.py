list1=[5,1,8,2,6,9,2,4]

# .insert
# list1.insert(-2,11)
# print(list1)

# print(list1.count(2))
# if 2 in list1:
#     print("Yes")
# else:
#     print("No")