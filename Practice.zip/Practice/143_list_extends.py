#extends()-> list_ref.extend(another list)
L1=[10,8,9,13]
L2=[2,8,15,3]
L3=[1,2]
L1.extend(L2)
print(L1)
L1.extend(L3)
print(L1)