# n=10
# while n<100:
#    print(n)
#    n+=1

#max of numbers 

# num=1
# max_num=0
# data=[]
# while num<=3:
#     n=int(input("Enter a number: "))
#     num+=1
#     data.append(n)
#     if n>=max_num:
#         max_num=n
# print(max(data))

num=0
max_num=0
data=[]
while num<3:
    n=int(input("Enter any number: "))
    num+=1
    data.append(n)

for j in data:
    for k in data:
        if j>k:
            j,k=k,j
print(max_num)
