#Write a program to find sum of digits of a number.

def sum_of_digit(no):
    sum=0
    while no>0:
        digit=no%10
        no=no//10
        sum+=digit
    return sum

no=int(input("Enter a number: "))
res=sum_of_digit(no)
print(f"sum of digits of {no} is: {res}")