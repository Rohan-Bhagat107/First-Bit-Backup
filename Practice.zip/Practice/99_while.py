#WAP to accept a number that is to be searched.and then take 5 user input for numbers
#And check how many times that number was entered


no_searched=int(input("Enter a number that is to be searched: "))
a=1
count=0
while a<=5:
    no=int(input("Enter a number: "))
    if no==no_searched:
        count+=1
    a+=1
print("User has entered",no_searched,"=",count,"time")
    