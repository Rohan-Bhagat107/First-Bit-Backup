#WAP to print numbes from 13 to 20 using while loop

a=13
while a<=20:
    print(a)
    a+=1