def fibbo(terms,a,b):
    if terms==0:
        return
    else:
        c=a+b
        print(c)
        return fibbo(terms-1,b,c)
terms=int(input("Enter how many terms you want: "))
print("0")
print("1")
res=fibbo(terms,0,1)
