#wap to remove all occurances of a given  number from a list: 
data=[]
data2=[]
no=int(input("How many elements you want to add in a list: "))
removing_element=int(input("Enter element tha you want to remove from list: "))
for i in range(no):
        element=int(input("Enter the element: "))
        data.append(element)
        if element!=removing_element:
            data2.append(element)
            
            

print("Original list is: ",data)
print(f"List after removing {removing_element} is: {data2}")

