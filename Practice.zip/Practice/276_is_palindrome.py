num=int(input("Enter any three digit number of your choice: ")) #235
# a=num%10   #5
# b=num//10  #23
# c=b%10   # 3
# d=b//10  #5
# rev=a*100+c*10+d
# if rev==num:
#     print("Yes")
# else:
#     print("No")

    # -----------OR-----------

