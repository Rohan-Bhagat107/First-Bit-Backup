# def my_decorator(x):
#     def wrapper():
#         print("Before function call")
#         x()
#         print("After function call")
#     return wrapper

# @my_decorator
# def display():
#     print("Hello!")

# display()

def my_decorator(func):
    def display():
        pin=int(input("Enter your pin here: "))
        func()
    return display

@my_decorator
def transfer_amt():

    print("Amount has been transferred!")

transfer_amt()
