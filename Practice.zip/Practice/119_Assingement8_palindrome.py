#	Write a program to check if entered number is a palindrome or not.

def is_palindrome(no):
    rev=0
    while no>0:
        rev=rev*10+no%10
        no=no//10
    return rev
    if rev==org_no:
        return True

    else:
        return False

no=int(input("Enter a number that you want to check: "))
org_no=no
res=is_palindrome(no)
if res==org_no:
    print(f"{org_no} is a plaindrome")
else:
    print(f"{org_no} is not a palindrome")

