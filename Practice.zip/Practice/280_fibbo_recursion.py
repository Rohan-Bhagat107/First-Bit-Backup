def fibb(terms,a=0,b=1):
    if terms==0:
        return
    else:
        c=a+b
        print(c)
        return fibb(terms-1,a=b,b=c)
fibb(5)