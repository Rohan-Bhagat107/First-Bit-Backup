n=int(input("Enter how many prime number you want to print: "))
start=int(input("Enter your start of range: "))
end=int(input("Enter your end of range: "))
count=0                   #or we can take count as 1
while count<n:              #so the condition will be count<=n
    for i in range(start,end+1):
            for j in range(2,i):
                 
             if i%j==0:
                break
            else:
             count+=1
             print(i)
             i+=1