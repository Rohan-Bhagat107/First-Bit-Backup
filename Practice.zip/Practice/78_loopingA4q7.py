# WAP to print all integers upto n that aren’t divisible by either 2 or 3.

n=int(input("Enter a number upto which you want the intergers: "))
for i in range(1,n+1):
    if i%2!=0 and i%3!=0:
        print(i)
