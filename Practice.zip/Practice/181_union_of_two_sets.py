set1={1,2,3,4,3}
set2={5,6,7,8,8}
set3=set()
for i in set1:
    for j in set2:
        if i not in set3 or j not in set3:
            set3.add(i)
            set3.add(j)
print(set3)

