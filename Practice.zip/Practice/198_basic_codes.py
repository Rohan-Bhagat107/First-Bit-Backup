# days=int(input("Enter numberr of days: "))

# year=days%365
# week=(days%365)//7
# day=(days%365)%7
# print(f"Your converted days are: {year} year {week} week {day} days ")


#sum of digits of a three digit number

# n=int(input("Enter any theree digit number: "))

# a=n%10
# b=n//10
# c=b%10
# d=b//10
# print(a+c+d)

#Swap two numbers using third variable

# a=10
# b=20
# c=a
# a=b
# b=c
# print(a,b)

#Swap two numbers without using third variable
# a=25
# b=36
# a,b=b,a
# print(a,b)


# check number is palindrome or not (three digit number)

# n=int(input("Enter three digit number: "))
# a=n%10
# b=n//10
# c=b%10
# d=b//10

# res=a*100+c*10+d
# if res==n:
#     print("Number is a palindrome")
# else:
#     print("Not a palindrome")

#facorial of a number:
# n=int(input("Enter any number: "))
# fact=1
# for i in range(1,n+1):
#     fact*=i
# print(fact)

# Fibbonacci series
# term=int(input("Enter how ,many fibo terms you want: "))
# a=0
# b=1
# for i in range(1,term+1):
#     c=a+b
#     a=b
#     b=c
#     print(c)



# Strong number

# n=int(input("Enter any number: "))
# org_no=n
# sum=0

# while n>0:
#     digit=n%10
#     fact=1
#     for i in range(2,digit+1):
#         fact*=i
#     sum+=fact
#     n=n//10
# if org_no==sum:
#     print("Strong number")
# else:
#     print("Not a strong number")

#Armstrong number

n=int(input("Enter an number: "))
sum=0
org_no=n
count=0
while n>0:
    digit=n%10
    count+=1
    n=n//10

n=org_no
while n>0:
    digit=n%10
    sum+=digit**count
    n=n//10
if sum==org_no:
    print("Armstrong number ")
else:
    print("Not armstrong number ")
