dict1={}
for i in range(1,3):
    name=input("Enter name: ")
    age=int(input("Enter age: "))
    dict1[name]=age
print(dict1)