class parent():
    def display(self):
        print("Parent is called")

class child(parent):
    def display(self):
       print("Child is called")
       

c=child()
c.display()