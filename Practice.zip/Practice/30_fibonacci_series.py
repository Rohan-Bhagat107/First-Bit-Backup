#print fibbonacci series upto n.

n=int(input("Enter number upto which you want the fibonacci series: "))
a=1
b=0
for i in range(a,n+1):
    c=a+b
    print(c)
    a=b
    b=c