# num=int(input("Enter a number you want to check: "))
# for i in range(2,num):
#     if num%i==0:
#         print("Not prime")
#         break
# else:
#     print("Prime")

#Finding prime number from given list
# l1=[1,4,192,133,8,12232,754,75,98]
# prime_list=[]
# for i in range(len(l1)):
#     for j in range(2,i):
#         if l1[i]%j==0:
#             break
#     else:
#         prime_list.append(l1[i])
# print(prime_list)

#Counting prime numbers in the given range provided by user
# start=int(input("Enter start of your range: "))
# end=int(input("Enter end of your range: "))
# if start<end:
#     prime_counter=0
#     prime_list=[]
#     for i in range(start,end+1):
#         for j in range(2,i):
#             if i%j==0:
#                 break
#         else:
#             prime_counter+=1
#             prime_list.append(i)
#     print(f"{prime_counter}\n {len(prime_list)}\n {prime_list}")

        