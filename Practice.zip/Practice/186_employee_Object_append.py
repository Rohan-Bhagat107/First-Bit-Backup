from employee187 import employee
class company():
    def __init__(self):
        self.emp=[]
    
    def add_emp(self,e):
        self.emp.append(e)
    
    def search_employee(self,id):
        for i in self.emp:
            print(i)
            if (i.id)==id:
        
                print("Employee found")
                print(i)
                break
        else:
            print(f"There is no employee associated with {id} ID")
    def display_employee(self):
        for i in self.emp:
            print(i)
    def get_index(self, id):
        for i in range(len(self.emp)):
            if self.emp[i].id == id:
                return i
    
    def update_employee(self,id):
        for i in self.emp:
            
            if i.id==id:
                print('''What do you want to update?
                         1)Id
                         2)Name
                         3)salary''')
                ch=int(input("Enter your choice here: "))
                if ch==1:
                    new_id=int(input("Enter new ID of an employee:"))
                    i.id=new_id
                elif ch==2:
                    new_name=input("Enter new name of employee: ")
                    i.name=new_name
                else:
                    new_salary=int(input("Enter new salary of employee:"))
                    i.salary=new_salary
    def delete_employee(self,id):
        # find the index of the emp with matching id
        index = self.get_index(id)
        if index != None:
            # pop the value from the list using index
            self.emp.pop(index)
        # for i in self.emp:
        #     print(i)
        #     if i.id==id:
        #         self.emp.pop(i)
                    


                
c=company()

while True:
    print('''What do you want to do?
             1)Add employee
             2)search_employee by id
             3)display_employee
             4)update employee
             5)delete employee
             6)exit''')
    choice=int(input("Enter your choice here: "))
    if choice==1:
        id=int(input("Enter employee id: "))
        name=input("Enter employee name here: ")
        salary=int(input("Enter employee salary here: "))
        e=employee(id,name,salary)
        c.add_emp(e)
    if choice==2:
        id=int(input("Enter ID of employee that you want to search: "))
        c.search_employee(id)
    
    if choice==3:
        c.display_employee()
    
    if choice==4:
        id=int(input("Enter ID of employee that you want to update: "))
        c.update_employee(id)
    
    if choice==5:
        id=int(input("Enter ID of employee that you want to delete: "))
        c.delete_employee(id)
    if choice==6:
        print("Thank you!")
        break




    
