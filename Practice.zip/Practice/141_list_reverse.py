# reverse()-> list_ref.reverse()
#reverses the list

L1=[10,8,9,13,14,7,12]
L1.reverse()
print(L1)