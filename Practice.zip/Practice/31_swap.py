#swap 2 numbers using third variable

a=int(input("Enter a 1st number: "))
b=int(input("Enter a 2nd number: "))
c=a
a=b
b=c
print("Swap numbers are: ","a=",a,"b=",b)