#print all odd numbers from 12 to 31

for i in range(12,32):
        if i%2==1:
            print(i)
         
            
        
         