data=[2,1,8,6,5]
for i in range(1,len(data)):
    while data[i-1]>data[i] and i>=0:
        data[i-1],data[i]=data[i],data[i-1]
print(data)
data.sort(reverse=True)
print(data)
