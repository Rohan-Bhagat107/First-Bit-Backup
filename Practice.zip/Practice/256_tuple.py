d1={"Name":"Rohan","Age":23}
d1.popitem()
print(d1)

word="Rohan"
word2=word.replace("R","r")
print(word2)
