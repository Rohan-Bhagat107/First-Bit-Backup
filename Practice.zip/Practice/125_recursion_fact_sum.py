def factorial(no):
    if no==1:
        return 1
    else:
        return no*factorial(no-1)
    
def sum(no):
    if no==1:
        return 1
    else:
        return factorial(no)+sum(no-1)
    
no=int(input("Enter a number upto which you want sum of factorials: "))
res=sum(no)
print(f"Sum of factorial from 1 to {no} is: {res}")