class BankAccount():
    def __init__(self,Acc_no,cust_name,Initial_deposite):
        self.Acc_no=Acc_no
        self.cust_name=cust_name
        self.Balance=Initial_deposite
    
    def deposite(self,amt):
        if amt> 0:
            self.Balance+=amt 
    
    def withdraw(self,amt):
        if amt>0 and amt<self.Balance:
            self.Balance-=amt
        else:
            print("Insufficient balance")
    
    def Display(self):
        print(f"Your account balance is: {self.Balance}")
    

B=BankAccount(1245,"Abc",5000)
B.withdraw(300)
B.Display()
B.deposite(3000)
B.Display()
B.withdraw(1500)
B.Display()

