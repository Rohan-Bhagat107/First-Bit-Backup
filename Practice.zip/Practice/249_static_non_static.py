class cirlce():
    area=25
    def __init__(self,color):
        self.color=color
    def display():
        print(cirlce.area)
    def info(self):
        print(cirlce.area)

c=cirlce("grey")
cirlce.display()