#minimum no. of notes using function

def no_of_notes(amt):

    n1=amt//500
    amt=amt%500

    n2=amt//200
    amt=amt%200

    n3=amt//100
    amt=amt%100

    n4=amt//50
    amt=amt%50

    n5=amt//20
    amt=amt%20

    n6=amt//10
    amt=amt%10

    print("To represent your amount your need: ",n1,"notes of 500",n2,"notes of 200",n3,"notes of 100",n4,"notes of 50",n5,"notes of 20",n6,"notes of 10")

# amt=int(input("Enter your amount: "))
# no_of_notes(amt)

# def notes_calculator():
#     notes=[10,20,50,100,200,500]
#     amt=int(input("Enter your amount: "))
#     number_of_notes=[]
#     for i in notes:
#         note=amt//i
#         amt=amt%i
#         number_of_notes.append(note)
#     # return number_of_notes
#     final_ans="You need "
#     for j in notes:
#         for k in number_of_notes:
#             final_ans=final_ans,str(j),"notes of",str(k)
#     return final_ans



# res=notes_calculator()
# print(res)

