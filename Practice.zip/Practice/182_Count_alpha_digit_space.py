#Count the number of alphabet,digit,spaces in a sentence

sent=input("ENter any sentence: ")
alpha_count=0
digit_count=0
space_count=0
for i in sent:
    if i.isalpha():
        alpha_count+=1
    elif i.isdigit():
        digit_count+=1
    else:
        space_count+=1
print("Number of alphabets: ",alpha_count)
print("Number of digits: ",digit_count)
print("Number of spaces: ",space_count)




