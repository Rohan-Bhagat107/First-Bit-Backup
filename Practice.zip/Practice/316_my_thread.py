import threading
import time

class Mythread(threading.Thread):
    def __init__(self,num):
        super().__init__()
        self.num=num
    def table(self):
        for i in range(1,11):
            print(self.num*i)
            time.sleep(1)
    
    def run(self):
        self.table()

M=Mythread(2)
M.start()