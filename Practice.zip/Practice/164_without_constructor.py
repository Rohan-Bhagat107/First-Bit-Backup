# class vehicle():
#     def set_data(self,type,wheels):
#         self.type=type
#         self.wheels=wheels
    
#     def display(self):
#         print(f"Type :{self.type} | Wheels: {self.wheels}")

    
# v=vehicle()
# v.set_data("Two wheeler",2)
# v.display()

a="Hello world"
a.replace(e,E)
