term=int(input("ENter how many fibbo terms you want to print: "))
a=0
b=1
for i in range(1,term+1):
    c=a+b
    print(c)
    a=b
    b=c