n=int(input("Enter a number: "))
sum=0
org_no=n
while n!=0:
    digit=n%10
    fact=1
    for i in range(2,digit+1):
        fact*=i
    sum+=fact
    n=n//10

n=org_no
if n==sum:
    print(n,"is a strong number.")
else:
    print(n,"is not a strong number.")