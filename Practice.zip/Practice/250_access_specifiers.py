color="Grey"
class Cirlce():
    __privateArea=25
    _protectedDiameter=35
    def __init__(self,radius):
        self.radius=radius
        
    def display(self):
        print("Area of circle is: ",self.__privateArea)

c=Cirlce(50)
c.display()
print(c._Cirlce__privateArea)

class SmallCircle(Cirlce):
    def display(self):
        print("Its parents Diameter is: ",Cirlce._protectedDiameter)
s=SmallCircle(2)
s.display()

    
