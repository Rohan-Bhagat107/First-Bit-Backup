
   
n=int(input("Enter a number that you want to check."))
for i in range(2,n):
    if n%i==0:
        print("Not a prime number.")
else:
    print("It is a prime number.")