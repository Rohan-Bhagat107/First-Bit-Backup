S1={1,2,3,"SBCJD"}
S2={1,2,3,"SBCJD"}
print(S1.issuperset(S2))
print(S1.union(S2))