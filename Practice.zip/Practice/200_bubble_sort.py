data=[2,8,1,11,3,5]
for i in range(len(data)):
    for j in range(i+1,len(data)):
        if data[i]>data[j]:
            data[i],data[j]=data[j],data[i]
print(data)



