def is_palindrome(num):
    org_num=num
    rev=0
    while num>0:
        digit=num%10
        num=num//10
        rev=rev*10+digit
    return org_num==rev
def next_palindrome(no):
    if is_palindrome(no+1):
        return no+1
    else:
        return next_palindrome(no+1)

result=next_palindrome(131)
print(result)