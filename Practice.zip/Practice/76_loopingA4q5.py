# WAP to print Fibonacci series upto n

term=int(input("Enter how many fibo terms you want to print: "))
a=1
b=0
for i in range(a,term+1):
    c=a+b
    print(c)
    a=b
    b=c