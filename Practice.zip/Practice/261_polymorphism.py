class vehicle():
    def bakes(self):
        print("Stop the vehicle....")

class Car(vehicle):
    def display(self):
        print("Press the bake pedal using your leg & stop the vehicle")
    
class Bycycle(vehicle):
    def display(self):
        print("Use your hands to apply brakes and stop the vehicle....")


c=Car()
c.display()


