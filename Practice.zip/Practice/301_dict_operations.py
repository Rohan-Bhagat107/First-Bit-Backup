dict1={"Id":405,"Name":"Rohan","Age":25,"City":"Pune","is_Relocated":True}
# 1) Getting particular key from dict
print(dict1.get("Name"))

#  2) Addinng New key
dict1["is_developer"]=True

#   3) GEtting all keys of dict
print(dict1.items())

#  4) Creating new dictionery form given keys
keys=["a","b",101]
new_dict=dict.fromkeys(keys,"0")
print(new_dict)

#  5) using list as a key in dictionery  ("NOTE"We cant use list as akey in dictionery if we want to use it then we need to convert it into tuple or string or frozenset)

key_list=["A","is_student",101,True]
new_dict2={}
new_dict2[tuple(key_list)]="Yes"
print(new_dict2)

#  6) removing last key value pair from dictionery
new_dict.popitem()
print(new_dict)

# 7)  removing particular key value pair from dictionery
new_dict.pop("a")
print(new_dict)