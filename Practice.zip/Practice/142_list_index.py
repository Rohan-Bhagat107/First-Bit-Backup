#index()-> list_ref.index(element)
L1=[10,8,9,13,14,7,12]
index=L1.index(9)
print(f"9 is at the index-> {index}")