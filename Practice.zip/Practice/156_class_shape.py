class Shape():
    def __init__(self):
        pass
    def area(self):
        pass

class rectangle(Shape):
    def __init__(self,length,breadth):
        self.length=length
        self.breadth=breadth
    def area(self):
        A=self.length*self.breadth
        print("Area of rectangle is: ",A)
    
class circle(Shape):
    def __init__(self,radius):
        self.radius=int(input("Enter radius: "))
    
    def area(self):
        a_circle=3.14*radius*radius
        print("Are aof circle is: ",a_circle)


R=rectangle(2,3)
R.area()
C=circle(5)
C.area
