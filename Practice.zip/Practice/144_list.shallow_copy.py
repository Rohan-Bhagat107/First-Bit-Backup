#copy()->  new_list=original_list_ref.copy()
#Note- Shallow copy fails in case of nested list
L1=[10,8,9,[13,14,7,12]]
L2=L1.copy()
L1[-1][0]=22
print(L1)
print(L2)