class info():
    def display(self):
        print("This is parent's implementation")

class Myinfo(info):
    def display(self):
        super().display()
        print("This is child's implementation")


M=Myinfo()
M.display()