a=[10,20,30]
b=(10,20,30)
a[1]=35
print(a)
#b[1]=36
c=b[1:3:1]
print(c)
#print(b)



