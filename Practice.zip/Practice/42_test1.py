	# A farmer has a field which is half in circle share and rest rectangle. He needs to do fencing for entire field using barbed wire 5 times. Circular section has radius 20m and rectangle length is 50 m and breadth is 40m. If cost of barbed wire is 35Rs/m then calculate the total cost of fencing the field.


radius=20
circumferenc_circle=(3.14*radius)
length=50
breadth=40
area_rectangle=(length*breadth)
total_area=(circumferenc_circle+area_rectangle)-(breadth)
cost_of_fencing=int(input("Enter cost of fencing one time: "))
fenc=(cost_of_fencing*5)
cost_of_total_area=(fenc*total_area)
print("Total cost of fencing the field",int(cost_of_total_area),"INR")


