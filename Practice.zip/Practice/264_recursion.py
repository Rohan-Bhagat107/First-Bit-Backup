def fibbo(terms,a,b):
    if terms==0:
        return 
    else:
        c=a+b
        fibbo(terms-1,b,c)
        print(c)
        
    
fibbo(5,0,1)


