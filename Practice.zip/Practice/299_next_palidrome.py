# 1) By converting a number into string
# def is_palindrome(no):
#     return str(no)==str(no)[::-1]

# def next_palidrome(no):
#     if is_palindrome(no+1):
#         return no+1
#     else:
#         return next_palidrome(no+1)

# n=int(input("Enter any number: "))
# res=next_palidrome(n)
# print(res)

#    2) without converting into string
n=int(input("Enter any number: "))
def is_palindrome(no):
    org_no=no
    rev_no=0
    while no>0:
        digit=no%10
        rev_no=rev_no*10+digit
        no=no//10
    return org_no==rev_no

def next_palidrome(no):
    if is_palindrome(no+1):
        return (no+1)

    else:
        return next_palidrome(no+1)


res=next_palidrome(n)
print(res)
