list1=[2,7,1,8,9,5]
#reversing the list with
#1)- Inbuild
# (list1.reverse())
# print(list1)

#2)without inbuild-
''' list2=[]
for i in range(len(list1)-1,-1,-1):
    list2.append(list1[i])
print(list2)'''

#Shallow copy of list
#without inbuild
'''list2=list1
print(list1)
print(id(list1))
print(id(list2))'''

## with inbuild
'''import copy
list2=copy.copy(list1)
print(id(list1))
print(id(list2))'''

## removing particular element form list
'''list1.remove(5)
print(list1)'''

## Add new element to list,tuple,dictionery
##List-
'''list1.append(85)'''

#Tuple-
'''TUPLES ARE IMMUTABLE'''
# Dictionery-
dict1={"Name":
"Rohan","Age":23}
dict1["Gender"]="Male"
print(dict1)
