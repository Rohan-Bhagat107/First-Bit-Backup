def power(no):
    count=0
    while no>0:
        digit=no%10
        count+=1
        no=no//10
    return count

def is_armstrong(n,org_no):
    i=power(org_no)
    if n==0:
        return 0
    else:
        return ((n%10)**i)+is_armstrong(n//10,org_no)

no=int(input("Enter a number: "))
org_no=no
res=is_armstrong(no,org_no)
if res==org_no:
    print(f"{org_no} is an armstrong number.")

else:
    print(f"{org_no} is not armstrong number.")