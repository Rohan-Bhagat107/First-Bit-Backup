#WAP to print all odd numbers until n 

n=int(input("How many odd numbers you want: "))
for i in range(1,n+1,+2):
    print(i)