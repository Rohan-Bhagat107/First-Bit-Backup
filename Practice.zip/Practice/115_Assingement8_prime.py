# Sum of all prime numbers between 1 to n

#with para with return

def is_prime(no):
    sum=0
    for i in range(2,no+1):
        for j in range(2,i):
            if i%j==0:
                break
        else:
            sum+=i
    return sum

no=int(input("Enter a number upto which you want sum of prime numbers: "))
res=is_prime(no)
print(f"Sum of all prime numbers from 1 to {no} is: {res}")

