# class Circle():
#     def __init__(self,r):
#         self.r=r
#     def area(self):
#         print("Area of circle is: ",3.14*self.r**2)

# class rectangle():
#     def __init__(self,l,b):
#         self.l=l
#         self.b=b
#     def area(self):
#         print("Area of rectangle  is: ",l*b)


# from abc import ABC,abstractmethod
# class Parent():
#     @abstractmethod
#     def demo(self):
#         pass

# class Child(Parent):
#     def demo(self):
#         print("THis is child Class")
    
# C=Child()
# C.demo()

class Parent():
    def display():
        print("THis is static method")

P=Parent()
Parent.display()