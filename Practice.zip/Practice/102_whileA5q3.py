# '''	#Accept no. of passengers from user and per ticket cost. Then accept age of each 
#  passenger and then calculate total amount to ticket to travel for all of them based on 
#  following condition :
#  a.	Children below 12 = 30% discount
#  b.	Senior citizen (above 59) = 50% discount
#  c.	Others need to pay full.'''


no_of_passengers=int(input("Enter how many passengers are travelling: "))
cost_of_1_ticket=int(input("Enter the cost of 1 ticket: "))
total=0
count=1
while count<=no_of_passengers:
    age=int(input("Enter age of passenger: "))
    if age<12:
        dis=cost_of_1_ticket*30/100
        total+=dis

    elif age>59:
        dis=cost_of_1_ticket/2
        total+=dis
    else:
        total+=cost_of_1_ticket
    count+=1

print("Total cost for travelling",count,"passengers is: ",total)

