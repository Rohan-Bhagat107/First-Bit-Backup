#WAP to print factorial of a number.

n=int(input("Enter a number that you want to check: "))
fact=1
for i in range (2,n+1):
    fact*=i
print("Factorial of",n,"is",fact)

