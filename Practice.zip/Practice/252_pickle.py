import pickle

list1=[2,5,8,1,6]
with open ("picklepractice.abc","wb") as fp:
    pickle.dump(list1,fp)
    print("Data Saved!")
with open("picklepractice.abc","rb") as fp:
    data=pickle.load(fp)
    print(data)