def sum(n):
    if n==1:
        return 1
    else:
        return n+sum(n-1)


no=int(input("Enter a number upto which you want sum of numbers: "))
res=sum(no)
print("Sum of numbers from 1 to",no,"is: ",res)