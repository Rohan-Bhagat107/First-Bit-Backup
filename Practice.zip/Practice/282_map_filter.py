data=[1,2,3,4,5]
def double(x):
        return x*2

result=(map(double,data))
print(list(result))


def is_even(x):
    return x%2==0

filter_result=filter(is_even,data)
print(list(filter_result))

