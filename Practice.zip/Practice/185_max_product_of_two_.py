#You have a collection of data.Find the max product of 2 numbers in given list.

l=[2,69,3,7,10,2,11,6,9,5]

l_set=set(l)
print(l_set)
max=0
second_max=0


for i in l_set:
    if i>max:
        second_max=max
        max=i
    elif i>second_max:
        second_max=i
    
print(f"Max product is of {max} and {second_max} and it is: {max*second_max}")

#You have a collection of data.Find the minimum product of 2 numbers in given list.


