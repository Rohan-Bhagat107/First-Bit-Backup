from abc import ABC,abstractmethod
class Vehcile(ABC):
    def wheels(self):
        pass

class Car(Vehcile):
    def wheels(self):
        print("Car has 4 wheels")

c=Car()
c.wheels()

