l=[2,8,1,9,3,11,0,7]
l[3]=10
#print(l)

## append
l.append(6)
print(l)


# insert
l.insert(1,9)
print(l)

l.insert(-3,12)
print(l)

# pop
l.pop()
print(l)

# pop with index
l.pop(3)
print(l)
print(l)
l.append(6)
l.append(6)

# remove
l.remove(6)
print(l)

# count
print(l.count(6))

# max
print(max(l))

# min
print(min(l))

# index
print(l.index(0))
