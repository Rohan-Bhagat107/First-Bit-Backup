word="Hello"
rev_word=word[::-1]
print(rev_word)

print(word==rev_word)


