import threading

def display(msg):
    for i in msg:
        print(i)
        
t1=threading.Thread(name="Thread1",target=display,args=("FirstBit"))
t2=threading.Thread(name="Thread2",target=display,args=("Hello"))

t1.start()

t2.start()