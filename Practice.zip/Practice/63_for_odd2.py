#print odd numbers from 20 to 3:

for i in range(20,2,-1):
    if i%2==1:
        print(i)