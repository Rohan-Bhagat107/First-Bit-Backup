#WAP to print table of a number:

no=int(input("Enter a number of which you want the table:"))
i=1
while i<=10:
    print(no,"x",i,"=",no*i)
    i+=1
