import threading
import time
def display(msg):
    lock1.acquire()
    for i in msg:
        print(i)
        time.sleep(2)
    lock1.release()

def info(msg):
    for i in msg:
        print(i)
        time.sleep(2)

t1=threading.Thread(name="Thread1",target=display,args=("Rohan",))
t2=threading.Thread(name="Thread2",target=info,args=([1,2,3,4,5],))

lock1=threading.Lock()
t1.start()
t2.start()