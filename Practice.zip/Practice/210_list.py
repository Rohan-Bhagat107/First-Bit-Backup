# l1=[1,7,8,9,4,8]
# l2=[]
# Removing element without using inbuilt
# for i in l1:
#     if i==8:
#         continue
#     else:
#         l2.append(i)
# print(l2)

# removing particular occurance of any element without inbuilt

# count=0
# for i in l1:
#     if i==8 and count==5:
#         continue
#     else:
#         l2.append(i)
#         count+=1
# print(l2)

l1=[3,4,2,7,2,9,1,2,11,8]
l2=[]
for i in l1:
    
    if i==2:
        continue
    else:
        l2.append(i)
l1=l2
print(l1)
print(id(l1))
print(id(l2))
