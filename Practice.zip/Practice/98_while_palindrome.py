#WAP to check a number is palindrome or not
no=int(input("Enter a number: "))
org_no=no
rev=0
while no>0:
    rev=rev*10+no%10
    no=no//10
if rev==org_no:
   print(org_no,"is a palindrome")
else:
    print(org_no,"is not a palindrome.")
