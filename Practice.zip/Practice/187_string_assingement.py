# Write a Python program to find elements in a given set that are not in 
# another set.

# set1={1,3,4,5,6,3,8,3}
# set1.pop()
# print(set1)
# set1.remove(3)
# print(set1)

a=input("Enter Any string: ")
b=""
for i in range(1,len(a)+1):
    b+=a[-i]
print(b)

#or

# for i in a:
#     b=i+b
# print(b)