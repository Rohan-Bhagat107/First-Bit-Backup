#WAP to print square of numbers from 1 to 11

a=1
while a<=11:
    print(a,"x",a,"=",a*a)
    a+=1