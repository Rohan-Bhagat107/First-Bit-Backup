n=int(input("enter a number upto which you want to print fibbonacci series: "))
a=1
b=0
for i in range(1,n+1):
    c=a+b
    print(c)
  
    a=b
    b=c

# terms=int(input("Enter how many fibo terms you want: "))
# a=0
# b=1
# for i in range(1,terms+1):
#     c=a+b
#     print(c)
#     a,b=b,c