#WAP to print sum of first 10 numbers(1 to 10)

a=1
sum=0
while a<=10:
    sum+=a
    a+=1
print("sum of first 10 numbers is: ",sum)