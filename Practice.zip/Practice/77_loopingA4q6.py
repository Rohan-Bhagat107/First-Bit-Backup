# WAP to check if a given number is prime number or not.

no=int(input("Enter a number: "))
for i in range(2,no):
    if no%i==0:
        print(no,"is not a prime number.")
        break
else:
    print(no,"is a prime number.")

