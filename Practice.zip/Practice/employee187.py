# class employee():
#     def __init__(self,id,name,salary):
#         self.id=id
#         self.name=name
#         self.salary=salary
    
#     def __str__(self):
#         return f"ID: {self.id} | Name: {self.name} | Salary: {self.salary}"
    


for i in range(1,7):
    for j in range(1,7-i):
        print("*",end=" ")
    for j in range(1,i+1):
        print(" A ",end=" ")
    print()