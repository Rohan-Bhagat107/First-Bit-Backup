# string=input("Enter any sentence: ")
# word_count=1
# unique_words=set(string)
# count=1
# frequncy={}
# for i in string:
#     if i==" ":
#         word_count+=1
# print(word_count)


