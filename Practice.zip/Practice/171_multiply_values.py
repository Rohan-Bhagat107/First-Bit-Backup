#WAP to multiply all values in a dictionary
data={}
data2={}
no=int(input("Enter how many key-value pairs you want to add in dictionary: "))
multiplier=int(input("Enter a multipler for values: "))
for i in range(no):
    key=input("Enter key: ")
    value=int(input("Enter value: "))
    data[key]=value
    data2[key]=value*multiplier
print(data)

print(f"Dictionary after multiplying values with {multiplier} is: ")
print(data2)
