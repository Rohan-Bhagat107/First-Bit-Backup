#create a dictionary that contains values as square of its keys
start=int(input("Enter a start of your range: "))
end=int(input("Enter end of your range: "))
dict1={}
for i in range(start,end+1):
    dict1[i]=i*i
print(dict1)
