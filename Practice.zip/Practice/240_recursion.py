def num_sum(n):
    if n==0:
        return 0
    else:
        return n+num_sum(n-1)
res=num_sum(5)
print(res)