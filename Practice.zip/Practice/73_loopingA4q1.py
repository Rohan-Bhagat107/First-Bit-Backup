#WAP to print all even numbers until 

n=int(input("How many even numbers you want: "))
for i in range(2,n+1,+2):
    print(i)