#WAP to check if given number is Perfect Number.


n=int(input("Enter a number: "))
sum=0
for i in range(1,n+1):
    if n%i==0:
        sum+=1

if sum==n:
    print(n,"is a perfect number.")
else:
    print(n,"is not a perfect number.")