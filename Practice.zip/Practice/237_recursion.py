def power_calculator(n,p):
    
    if p==1:
        return n
    else:
        return n*power_calculator(n,p-1)
res=power_calculator(2,3)
print(res)
