def trial():
    try: 
        n=int(input("ENter a number: "))
    except ValueError:
        print("Invalid value")
    else:
        print("You are eligible!")
        return "Returning from else block"
    
    finally:
        print("Thank you for your response")
res=trial()
print(res)
