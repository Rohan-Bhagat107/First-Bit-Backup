#WAP to count the frequency of unique words in a sentence using set and dictionary concept: 

string=input("Enter a string: ")
list1=(string.split(" "))
data=set(list1)
data2={}
for i in data :
    count=0
    for j in list1:
        if i==j:
         count+=1
    data2[i]=count
print(data2)
x=string.lower()
print(string)
    
