#print the reverse of given number:

def reverse(no,rev):
    if no==0:
        return rev
    else:
        return reverse(no//10,rev*10+no%10)

no=int(input("enter a number: "))
res=reverse(no,0)
print(res)