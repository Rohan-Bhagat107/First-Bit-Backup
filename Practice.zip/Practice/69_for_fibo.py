#WAP to print fibonacci series

term=int(input("Enter how many fibonacci terms you want to print: "))
a=1
b=0
for i in range(a,term+1):
    c=a+b
    print(c)
    a=b
    b=c
    