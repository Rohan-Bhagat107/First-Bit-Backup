n=int (input("Enter a number: "))
# ----------------By converting it into string----------------

string_number=str(n)
rev_num=string_number[::-1]
print(rev_num)


#-----------Using Reursion----------------
# def rev_num(no,rev):
#     if no==0:
#         return rev
#     else:
#         return rev_num(no//10,rev*10+no%10)

# res=rev_num(n,0)
# print(res)


#----------------Using while loop-------------

# reversed_num=0
# while n>0:
#     digit=n%10
#     reversed_num=reversed_num*10+digit%10
#     n=n//10
# print(reversed_num)
