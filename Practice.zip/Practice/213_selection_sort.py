# l1=[5,2,1,11,6,13,8]

# for i in range(len(l1)):
#     min=i
#     for j in range(i+1,len(l1)):
#         if l1[j]<l1[min]:
#             l1[j],l1[min]=l1[min],l1[j]
# print(l1)


data=[2,4,1,7,6,3]
for i in range(len(data)):
    min=i
    for j in range(i+1,len(data)):
        if data[min]>data[j]:
            data[min],data[j]=data[j],data[min]

print(data)