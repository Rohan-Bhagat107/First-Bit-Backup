	# Write a program to calculate the total cost of painting. The interior of building with four equal sized walls.

side=int(input("Enter side of wall: "))
area_square=4*side          #of 1 wall there are total 4 walls +1 ceiling
area_building=area_square*4
cost_per_wall=int(input("Enter cost of painting one wall: "))
total_cost=(cost_per_wall*area_building)
print("Total cost of painting interior of building is: ",total_cost,"INR")

