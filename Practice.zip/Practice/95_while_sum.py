#WAP to print sum of numbers form 11 to 23

a=11
sum=0
while a<=23:
    sum+=a
    a+=1
print("print sum of numbers form 11 to 23 is: ",sum)