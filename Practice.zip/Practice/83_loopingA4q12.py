# WAP to print Armstrong number within a given range

start=int(input("Enter start of your range: "))
end=int(input("Enter end of your range: "))
for n in range(start,end+1):
    count=0
    org_no=n
    while n!=0:
        digit=n%10
        n=n//10
        count+=1
        

    n=org_no
    sum=0
    while n!=0:
          digit2=n%10
          n=n//10
          power=digit2**count
          sum+=power
    if sum==org_no:
       print(org_no)
    
    

        
        

