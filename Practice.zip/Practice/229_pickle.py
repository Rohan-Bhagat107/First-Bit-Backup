import pickle 
class Student():
    def __init__(self,Id,Name,Age):
        self.id=Id
        self.name=Name
        self.age=Age
    def __str__(self):
        return f"Id:{self.id} | Name: {self.name} | Age: {self.age}\n"

class College():
    def __init__(self):
        self.stud=[]
    
    def clear_list(self):
        self.stud.clear()
        return
    def show_all_students(self):
        with open("College_data.abc","rb") as fp:
            data=pickle.load(fp)
            for i in data:
                print(data)

    def add_student(self):
        self.clear_list()
        # with open("College_data.abc","rb")as fp:
        #     data=pickle.load(fp).split(" ")
        #     for i in data:
        #         print(i)
                # self.stud.append(i)
                
        id=int(input("Enter student ID: "))
        name=input("Enter student name here: ")
        age=int(input("Enter student age here: "))
        s=Student(id,name,age)
        self.stud.append(s)
        with open("College_data.abc","ab")as fp:
            pickle.dump(self.stud,fp)
            print("Data Saved!")
    
    

    
if (__name__)=="__main__":
    c=College()
    
    while True:
        print('''What do you want to do?
        1)Show all students 
        2)Add Student
        3)Delete Student
        4)Edit Student
        5)Exit'''
        )
        choice=int(input("Enter your choice here: "))
        if choice==1:
            c.show_all_students()
        elif choice==2:
            c.add_student()
