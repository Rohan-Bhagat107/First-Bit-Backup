#Q4)  S = a + a2 / 2 + a3 / 3 + …… + a10 / 

a=int(input("ENter a number: "))
sum=0
for i in range(1,11):
    sum+=a**i/i
print("Sum of series is: ",int(sum))