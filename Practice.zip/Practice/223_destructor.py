class Shape():
    def __init__(self,color):
        self.color=color
    def display(self):
        print("This is the display method")
    def info(self):
        print("Color of shape is", {self.color})
    def __del__(self):
        print("Distructor is called")
S=Shape("Grey")
S.display()
del(S)
print(S.info())
# try:
#     print(S.info())
# except:
#     print("Object deleted!")
# else:
#     print("Object Found!")
