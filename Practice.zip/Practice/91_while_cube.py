#WAP to print cube of numbers from 5 to 15

a=5
while a<=15:
    print(a,"^3=",a**3)
    a+=1
