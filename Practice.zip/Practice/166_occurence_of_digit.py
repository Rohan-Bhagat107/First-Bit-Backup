#find all numbers from 1-1000 that have 6 in them

#regular way to solve this question is: 

for i in range(1,1001):
    num=i
    while num!=0:
        digit=num%10
        if digit==6:
            print(num)
        num=num//10
        
        
