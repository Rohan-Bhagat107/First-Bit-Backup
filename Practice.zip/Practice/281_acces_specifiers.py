class Circle():
    radius=15
    __color="Grey"
    _circumference=255
    def __init__(self,diameter):
        self.diameter=diameter

    def display(self):
        print("color of circle is: ",self.__color)
        print("Circumference of circle is: ",self._circumference)



c=Circle(30)
c.display()
print(c._Circle__color)
print(Circle._circumference)