wheels=4
class Vehicle():
    color="Gery"
    def display():
        print("Color of vehicle is : ",Vehicle.color,"and wheels are",wheels)
v=Vehicle()
Vehicle.display()