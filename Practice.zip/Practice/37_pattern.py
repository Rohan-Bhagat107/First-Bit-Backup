# #         1   
#         1   1
#       1   2    1
#     1   3    3    1
for i in range(0,4):
    for j in range(1,6-i):
        print(" ",end=" ")
    for j in range(1,i+2):
        if j==1 or j==i+1 :
            print("1  ",end=" ")
        else:
            print(i,"  ",end=" ")
    print()