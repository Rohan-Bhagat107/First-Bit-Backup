data=[]
data2=[]
no=int(input("How many elements you want to add in a list: "))
for i in range(no):
    element=int(input("Enter the element: "))
    data.append(element)
    if element not in data2:
        data2.append(element)
print("Original list is: ",data)
print("List with uique elements is: ",data2)


