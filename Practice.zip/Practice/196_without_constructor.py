class square():
    def set_attributes(self,side):
        self.side=side
    
    
    def display(self):
        print("side is: ",self.side)
        print("Area is: ",self.side**2)

a=square()
a.set_attributes(2)
a.display()
        