# word="Hello"
# print(type(word))
# print(int(word))

number="12"
print(type(number))
print(int(number))
print(type(number))