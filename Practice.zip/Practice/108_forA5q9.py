#Q 2)=>    N + N^2 + N^3+N^4 …..+N^N (here ^ means exponent)

no=int(input("Enter a number of which you want sum of powers: "))
sum=0
for i in range(1,no+1):
    sum+=no**i
print(sum)