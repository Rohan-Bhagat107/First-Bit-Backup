class parent():
    # __color="Brown"
    # _hairs="Curly"
    def display(self):
        print("This is parent")
    
class child(parent):
    def display(self):
        print("This is child")
        # super().display()
    


c=child()
c.display()
# print(c._parent__color)
# print(parent._hairs)