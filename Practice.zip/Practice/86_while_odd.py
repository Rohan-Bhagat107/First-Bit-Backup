#WAP to print all odd numbers from 1 to n

n=int(input("Enter a number upto which you want the odd numbers:"))
a=1
while a<=n:
    if a%2==0:
        a+=1
        continue
    else:
        print(a)
        a=a+1
