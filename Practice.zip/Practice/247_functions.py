# 1) with parameter with return
def square(num):
    return num**2
res=square(2)
print(res)

#2) with para without return
def square(num):
    print(num**2)
square(2)

#3)without para with return
def square():
    n=int(input("Enter number: "))
    return n**2
res=square()
print(res)

