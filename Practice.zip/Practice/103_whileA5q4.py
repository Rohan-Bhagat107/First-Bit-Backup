#	Write a program to check if given number is Armstrong number or not

no=int(input("Enter a number: "))
count=0
org_no=no
while no>0:
    digit=no%10
    no=no//10
    count+=1

no=org_no
sum=0
while no>0:
    digit=no%10
    fact=1
    for i in range(1,digit+1):
        fact*=digit**count
        sum+=fact
        break
    no=no//10
    
if sum==org_no:
    print(org_no,"is an armstrong numbere.")
else:
    print(org_no,"is not a armstrong number.")

