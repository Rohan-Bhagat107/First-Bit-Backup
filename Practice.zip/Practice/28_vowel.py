#Take input of alphabet and check is it is vowel or not:

alpha=input("Enter alphabet: ")

# if alpha=="a" or alpha== "A" or alpha=="e" or alpha== "E" or alpha=="i" or alpha=="I" or alpha=="o" or alpha=="O" or alpha=="u" or alpha== "U":
#     print(alpha,"is a vowel.")
# else:
#     print(alpha,"is not a vowel it is a consonant.")

if alpha in ("a","e","i","o","u","A","E","I","O","U"):
    print(alpha,"is a vowel.")
else:
    print(alpha,"is not a vowel it is a consonant.")