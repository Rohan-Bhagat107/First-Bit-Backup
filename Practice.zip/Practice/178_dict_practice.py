dict1={"name":"Rohan","Age":23,"City":"Buldhana"}
for i in dict1.keys():
    if i=="name":

        print("This key is present in the dictionary")
        break
else:
    print("Not present")

