#WAP to check a given no. is armstrong number or not using function

def armstrong_no(n):
    count=0
    org_no=n
    while n!=0:
        digit=n%10
        n=n//10
        count+=1
    n=org_no
    sum=0
    while n!=0:
        x=n%10
        
        power=x**count
        sum+=power
        n=n//10
    if sum==org_no:
        return True
    else:
        return False


n=int(input("Enter a number: "))
res=armstrong_no(n)
if res==True:
    print(n,"is an armstrong no.")
else:
    print(n,"is not a armstrong no.")

