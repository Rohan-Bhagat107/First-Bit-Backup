import pickle

list1=[5,1,8,2,3,9,4]
list2=[15,1,8,2,3,9,58]

# with open("pickleDemo.abc","wb") as fp:
#     pickle.dump(list1,fp)
#     print("data saved!")

# with open("pickleDemo.abc","ab") as fp:
#     pickle.dump(list2,fp)
#     # print(data)

with open("pickleDemo.abc","rb") as fp:
    data=pickle.load(fp)
    print(data)
    # for i  in data:
    #     print(i)