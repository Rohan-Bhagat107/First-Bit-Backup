#WAP to print sum of all elements of a list (take user input for list)

data=[]
no=int(input("How many elements you want to add in a list: "))
sum=0
for i in range(1,no+1):
    n=int(input("Enter the element: "))
    data.append(n)
    sum+=n
print(data)
print(sum)
