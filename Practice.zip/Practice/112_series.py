# Write a program to find sum of following series using functions :
#        1+ 2 + 3 + 4+….. + n

#With para with return

def sum(n):
    sum=0
    for i in range(1,n+1):
        sum+=i
    return sum

no=int(input("Enter a number upto which you want sum of series: "))
res=sum(no)
print("Sum of series from 1 to",no,"is: ",res)
