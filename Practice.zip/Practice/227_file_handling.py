name=input("Enter name: ")

with open("demo.txt","w") as fp:
    fp.write(name+"\n")
    print("Data saved!")
with open("demo.txt","a") as fp:
    fp.write(name+"\n")
    print("Data saved!")

with open("demo.txt","r") as fp:
    data=fp.read().split(" ")
    for i in data:
        print(i)


# with open("demo.txt","w+") as fp:
#     fp.write(name+"\n")
#     print("Data saved!")
#     data=fp.read().split(" ")
#     for i in data:
#         print(i)
    