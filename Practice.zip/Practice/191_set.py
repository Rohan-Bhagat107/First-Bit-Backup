set1={1,12,"Hello"}
set1.add(13)
print(set1)
