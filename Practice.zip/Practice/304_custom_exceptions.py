class Age_error(Exception):
    def __str__(self):
        return f"You are not eligible to vote!"
    

try:
    age=int(input("Enter your age :"))
    if age<18:
        raise Age_error
except Age_error as a:
    print(a)
else:
    print("Thank You Dear!🫡")
finally:
    print("Your Data has been saved!")