#Find all numbers from 1-1000 that are divisible by 8

#regular way to solve this question is: 
for i in range(1,1001):
    if i%8==0:
        print(i)


#another way to solve this question is:  list comprehension

# num=[x for x in range(1,1001) if x%8==0]
# print(num) 