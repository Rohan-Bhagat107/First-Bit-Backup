x = lambda a,b : a + b
print(x(5,5))
Addition=lambda  a,b,c: a+b+c
print(Addition(1,2,3))