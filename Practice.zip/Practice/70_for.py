#WAP to print table of 3 using step size

for i in range(1,11):
    print(3*i)

                       #or

#step size
# for i in range(3,33,3):
#     print(i)

#WAP to print sq of numbers form 1 to 20 using step size
# for i in range(2,21,+2):
#     print(i)

