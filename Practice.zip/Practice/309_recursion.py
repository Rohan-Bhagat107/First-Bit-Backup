# def fibbo(n,a=1,b=0):
#     if n==0:
#         return 
#     else:
#         c=a+b
#         print(c)
#         return fibbo(n-1,a=b,b=c)
# fibbo(7)

#Reverse of number
# def rev_num(no,rev=0):
#     if no==0:
#         return rev
#     else:
#         return rev_num(no//10,rev*10+no%10)

# res=rev_num(123)
# print(res)

#Factorial of number
# def fact(num):
#     if num==1:
#         return 1
#     else:
#         return num*fact(num-1)

# res=fact(4)
# print(res)
