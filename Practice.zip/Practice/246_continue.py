for i in range(1,11):
    if i==7:
        continue
    # print(i)

n=int(input("Enter a number that you want to check: "))
for i in range(2,n):
    if n%i==0:
        print("Not prime")
        break
else:
    print("Prime number")