def fibbonacci(term,a,b):
    if term==0:
        return
    else:
        c=a+b 
        print(c)
        return fibbonacci(term-1,b,c)
    
term=int(input("How many fibo terms you want to print: "))
fibbonacci(term,0,1)
