def var_kwargs(**args):
    #print(args)
    for i in args:
        print(i)


var_kwargs(name="Rohan",age=23)
var_kwargs(Name="Kshitij",Roll_no=101,age=24)
var_kwargs(name="Prafull",age=22,city="nagar",mob_no=123459)
