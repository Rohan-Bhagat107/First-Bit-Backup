a=30
b=15
print("Sum of a & b is: ",a+b)

c=458
d=15
print("Remender of c & d is: ",c%d)

e=15
f=25
print(e>f)
g=65
h=65
print(g<=h)