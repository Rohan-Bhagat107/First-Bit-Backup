#calculate total salary in company where {employee:salary}

dict1={"emp1":30000,"emp2":40000,"emp3":50000}
sum=0
for i in dict1.values():
    sum+=i
print("Total salary of all employees is: ",sum)
