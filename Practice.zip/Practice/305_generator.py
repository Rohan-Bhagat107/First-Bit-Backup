import random
def rand_numbers(n):
    yield random.randint(120,154)

for i in range(5):
    print(next(rand_numbers(i)))