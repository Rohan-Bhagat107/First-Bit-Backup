l=[3,8,6,7,1]
max=l[0]
second_max=l[0]

for i in l:
    if i>max:
        second_max=max
        max=i
    elif i>second_max:
        second_max=i
print("Second max is: ",second_max)