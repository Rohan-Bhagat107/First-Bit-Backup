n=int(input("ENter a number: "))
def factorial(num):
    fact=1
    for i in range(2,num+1):
        fact=fact*i
    return fact
        
def sum(no):
    if no==1:
        return 1
    else:
        return factorial(no)+sum(no-1)

res=sum(n)
print(res)