data=[2,6,5,1,3]

for i in range(len(data)):
    min=i
    for j in range(i+1,len(data)):
        if data[j]<data[min]:
            
            data[j],data[min]=data[min],data[j]
print(data)

# data=[2,5,1,9,8,6]
# for i in range(len(data)-1):
#     min=i
#     for j in range(i+1,len(data)):
#         if data[j]<data[min]:
#             data[j],data[min]=data[min],data[j]
# print(data)

