#copy()->  new_list=original_list_ref.copy()
import copy
L1=[10,8,9,[13,14,7,12]]
L2=copy.deepcopy(L1)
L1[-1][0]=22
print(L1)
print(L2)