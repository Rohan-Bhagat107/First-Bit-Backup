class Age_error(Exception):
    def __str__(self):
        return f" You are not eligible to vote"

class Voting():
    try:
        age=int(input("Enter your age here: "))
        if age>=18:
            print("You are eligible")
        else:
            raise Age_error
    except Age_error as obj:
        print(obj)
