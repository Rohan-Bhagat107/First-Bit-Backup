n=int(input("Enter a number: "))
sum=0
number=n
while n!=0:
    digit=n%10
    fact=1
    for i in range(2,digit+1):
        fact*=i
    sum+=fact
    n=n//10
if sum==number:
    print("It is strong number.")
else:
    print("Not strong number")
