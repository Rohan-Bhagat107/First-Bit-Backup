#WAP to print numbers from 100 to 200  that are divisible by 7

a=100
while a<=200:
    if a%7==0:
        print(a)
        a+=1
    else:
        a+=1