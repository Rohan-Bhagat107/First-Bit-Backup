#Write a program to check if entered year is a leap year or not.
def is_leap_year(year):
    if year %4==0:
        if  year%100==0:
            if year%400==0:
                return True
        return True
    return False

y=int(input("Enter year: "))
res=is_leap_year(y)
if res==True:
    print(f"{y} is a leap year")
else:
    print(f"{y} is not a leap year")