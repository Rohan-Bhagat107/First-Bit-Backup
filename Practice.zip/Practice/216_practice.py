data=[5,2,4,6]
data2=[]
n=4
data.remove(n)
# for i in data:
#     if i==n:
#         continue
#     else:
#         data2.append(i)
# print(data2)
        


# data.pop(2)
# print(data)
