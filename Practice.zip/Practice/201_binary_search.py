data=[1,2,3,5,8,11,12,13]
start=0
end=len(data)-1

n=12


for i in data:
    mid=(start+end)//2
    if n==data[mid]:
        print(f"{n} is present in the list at index: ",mid)
        break
    elif n<data[mid]:
        end=mid-1
        start=start
        
    elif n>data[mid]:
        end=end
        start=mid+1
else:
    print("Not present")

