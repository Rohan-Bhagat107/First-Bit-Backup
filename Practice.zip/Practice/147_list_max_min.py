#WAP to find max and minimum element of a list(take user input for list elements)
data=[]
no=int(input("How many elements you want to add in a list: "))
max=0
min=0
for i in range(no):
    n=int(input("Enter the element: "))
    data.append(n)
print(data)
for i in range(len(data)):
    for j in range(i+1,len(data)):

        if data[i]>=data[j]:
            data[i],data[j]=data[j],data[i]

#print(data)
max=data[len(data)-1]
min=data[0]
#second_largest=data[len(data)-2]
print("Max is: ",max)
print("Min is",min)
#print(second_largest)


