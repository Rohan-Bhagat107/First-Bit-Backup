set1={1,5,3,8,4,9,0,22,35}
set1.add(35)
print(set1)

set1.remove(35)
set1.pop()
print(set1)