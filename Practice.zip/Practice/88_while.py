#WAP to print numbers from 200 to 1 in reverse order

# a=200
# while a>=1:
#     print(a)
#     a-=1
a=200
while a>=1:
    print(a)
    a-=1