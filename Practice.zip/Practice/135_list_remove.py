#remove()-> list_ref.remove(element)
list1=[1,2,5,3,4,5]  
list1.remove(5)  #removes first occurance of that particular element
print(list1)