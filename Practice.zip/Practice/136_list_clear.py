#clear()-> list_ref.clear()
list1=[1,2,3,4,5]
list1.clear()
print(list1)