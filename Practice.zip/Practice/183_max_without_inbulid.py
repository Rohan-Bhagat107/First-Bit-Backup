l=[3,6,8,1,7,6]
max=l[0]
for i in l:
    if i>max:
        max=i
print("max:",max)