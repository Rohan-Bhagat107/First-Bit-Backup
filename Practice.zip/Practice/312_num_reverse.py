# try:
#     no=int(input("Please enter a number you want to reverse: "))
# except Exception as e:
#     print("Please enter a valid number!")
# else:
#     rev=0
#     while no>0:
#         digit=no%10
#         no=no//10
#         rev=rev*10+digit
# print(rev)

def rev_num(num,rev):
    if num==0:
        return rev
    else:
        return rev_num(num//10,rev*10+num%10)

result=rev_num(145,0)
print(result)