def is_palindrome(num,rev):
    if num==0:
        return rev
    else:
        return is_palindrome(num//10,rev*10+num%10)
no=123
result=is_palindrome(no,0)
if no==result:
    print("it's a plindrome")
else:
    print("Not Palindrome")