def add():
    print(2+3)


def add():
    print(2**2)
    sw
def add():
    print(2*3)
    


add()