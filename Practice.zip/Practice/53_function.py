#convert days into year,week,day format

def convert_days(days):
    year=days//365
    week=(days%365)//7
    day=(days%365)%7
    print("Your converted days are: ",year,"year",week,"weeks",day,"day")
n=int(input("Enter no. of days: "))
convert_days(n)
