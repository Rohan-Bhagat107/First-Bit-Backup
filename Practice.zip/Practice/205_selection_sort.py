data=[2,8,1,11,3,5]

for i in range(len(data)-1):
    min=i
    for j in range(i+1,len(data)):
        if data[j]<data[min]:
            data[j],data[min]=data[min],data[j]
print(data)