import random
# def rand_numbers(n):
#     # for i in range(n):
#     yield random.randint(120,514)
# for i in range(1,7):
#     print(next(rand_numbers(i)))


def rand_numbers(n):
    yield random.randint(120,154)

for i in range(5):
    print(next(rand_numbers(i)))