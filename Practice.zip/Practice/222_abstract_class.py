from abc import ABC,abstractmethod
class Parent(ABC):
    @abstractmethod
    def display(self):
        pass

