class Shape():
    def __init__(self,color):
        self.color=color
    def display(self):
        print("Color of shape is: ",self.color)

    
class Circle(Shape):
    def display(self):
        super().display()
        print("Color of circle is",self.color)


C=Circle("Grey")
C.display()
        
