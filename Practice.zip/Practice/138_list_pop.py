#pop()-> list_ref.pop()
# list1=[1,2,3,4,5]
# list1.pop()
# print(list1)
# list1.pop()
# print(list1)

#pop with index
list1=[1,2,3,4,5]
list1.pop(4)
print(list1)
list1.pop(2)
print(list1)
