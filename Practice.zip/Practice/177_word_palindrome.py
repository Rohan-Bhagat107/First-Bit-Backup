# #WAP to check if a given string is a palindrome or not: 
word=input("Enter any word: ")
word_list=list(word)
original_list=word_list
#print(word_list)
print(original_list)
word_list.reverse()
reversed_list=[]
for i in word_list:
    reversed_list.append(i)
if original_list==reversed_list:
    print("Given word is a palindrome")
else:
    print("Given word is not a palindrome")





