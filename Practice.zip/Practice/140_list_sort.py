#ascending sort
L1=[10,8,9,13,14,7,12]
L1.sort()
print(L1)

#descending sort
L1=[10,8,9,13,14,7,12]
L1.sort(reverse=True)
print(L1)

