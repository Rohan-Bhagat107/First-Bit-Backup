#WAP to check a given no. is perfect number or not using function


def perfect_no(n):
    add=0
    for i in range(1,n):
        if n%i==0:
            add+=i
    if n==add:
        return True
    else:
        return False
    
n=int(input("Enter a number: "))
res=perfect_no(n)
if res==True:
    print(n,"is a perfect number.")
else:
    print(n,"is not a perfect number.")