#check if a given no. is palindrome or not

n=int(input("Enter a number: "))
org_no=n
rev=0
while n!=0:
    rev=rev*10+n%10   
    n=n//10
if rev==org_no:
    print(org_no,"is a palindrome.")
else:
    print(org_no,"is not a palindrome.")
