def strong_no(n):
    org_no=n
    sum=0
    while n!=0:
        digit=n%10
        fact=1
        for i in range(2,digit+1):
            fact*=i
        sum+=fact
        n=n//10

    if org_no==sum:
        return True
    else:
        return False
    
n=int(input("Enter a number: "))
res=strong_no(n)
if res==True:
    print(n,"is a strong number.")
else:
    print(n,"is not a strong number.")
