s1={1,8,8,9,2,4,True,"Rohan"}
print(s1)
s1.add("Pune")

s2={8,9,True,"Pune",2,4,1,"Rohan"}
print(s1.issubset(s2))


