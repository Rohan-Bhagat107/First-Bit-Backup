# Enter number of students from user. For those many students accept marks of 5 
# subject marks from user and calculate percentage. Display all percentage and 
# average percentage of students.

no_of_student=int(input("Enter How many students are there?: "))
total_marks=int(input("Enter Total marks of 5 subject: "))
count=0
sum=0
while count<=no_of_student:
    total=0
    s1=int(input("Enter marks obtained in 1st subject: "))
    s2=int(input("Enter marks obtained in 2nd subject: "))
    s3=int(input("Enter marks obtained in 3rd subject: "))
    s4=int(input("Enter marks obtained in 4th subject: "))
    s5=int(input("Enter marks obtained in 5th subject: "))
    count+=1
    total=s1+s2+s3+s4+s5
    percentage=int((total/total_marks)*100)
    print("percentage of student",count,"is: ",percentage)
    sum+=percentage
    if count==no_of_student:
        break
avg_percentage=float((sum//no_of_student))
print("Average percentage of",count,"students is: ",avg_percentage)


    