# .	Write a program to solve the following series 

#Q 1)=>   1! + 2! + 3! + 4! + …..n!

n=int(input("Enter a number upto which you want sum of series: "))
sum=0
fact=1
for i in range(1,n+1):
    fact*=i
    sum+=fact
print(sum)