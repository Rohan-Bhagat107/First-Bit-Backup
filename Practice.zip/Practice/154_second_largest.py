#WAP to find second largest element in the list
data=[]
num=int(input("How many elements you want to add in list: "))
for i in range(num):
    no=int(input("Enter element: "))
    data.append(no)

for j in range(len(data)):
    for k in range(j+1,len(data)):
        if data[j]<=data[k]:
            data[j],data[k]=data[k],data[j]
print("Descending order of list is:......")     
print(data)
print("second largest number is:....")
print(data[1])