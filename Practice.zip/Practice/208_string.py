word="Beautifull"
for i in range(len(word)):
    if word[i] in ("a","e","o","u") and word[i+1] in ("a","e","i","o","u"):
        print(word[i])
        print(word[i+1])

