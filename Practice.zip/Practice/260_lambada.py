Square=lambda a:a**2

print(Square(2))

# data=[x for x in range(2,8) if x%2==0]
# print(data)

