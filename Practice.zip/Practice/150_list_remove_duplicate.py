#WAP to remove duplicate elements from the list

number=[]
number2=[]
n=int(input("How many elements you want to add in a list: "))
for i in range(n):
    element=int(input("Enter element: "))
    number.append(element)

for j in number:
        if j not in number2:
            number2.append(j)
print("List without duplicates is........")
print(number2)
