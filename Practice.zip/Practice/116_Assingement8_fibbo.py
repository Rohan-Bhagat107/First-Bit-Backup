#	Write a program to  print the following Fibonacci series using functions:
#       1  1  2  3 5 8  n terms
def Fibonacci(n):
    a=1
    b=0
    
    for i in range(1,n+1):
        c=a+b
        print(c)
        a=b
        b=c


no=int(input("Enter how many fibbonacci terms you want"))
Fibonacci(no)
