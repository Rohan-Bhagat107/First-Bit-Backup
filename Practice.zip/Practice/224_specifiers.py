## Public or Global
from datetime import datetime
# todays_date=datetime.now()
# class Specifiers():
#     def __init__(self,specifier_name):
#         self.specifier_name=specifier_name
#     def display(self):
#         print("This is global access specifire demo",todays_date.)


# S=Specifiers("Global")
# S.display()
# print("------------")
# print(todays_date)

'''Private'''
class Specifiers():
    __date="PRIVATE"
    def __init__(self,specifier_name):
        self.specifier_name=specifier_name
    def display(self):
        print("This is global access specifire demo",Specifiers.__date)
S=Specifiers("Private")
S.display()
print("------------")
print(S._Specifiers__date)