#count the number of prime numbers in a given range

start=int(input("Enter start of your range: "))
end=int(input("Enter  end of your range: "))
count=0
for i in range(start,end):
    for j in range(2,i):
        if i%j==0:
            break
    else:
        count+=1
        print(i)
print("Total prime numbers between",start,"to",end,"is: ",count)

# start=int(input("Enter start of your rabge: "))
# end=int(input("Enter end of your rabge: "))
# count=0
# for i in range(start,end+1):
#     for j in range(2,i):
#         if i%j==0:
#             break
#     else:
#         count+=1
# print(count)
