l1=[5,2,8,3,6,1,9]
for i in range(len(l1)):
   for j in range(i+1,len(l1)):
        if l1[i]>l1[j]:
            l1[i],l1[j]=l1[j],l1[i]
print(l1[-2])