#WAP to separate out even and odd numbers from the list in 2 different lists
#Q156--WAP to remove all occurances of a given number from the list

num=[]
even_num=[]
odd_num=[]
no=int(input("How many elements you want to add in list: "))
for i in range(no):
    n=int(input("Enter element: "))
    num.append(n)
    if n%2==0:
        even_num.append(n)
    else:
        odd_num.append(n)

print("Original list....")
print(num)
print("-------------------------")
print("Even number list....")
print(even_num)
print("-------------------------")
print("odd number list....")
print(odd_num)



