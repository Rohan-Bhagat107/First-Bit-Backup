class square():
    def __init__(self,side):
        self.side=side

    def display(self):
        print("side is: ",self.side)
        print("Area is: ",self.side**2)

    def __del__(self):
        print("Distructor is called")

    

a=square(2)
a.display()
# del(a)
print(a)
