# def odd_count(low,high):
#     count=0
#     for i in range(low,high+1):
#         if i%2==0:
#             count+=1
#     print("Total Odd Numbers are: ",count)
# odd_count(2,11)


# Power of Three
# - Given an integer n, return true if it is a power of three. Otherwise, return false.
# - An integer n is a power of three, if there exists an integer x such that n == 3^x.
# def is_power(n,power):
#     if n==3**power:
#         return True
#     else:
#         return False
# n=int(input("Enter a number: "))
# power=int(input("Enter  power: "))
# res=is_power(n,power)
# if res==True:
#     print(n,"is power of 3")
# else:
#     print(n,"is not a power of 3")

def isPowerOfThree(n):
    
    if n <1:
        return False
    
    if n==1:
        return True
    
    if n%3 !=0:
        return False
    
    return n%3==0 and isPowerOfThree(n/3)