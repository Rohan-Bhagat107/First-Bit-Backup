def var_args(*args):
    for i in args:
        print(i)

var_args(2,3)
var_args(2)
var_args(2,8,9,6)