#WAP for quadratic equation using else_if ladder
 
a=int(input("Enter first coefficient: "))
b=int(input("Enter second coefficient: "))
c=int(input("Enter third coefficient: "))

disk=int(b**-4*a*c)
root1=int((-b+(disk**0.5))/2*a)
root2=int((-b-(disk**0.5))/2*a)

if disk>0:
    print("Roots of given quadratic equation is: ",root1,"and",root2)
elif disk==0:
    print("Roots of given quadratic equation are real and equal: ",root2)
else:
    print("complex roots")