#WAP to check if a given number is armstrong number or not

n=int(input("Enter a nunber that you want to check: "))       #153
sum=0
count=0
org_no=n
while n!=0:
    digit=n%10         #3
    n=n//10     #15
    count+=1

n=org_no
while n!=0:
      a=n%10
      n=n//10
      power=a**count
      sum+=power
if sum==org_no:
     print("It is armstrong number.")
else:
     print("Not armstrong number.")


# n=int(input("Enter a number: "))
# sum=0
# org_no=n
# count=0
# while n>0:
#      digit=n%10
#      n=n//10
#      count+=1
# n=org_no
# while n>0:
#      digit=n%10
#      power=digit**count
#      sum+=power
#      n=n//10     
# if org_no==sum:
#      print("Armstrong")
# else:
#      print("Not")