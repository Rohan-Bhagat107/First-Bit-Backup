data=[2,8,2,9,1,9,4,8,89,65,45,6,7,9,4]
# 1) Adding new element
data.append(86)
#  2) removing particular element
data.remove(9)

#  3) removing last element
data.pop()

#  4) Finding maximum element form list
print(max(data))

#  5) Finding Minimum element form list
print(min(data))

#  6) Counting occurance of particular element

print(data.count(9))

# 7) Counting occurance of each element form list
from collections import Counter
print(Counter(data))
