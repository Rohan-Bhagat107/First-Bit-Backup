import threading,time
lock1=threading.Lock()
def display(msg):
    lock1.acquire()
    for i in msg:
        print(i)
        time.sleep(2)
    lock1.release()

def info(msg):
    for i in msg:
        print(i)
        time.sleep(3)

t1=threading.Thread(name="Thread1",target=display,args=("Rohan",))
t2=threading.Thread(name="Thread2",target=info,args=("BHAGAT",))

t1.start()
t2.start()
