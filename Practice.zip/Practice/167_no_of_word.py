#WAP to count number of words and characters in a given string

string=input("Enter any string: ")
word_count=1
character_count=0
words=string.split(" ")
for i in string:
    if i==" ":
        word_count+=1
for j in words:
    for k in j:
        character_count+=1
print("Number of characters in given string are: ",character_count)
print("Number of words in given string are: ",word_count)


#without inbuild function
string=input("Enter any string: ")
word_count=1
character_count=0
for i in string:
    if i==" ":
        word_count+=1
    else:
        character_count+=1
print("Number of characters in given string are: ",character_count)
print("Number of words in given string are: ",word_count)