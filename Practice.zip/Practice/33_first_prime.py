#print first n prime number by taking user input for n

n=int(input("Enter how many prime number you want to print: "))
start=int(input("Enter your start of range: "))
end=int(input("Enter your end of range: "))
count=0                   #or we can take count as 1
#while count<n:              #so the condition will be count<=n
for i in range(start,end+1):
            for j in range(2,i):
                 
              if i%j==0:
                break
            else:
              print(i)
              count+=1
              if count==n:
                  break
    



# for i in range (start,end+1):
#     for j in range(2,i+1):
#         prime=True
#         if i%j==0:
#               False
#               break
        
#         if prime:
#              count+=1
#              print(i)
#         if count==n:
#              break

# n=int(input("Enter how many prime numbers you want: "))
# start=int(input("Enter start of your range: "))
# end=int(input("ENter end of your range: "))
# count=0
# while count<=n:
#   for  i in range(start,end+1):
#     for j in range(2,i):
#       if i%j==0:
#         break
#     else:
#       print(i)
#       count+=1
