import threading
import time

class My_thread(threading.Thread):
    def __init__(self,num):
        super().__init__()
        self.number=num
    
    def table(self):
        for i in range(1,11):
            print(i*self.number)
    
    def run(self):
        self.table()
    
M=My_thread(2)
M.start()