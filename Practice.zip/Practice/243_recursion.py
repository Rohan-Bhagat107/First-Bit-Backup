def fact(num):
    if num==1:
        return 1
    else:
        return num*fact(num-1)
def series_sum(num):
    if num==1:
        return 1
    else:
        return fact(num)+series_sum(num-1)
res=series_sum(4)
print(res)