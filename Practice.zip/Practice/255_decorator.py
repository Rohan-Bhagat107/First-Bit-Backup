# def display():
#     print("Hello! this is decorator demo")


# def table(n):
#     display()
#     for i in range(1,11):
#         print(n*i)
# table(2)

def send_money(x):
    x()
    print("Transaction succesfull!")

def acc_pin():
    my_pin=input("Enter your pin: ")

send_money(acc_pin)

