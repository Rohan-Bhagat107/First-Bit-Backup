class Vehicle():
    def __init__(self,wheels,color=" "):
        self.color=color
        self.wheels=wheels
    def display(self):
        print(self.wheels,self.color)
    
V=Vehicle(color="Black",wheels=4)
V.display()
