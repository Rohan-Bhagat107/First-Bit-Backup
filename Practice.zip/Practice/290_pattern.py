#         1
#      1  2 1
#    1  2 3  2 1
#   1 2 3 4  3  2 1
#  1 2 3  5  4  3 2 1

for i in range(1,6):
    for j in range(1,7-i):
        print(" ",end=" ")
    for j in range(1,i+1):
        print(j,end=" ")
    for j in range(2,i+1):
        if j==i:
            print("1",end=" ")
        else:

            print(j,end=" ")
    print()