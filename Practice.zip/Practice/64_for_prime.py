#WAP to take user for number and check it is prime or not:

no=int(input("Enter a number: "))
for i in range(2,no):
    if no%i==0:
        print(no,"is not a prime number.")
        break
else:
    print(no,"is a prime number.")