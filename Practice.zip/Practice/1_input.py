a=input("Enter a number: ")
print("Number  enterd is: ",a,"of type:",type(a))


b=int(input("Enter a number: "))
print("Number  enterd is: ",b,"of type:",type(b))


c=float(input("Enter a number: "))
print("Number  enterd is: ",c,"of type:",type(c))