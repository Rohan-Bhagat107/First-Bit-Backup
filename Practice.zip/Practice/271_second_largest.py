list1=[2,8,9,6,5]
# list1.sort(reverse=True)
# print(list1)
# print(list1[1])

        # OR

for i in range(len(list1)):
    for j in range(i+1,len(list1)):
        if list1[i]>list1[j]:
            list1[i],list1[j]=list1[j],list1[i]
print(list1)
print(list1[-1])





