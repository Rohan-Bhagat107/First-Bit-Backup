n=int(input("Enter how many terms you want  to print: "))
a=0
b=1
print(a)
print(b)
while n!=0:
    c=a+b
    print(c)
    a=b
    b=c
    n-=1