# nested_list = [1,[13,14],2,3,4,[5,6,7,[8,9,[12,[1212,1212]]],10],11,12]
# OP2 : [1,[13,14],2,3,4,[5,6,7,[8,9,[12,13,[1212,1212]]],10],11,12,13]

def add_after_twell(nested_list):
    for i in range(len(nested_list)):
        if isinstance(nested_list[i],list):
            add_after_twell(nested_list[i])
        elif nested_list[i]==12:
            nested_list.insert(i+1,35)
        else:
            continue
            
    
data=[2, 12, 3, [2, 12, 6, 7, 9, [5, 8, 12, 9], 11]]
(add_after_twell(data))
print(data)



