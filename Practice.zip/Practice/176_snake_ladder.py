#WAP to print snake ladder pattern: 
for i in range(10,0,-1):
    l=[]
    x=i*10
    for j in range(0,10):
        l.append(x-j)
            
    if i%2==0:
        l.reverse()
    for i in l:
        print(i,end=" ")
    print()
    