#WAP to print sum of numbers form 5 to 16
sum=0
for i in range(5,17):
    sum+=i
print("Sum of numbers form 5 to 16 is:",sum)