def display(a,b):
    print(a+b)
def display(c,d):
    print(c-d)

display(2,3)

