# n+n**2+n**3+............+n**n
# n=int(input("Enter number: "))
# sum=0
# for i in range(1,n+1):
#     sum+=n**i
# print(sum)


# number=int(input("Enter number: "))
# power=int(input("Enter power: "))
# sum=0
# for i in range(1,power+1):
#     if i%2==0:
#         sum-=number**i/i+1
#     else:
#         sum+=number**i/i+1
# print(sum)