# 	Write a program to prompt user to enter userid and password. If Id and 
# password is incorrect give him chance to re-enter the credentials. Let him try 3 
# times. After that program to terminate


reg_username=input("Enter your username for registration: ")
reg_pass=input("Enter your registration password: ")

login_username=input("Enter your registered username: ")
login_pass=input("Enter your registered password: ")

if login_username !=reg_username or login_pass!=reg_pass:
    count=0
    while count<=3:
        login_username=input("Enter your registered username: ")
        login_pass=input("Enter your registered password: ")
        count+=1
        if count==3:
            print("Sorry! Your account has been locked for security check.")
            break

else:
    print("Credentials are matched.")
    print("Login succesfull")


