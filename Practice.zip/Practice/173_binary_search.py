data=[2,4,5,6,8,9,11,15,17,19]
#n=int(input("Enter how many elements you want to add in a list: "))
no_searched=int(input("Enter a number that you want to serach in a list: "))
star=0
end=len(data)-1
mid=start+end//2
# for i in range(n):
#     element=int(input("Enter element: "))
#     data.append(element)
for j in data:
    if no_searched>mid:
        start=mid+1
        end=end
        mid=start+end//2
    elif no_searched<mid:
        start=start
        end=mid-1
        mid=start+end//2
    else:
        print("no is not in the list!")
    
   