#swap 2 numbers without 3rd

a=int(input("Enter a 1st number: "))
b=int(input("Enter a 2nd number: "))

a,b=b,a
print("Swap numbers are: ","a=",a,"b=",b)