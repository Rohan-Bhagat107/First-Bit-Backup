n=int(input("Enter a number: "))
i=2
while i**2<=n:
    if n%i==0:
        print("Not Prime Number")
        break

else:
    print("It is Prime Number")

# ch=65
# for i in range(1,5):
    
#     for j in range(1,i+1):
#         print(chr(ch),end=" ")
#         ch+=1
#     print()
# ch=65
# for i in range(1,6):
#     for j in range(1,i+1):
#         print(j,end=" ")
#     for k in range(i):
#         print(chr(ch+k),end=" ")
#     print()
