#Wap to find factorial of a number
no=int(input("Enter a number:"))
fact=1
for i in range(no,1,-1):
    fact=fact*i
print("Factorial of",no,"is: ",fact)
