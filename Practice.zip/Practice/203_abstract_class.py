### Abstract class is a class which has atleast one method which doesn't have its own implemenation,rather its implementation is compulsary for its child
#      OR
# a class which can't be instansiated. 

# from abc import ABC,abstractmethod
# class Shapes(ABC):
#     def area(self):
#         pass

# class square(Shapes):
#     def area(self):
#         print("This is area of square.")

# class rectangle(Shapes):
#     def area(self):
#         print("This is rectangle area.")

# shape=Shapes()
# shape.area()
# s=square()
# s.area()

# r=rectangle()
# r.area()

from abc import ABC,abstractmethod
class Vehicle(ABC):
    def __init__(self,wheels,colour):
        self.wheels=wheels
        self.colour=colour
    
    @abstractmethod
    def display(self):
        pass

class car(Vehicle):
    def __init__(self,wheels,colour):
        super().__init__(wheels,colour)
    
    def display(self):
        print(f"Color: {self.colour} | Wheels: {self.wheels}")

c=car(4,"Black")
c.display()