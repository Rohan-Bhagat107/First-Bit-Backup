#WAP to print factorial of a number.
n=int(input("Enter a number that you want to reverse: ")) #126
org_no=n
count=0
rev=0
while n!=0:
    rev=rev*10+n%10         
    n=n//10
    count+=1
print(rev)


# n=int(input("Enter a number: "))
# rev=0
# while n>0:
#     rev=rev*10+n%10
#     n=n//10
# print(rev)
