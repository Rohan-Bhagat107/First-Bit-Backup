#Print cube of numbers from 6 to 13

for i in range(6,14):
    print(i,"^3 =",i**3)