#WAP to check if it is palindrome of not
n=int(input("Enter a number that you want to chek: "))
rev=0
org_no=n
while n!=0:
    rev=rev*10+n%10
    n=n//10
print("Reverse of your number is:",rev)
if rev==org_no:
    print("Given number is a palindrome.")
else:
    print("Not a palindrome")

# # Using recursion
# def reverse(n,rev=0):
#     if n==0:
#         return rev
#     else:
#         return reverse(n//10,rev*10+n%10)

# n=int(input("Enter a number that you want to chek: "))
# # print(reverse(n))


# def is_palindrome(num,rev=0):
    
#     if num==0:
#         return rev
#     else:
#         return is_palindrome(num//10,rev*10+num%10)

# res=is_palindrome(n)

# if res==n:
#     print("Yes")
# else:
#     print("No")