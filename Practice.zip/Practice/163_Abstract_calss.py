from abc import ABC,abstractmethod
class shapes(ABC):
    @abstractmethod
    def perimeter(self):
        pass

class cirlce(shapes):
    def perimeter(self,r):
        self.radius=r
        p=2*3.14*self.radius
        print("Perimeter is: ",p)


c=cirlce()
c.perimeter(2)