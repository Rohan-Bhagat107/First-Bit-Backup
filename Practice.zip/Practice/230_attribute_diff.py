''' Here in this example- attributes which are defined inside the constructor(ie color) are class level 
and those which is defined with the object(ie radius) is the object level attribute'''

class Circle():
    def __init__(self,color):
        self.color=color
    def display(self):
        print("Color of circle is: ",self.color)
    
S=Circle("Black")
S.display()

