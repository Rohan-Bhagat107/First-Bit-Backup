import requests

Base_url="http://127.0.0.1:8000/"
response=requests.get(Base_url+"GET/clients")
print(response.json())