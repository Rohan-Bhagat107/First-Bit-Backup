#WAP to chek is a given number present in the list or not(list should be user defined)

n=int(input("How many elements you want to add in a list: "))
no_searched=int(input("Enter a number that you want to search: "))
number=[]
count=0
for i in range(n):
    element=int(input("Enter element: "))
    number.append(element)
for j in number:
    if j==no_searched:
        count+=1
    else:
        print(f"{no_searched} is not in the list.")
print(f"{no_searched} is present in the list {count} time")


#WAP to chek is a given number present in the list or not

# number=[1,6,82,9,7,3,3]
# print(number)
# no_searched=int(input("enter a number that you want to search in the above list: "))
# count=0
# for i in number:
#     if i==no_searched:
#         count+=1
# print(f"{no_searched} is there in list {count} times ")

                        #OR

# data=[2,5,55,2,6,99,55,66,3]
# b=[]

# for i in data:
#     if i not in b:
#         b.append(i)
# print(b)

# for j in b:
#     print(j,"->",data.count(i))

