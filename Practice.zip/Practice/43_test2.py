#WAP to print first n prime numbers

n=int(input("Enter how many prime numbers you want to print: "))
start=int(input("Enter start of your range: "))
end=int(input("Enter end of your range: "))
count=0
for i in range(start,end+1):
    for j in range(2,i):
        if i%j==0:
            break
    else:
        print(i)
        count+=1
        if count==n:
            break