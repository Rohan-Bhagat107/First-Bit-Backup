from collections import Counter
word="hello"
print(Counter(word))

#Reverse of given string
# rev_word=""
# for i in range(len(word)-1,-1,-1):
#     rev_word+=word[i]
# print(rev_word)

#lower of given string
# print(word.lower())

# Capitalize of given word
# print(word.capitalize())

# Implementing caseless string
# print(word.casefold())

#pad string with specified character
# print(word.center(3))

# Getting no. of occurances of substring in string
# print(word.count("l"))

#checking ending of string 
# print(word.endswith("o"))

#Finding particular character in string
# print(word.find("e"))

# chaecking string is alphanumerich or not
# alpha_num="129awe"
# print(alpha_num.isalnum())

# Checking decimal or not
# dec_num="10000"
# print(dec_num.isdecimal())

# checking digit or not
# dig_num=12.35
# print(dig_num.is_integer())

#separates the string form specified char/string
# print(word.partition("l"))

#Get highest index of given char/string
# print(word.rfind('l'))

# shift given string to right direction
# print(word.rjust(2))

# split the given string from right
# print(word.rsplit("e"))

# converts string into title case
print(word.title())