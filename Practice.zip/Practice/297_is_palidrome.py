n=int(input("Enter a number: "))
# 1) By converting a number into string
# string_num=str(n)
# rev_no=string_num[::-1]
# if string_num==rev_no:
#     print("It is palindrome")
# else:
#     print("Not palindrome")
 
#  2) By using Recursion
# def is_palindrome(no,rev):
#     if no==0:
#         return rev
#     else:
#         return is_palindrome(no//10,rev*10+no%10)

# res=is_palindrome(n,0)
# if n==res:
#     print("It is palindrome")
# else:
#     print("Not a palindrome")

#   3) By using while loop 
reversed_num=0
org_no=n
while n>0:
    digit=n%10
    reversed_num=reversed_num*10+digit
    n=n//10

if reversed_num==org_no:
    print("It is palindrome")
else:
    print("Not a palindrome")