# l1=[5,2,1,11,6,13,8]
# for i in range(len(l1)):
#     for j in range(i+1,len(l1)):
#         if l1[i]>l1[j]:
#             l1[i],l1[j]=l1[j],l1[i]
# print(l1)

#Bubble sort
l1=[2,8,5,1,6,9,7]
for i in range(len(l1)):

    for j in range(i+1,len(l1)):
        if l1[i]<l1[j]:
            l1[i],l1[j]=l1[j],l1[i]
print(l1)


