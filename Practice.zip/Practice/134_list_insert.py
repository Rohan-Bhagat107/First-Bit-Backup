#insert-> list_ref.insert(index_no,element)
list1=[1,2,3,4,5]
3
print("---------inserting list with positive index------------")
list1.insert(1,7)
print(list1)
print("---------inserting list with negative index------------")
list1.insert(-25,3)
print(list1)