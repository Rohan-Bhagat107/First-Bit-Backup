#WAP to print all prime numbeers between 300 to 100 in reverse order

a=300
while a>100:
    for i in range(2,int(a**0.5+1)):
        if a%i==0:
            a-=1
            break
    else:
        print(a)
        a-=1

