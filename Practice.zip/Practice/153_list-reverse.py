#WAP to reverse a list

data=[]
rev_data=[]
num=int(input("How many elements you want to add in list: "))
for i in range(num):
    element=int(input("Enter element: "))
    data.append(element)
print("Original list.......")
print(data)
for j in range(len(data)-1,-1,-1):
    rev_data.append(data[j])
print("Reversed list..........")
print(rev_data)