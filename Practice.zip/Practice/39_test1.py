# Write a program to accept 3 digit number. If first digit is double of second digit and half of third digit then display “Yes, you have done it”, otherwise display “Please try next time”.

num=int(input("Enter a three digit num:"))
a=num%10
b=num//10
c=b%10
d=b//10
if d==2*c and d==0.5*a:
    print("Yes you have done it.")
else:
    print("Please try again next time.")

# n=int(input("Enter any three digit number: "))  ##123
# a=n%10  #3
# b=n//10  #12
# c=b%10   #2
# d=b//10  #1
# if (d==2*c) and d==0.5*a:
#     print("Yes")
# else:
#     print("No")