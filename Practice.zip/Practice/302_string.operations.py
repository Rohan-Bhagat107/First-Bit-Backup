from collections import Counter
word="Yahoo Baba"
# print(word.casefold())

# print(word.center(7,"b"))

# print(word.count("a"))
# print(Counter(word))

# alpha_num="Hello23"
# print(alpha_num.isalnum())

# alpabet="World"
# print(alpabet.isalpha())


# print(word.isdigit())

# print(word.rfind("a"))
# print(word.lower())
# print(word.islower())
# print(word.swapcase())
# print(word.partition("a"))

dict1={}
word="Yahoo Baba"
for i in word:

    if i!=" ":
        count=0
        for j in word:
            
            if i==j:
                count+=1
        dict1[i]=count  
print(dict1)

