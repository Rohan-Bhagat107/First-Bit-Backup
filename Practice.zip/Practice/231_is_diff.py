## difference between is and ==
# is used to compare identity of two variable
# it returns the boolean output,True if variables are assingned at same memory location 
# it compares the memory location

a="Hello"
b="Hello"
print(a is b)
print(id(a))
print(id(b))

## == campares the actual value stored in the variable if it is same the it will return True else False
print(a==b)

