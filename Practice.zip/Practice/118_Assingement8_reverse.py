# Write a program find reverse of a number

def reverse_of_number(no):
    rev=0
    while no>0:
        rev=rev*10+no%10
        no=no//10
    return rev


no=int(input("Enter a number: "))
res=reverse_of_number(no)
print(f"Rverese of {no} is: {res}")
