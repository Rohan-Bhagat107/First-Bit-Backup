#delete()-> del list_ref

list1=[1,2,3,4,5]
del list1
print(list1)