#WAP to print factorial of a number .

no=int(input("Enter a number: "))
fact=1
for i in range(2,no+1):
    fact*=i
print("Factorial of",no,"is: ",fact)