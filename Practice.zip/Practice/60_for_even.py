#WAp to print even numbers from 1 to 10

for i in range(2,11):
        if i%2==0:
            print(i)
           
    