#WAP to create duplicate copy of existing list.It should not point to the same list

data=[]
num=int(input("How many elements you want to add in list: "))
for i in range(num):
    element=int(input("Enter element: "))
    data.append(element)
print(data)
print(id(data))

new_data=[]
for j in data:
    new_data.append(j)
print(new_data)
print(id(new_data))


# data_copy=data
# #rev_data_copy=[]
# for j in range(len(data_copy)-1,-1,-1):
#     rev_data_copy.append(data_copy[j])
# print(rev_data_copy)

# new_data=[]
# for i in range(len(data_copy)-1,-1,-1):
#     new_data.append(data_copy[i])
# print(new_data)


# print(data_copy)
# data[0]=5
# print(data)
# print(data_copy)