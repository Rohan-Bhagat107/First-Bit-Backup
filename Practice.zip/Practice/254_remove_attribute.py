class Product():
    def __init__(self,color,weight):
        self.color=color
        self.weight=weight
    
    def display(self):
        print("Color of product is",self.color,"and its weight is: ",self.weight)


p=Product("gery",200)
p.height=120
print(p.height)
del p.height
print(p.height)
