# .	Write a program to find sum of following series using recursive functions: 
# 	1! + 2!  + 3! + 4! +….. + n! 
# Note : For fact and sum two recursive functions

def sum(n):
    if n==0:
        return 0
    else:
        return n+fact(n-1)

def fact(no):
    if no==1:
        return 1
    else:
     return no*fact(n-1)