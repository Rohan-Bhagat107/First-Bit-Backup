#WAP to print all numbers from 6 to 30 that are divisible either by 5 ,6,or 10
print("Numbers from 6 to 30 that are divisible either by 5 ,6 or 10 are:")
for i in range(6,31):
    if i%5==0 or i%6==0 or i%10==0:
        print(i)
