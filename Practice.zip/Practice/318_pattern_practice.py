def var_args(*kwargs):
    for i in kwargs:
        print(2*i)
    
var_args(1,4,"Rohan")


class Car():
    _color="Black"
    __wheels="4"
    def __init__(self,sits=0):
        self.sits=sits
    def info(self):
        print(f"Vehicle colour: {self._color}, Wheels: {self.__wheels}")

mahindra=Car(4)
print(mahindra._Car__wheels)
print(Car._color)
