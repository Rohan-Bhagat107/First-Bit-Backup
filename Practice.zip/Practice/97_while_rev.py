#WAP to print reverse of a numbeer using while loop

no=int(input("Enter a number: "))
org_no=no
rev=0
while no>0:
    rev=rev*10+no%10
    no=no//10
print("Reverse of",org_no,"is: ",rev)
