#WAP to print square of numbers from 1 to 20
for i in range(1,21):
    print(i,"x",i,"=",i*i)