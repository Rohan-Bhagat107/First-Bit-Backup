class Student():
    clg="FBS"
    count=0
    discount=0.8
    def __init__(self,roll,name,Fees):
        Student.count+=1
        self.roll=roll
        self.name=name
        self.fees=Fees


    # def set_attribute(self,roll,name="Rohan"):
    #     self.roll=roll
    #     self.name=name
    def display():
        print(Student.clg)
    
    def total_students():
        print("Total students are: ",Student.count)
    
    def student_fees(self):
        print("Your total fees is: ",(Student.discount*self.fees))

s1=Student(101,"Rohan",1000)
s2=Student(102,"ABC",1250)
s1.student_fees()
s2.student_fees()
#Student.total_students()
#s1.set_attribute(101)
#Student.display()

    