#Q5)  x - x2/3 + x3/5 - x4/7 + …. to n terms

n=int(input("Enter number of term upto which you want sum of series: "))
x=int(input("Enter a number of which you want sum of series: "))
sum=0
for i in range(1,n+1):
    if i%2==0:
        sum-=x**i/(2*i)-1
    else:
        sum+=x**i/(2*i)-1
print("Sum of series is: ",sum)