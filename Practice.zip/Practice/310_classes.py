class Employee():
    def __init__(self,id,name,designation):
        self.id=id
        self.name=name
        self.designation=designation
    def info(self):
        print(f"Emp ID: {self.id} | Name:{self.name} | Designation: {self.designation}")
    def __str__(self):
        return f"Emplyee Name: {self.name}"

emp=Employee(1,"Rohan", "Software Developer")
print(emp)
print(emp.designation)
emp.department="IT"
print(emp.department)
del(emp.department)
print(emp.department)
