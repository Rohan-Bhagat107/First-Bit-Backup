#Print numbers form 10 to 1

for i in range(10,0,-1):
    print(i)