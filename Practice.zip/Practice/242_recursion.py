sum=0
def is_armstrong(num,digit):
    if num==0:
        return 0
    else:
        sum=num%10**digit+is_armstrong(num//10,digit)
        return sum
num=int(input("Eneter a number: "))
digit=int(input("Enter number of digits of your number: "))
res=is_armstrong(num,digit)
if res==num:
    print("Yes")
else:
    print("No")