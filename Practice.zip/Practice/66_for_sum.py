#WAP to print sum of numbers from 1 to 30
sum=0
for i in range(1,31):
    sum+=i
print("Sum of numbers from 1 to 30 is: ",sum)
