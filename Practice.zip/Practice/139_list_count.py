#count()-> list_ref.count()
list1=[1,2,5,3,4,5]
count=list1.count(5)
print("5 occurce in the list-",count,"time")
#print(list1)
