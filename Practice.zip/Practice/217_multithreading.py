# import threading
# import time
# def display(msg):
#     lock1.acquire()
#     for i in msg:
#         print(i)
#         time.sleep(2)
#     lock1.release()

# def info(msg):
    
#     for i in msg:
#         print(i)
#         time.sleep(3)
    
# t1=threading.Thread(name="Thread1",target=display,args=("Rohan",))
# t2=threading.Thread(name="Thread2",target=info,args=("Bhagat",))
# lock1=threading.Lock()
# t1.start()
# t2.start()


## CUstmoized thread
# class Mythread(threading.Thread):
#     def __init__(self,number):
#         super().__init__()
#         self.num=number
    
#     def table(self):
#         for i in range(1,11):
#             print(self.num*i)
    
#     def run(self):
#         self.table()
# t1=Mythread(5)
# t1.start()
import threading
import time
class Mythread(threading.Thread):
    def __init__(self,number):
        super().__init__()
        self.number=number
    def table(self):
        for i in range(1,11):
            print(self.number*i)
            time.sleep(1)


    def run(self):
        self.table()

m=Mythread(2)
m.start()