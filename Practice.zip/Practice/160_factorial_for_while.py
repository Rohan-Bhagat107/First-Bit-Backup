n=int(input("Enter a number: "))
fact=1
for i in range(1,n+1):
    fact*=i

#factorial using while loop;-

# while n>1:
#         fact*=n
#         n=n-1

print(fact)