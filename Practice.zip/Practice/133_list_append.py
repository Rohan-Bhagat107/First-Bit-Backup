#append -> list_ref.append(element)

list1=[1,2,3,4,5]
list1.append(6)
print(list1)



