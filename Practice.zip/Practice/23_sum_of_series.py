#   a+a**2/2+a**3/3+a**4/4..................+a**n/n  find sum of series

a=int(input("Enter a number: "))
n=int(input("Enter the power upto which you want the sum of series: "))
sum=0
for i in range(1,n+1):
    sum+=(a**n/2*i-1)
print("Sum of series is: ",int(sum))