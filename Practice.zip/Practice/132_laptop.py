class Laptop():
    def __init__(self,brand,colour,size):
        self.brand=brand
        self.colour=colour
        self.size=size
    
    def display(self):
        print(f"Name: {self.brand} | Colour: {self.colour} | size: {self.size}")
    

l1=Laptop("Dell","Black",14)
l1.display()
print(l1)