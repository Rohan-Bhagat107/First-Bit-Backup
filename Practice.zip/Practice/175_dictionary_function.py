data={1:2,3:4,5:6,7:8}
print(type(data))
print(data.get(1))
data.items()  