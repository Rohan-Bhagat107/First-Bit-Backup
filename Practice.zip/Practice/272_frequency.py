from collections import Counter
word="hello"
# without using inbuilt
frequency={}
for i in range(len(word)):
    counter=0
    for j in range(len(word)):
        if word[i]==word[j]:
            counter+=1
    frequency[word[i]]=counter
print(frequency)

        # ------------OR------------
# for i in word:
#     counter=0
#     for j in word:
#         if i==j:
#             counter+=1
#     frequency[i]=counter
# print(frequency)

#          ------------using inbuilt-------------
print(Counter(word))
