# l1=[i for i in range(1,200) if i%3==0]
# print(l1)
num=1433435
rev=0
while num>0:
    digit=num%10
    rev=rev*10+digit
    num=num//10

print(rev)