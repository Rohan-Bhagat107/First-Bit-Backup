data=(1,5,7,8,9,5,11)
print(type(data))
#to count occureance of any element
print(data.count(5))
print(max(data))
print(data.index(8))
print(min(data))
print(sum(data))
