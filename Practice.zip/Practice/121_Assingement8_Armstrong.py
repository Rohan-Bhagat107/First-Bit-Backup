#	WAP to check if a given number is Armstrong number or not. For each task create separate functions.

def power_calculator(n):
    count=0
    while n!=0:
        digit=n%10
        n=n//10
        count+=1
    return count

def is_Armstrong(n):
    org_no=n
    sum=0
    while n!=0:
        digit2=n%10
        for i in range(1,digit2+1):
            power=digit2**power_calculator(org_no)
        sum+=power
        n=n//10
    if sum==org_no:
        return True
    else:
        return False

no=int(input("Enter a number that you want to check: "))
res=is_Armstrong(no)
if res==True:
    print(no,"is a armstrong number.")  
else:
    print(no,"is not a armstrong number.")
