n=int(input("Enter a number: "))
count=0
org_no=n
while n!=0:
    digit=n%10
    n=n//10
    count+=1
n=org_no
sum=0
while n!=0:
    digit=n%10
    n=n//10
    power=digit**count
    sum+=power

if sum==org_no:
    print("It is armstrong number.")
else:
    print("Not armstrong number.")

