#WAP to print factorial of a number using while loop

no=int(input("Enter a number:"))
fact=1
while no>0:
    fact*=no
    no-=1
print("Factorial of",no,"is: ",fact)