# WAP to print all numbers in a range divisible by a given number.

no=int(input("Enter a number: "))
start=int(input("Enter start of your range: "))
end=int(input("Enter end of your range: "))
for i in range(start,end+1):
    if i%no==0:
        print(i)
