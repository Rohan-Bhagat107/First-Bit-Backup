class Vehicle():
    def __init__(self,color,wheels):
        self.color=color
        self.wheels=wheels
    def display(self):
        print(self.color , self.wheels)

class Car(Vehicle):
    def __init__(self,seats,color,wheels):
        # super().__init__(self)
    
        self.seats=seats
        self.color=color
        self.wheels=wheels
    def info(self):
        print(self.color,self.wheels)

V=Vehicle("Silver",4)
C=Car(4,"silver",4)
C.name="Lamborgini"

C.info()