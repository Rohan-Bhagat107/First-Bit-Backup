#WAP to print all numbers from 2 to 30 that are divisible either by 2 ,3 and 10

print("Numbers from 2 to 30 that are divisible either by 2 ,3 and 10 are:")
for i in range(2,31):
    if i%2==0 and i%3==0 and i%10==0:
        print(i)
