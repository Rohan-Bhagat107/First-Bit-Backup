import copy
dict1={"Name":"Rohan","Age":24}
print(dict1.items()) # to fetch key and value
print(dict1.keys()) # to get keys 

dict2=copy.copy(dict1)
dict2["Education"]="Garduation"
print("Dict1 is: ",dict1,"& it address is: ",id(dict1))
print("Dict2 is: ",dict2,"& it address is: ",id(dict2))


dict3=copy.deepcopy(dict1)
dict3["Location"]="Mumbai"
print("Dict1 is: ",dict1,"& it address is: ",id(dict1))
print("Dict3 is: ",dict3,"& it address is: ",id(dict3))


# dict3.popitem()
# print(dict3)

dict3.update(dict1)
print(dict3)