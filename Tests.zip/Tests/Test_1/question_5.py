# -A man goes for shopping. He buys 5 products. Accept the price of all 
# products and display the total bill after adding 18% GST

p1=int(input("Enter price of 1st product: "))
p2=int(input("Enter price of 2nd product: "))
p3=int(input("Enter price of 3rd product: "))
p4=int(input("Enter price of 4th product: "))
p5=int(input("Enter price of 5th product: "))

total=p1+p2+p3+p4+p5
total_bill=total+(total*18/100)
print("Your total bill amount after 18% of GST is:",int(total_bill),"INR")
