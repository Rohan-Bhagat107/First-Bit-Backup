# Write a program to accept year from user and check if it is a leap 
# year or not.


year=int(input("Enter your year: "))
if year%4==0:
    if year%100==0:
         #print("It is a leap year")
         if year%400==0:
              print("It is leap year")
         else:
              print("not a leap year")
    else:
         print(" leap year")
else:
     print("It is not a leap year")      



# year=int(input("Enter your year: "))
# if year%4==0:
#    if year%100!=0:
#     print("It is a leap year")
#    else:
#      print("Not a leap year")
# else:
#   print("It is not a leap year")       