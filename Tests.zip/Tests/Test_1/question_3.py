


# A farmer has a field which is half in circle share and rest rectangle. He 
# needs to do fencing for entire field using barbed wire 5 times. Circular section 
# has radius 20m and rectangle length is 50 m and breadth is 40m. If cost of 
# barbed wire is 35Rs/m then calculate the total cost of fencing the field.


r=20   #m
l=50    #m
b=40    #m
cost=35    #INR
circumference_circle=3.14*r
fenc_area=circumference_circle+l+b+l
total_cost=fenc_area*cost
print("Total cost of fencing a field one time is: ",int(total_cost),"INR")
print("Total cost of fencing a field five time is: ",int(5*total_cost),"INR")




# p_rectangle=2*l*b
# cost_rectangle=p_rectangle*c
 
# p_circle=2*3.14*r 
# cost_circle=p_circle*c

# total_cost=cost_rectangle+cost_circle
# print("Total cost of fencing a field one time is: ",int(total_cost),"INR")
# print("Total cost of fencing a field five time is: ",int(5*total_cost),"INR")

