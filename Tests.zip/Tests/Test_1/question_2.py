# -Write a program to accept 3 digit number. If first digit is double of second 
# digit and half of third digit then display “Yes, you have done it”, otherwise 
# display “Please try next time”.

no=int(input("Enter a three digit number: "))   #235
a=no%10     #5
b=no//10     #23
c=b%10       #3
d=b//10      #2

if d==2*c and d==a*0.5:
    print("Yes, you have done it.")

else:
    print("Please try next time.")