# Write a program to calculate the total cost of painting. The interior of 
# building with four equal sized wall
wall=int(input("Enter size of wall: "))    #it is in unit
cost=int(input("Enter cost of painting one wall: "))# it is in INR
# perimeter=4*wall
# total_cost=cost*perimeter

wall_area=wall*wall
total_area=4*wall_area
total_cost=total_area*cost

print("Your total cost of painting is: ",total_cost,"INR")