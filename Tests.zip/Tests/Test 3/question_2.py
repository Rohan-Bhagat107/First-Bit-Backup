#WAP to find factorial of given number using recursion

def factorial(no):
    if no==1:
        return 1
    else:
        return no*factorial(no-1)
    
n=int(input("Enter a number of which you want factorial: "))
res=factorial(n)
print(f"Factorial of {n} is: {res}")