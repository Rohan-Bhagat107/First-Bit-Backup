#WAP to print
# * * * * * * * * * * * * * * * * * * * * * * 
#                                              *
#                                          *
#                                      *
#                                  *
#                              *
#                          *
#                      *
#                  *
#              *
#          *
#      *
# * * * * * * * * * * * * * * * * * * * * * *

for i in range(1,23):
    print("*",end=" ")
print()
for i in range(1,12):
    for j in range(1,28-i):
        if j==(26-2*i)-1  :
          print(" * ",end=" ")
        else:
            print(" ",end=" ")
             
    print(" ")
for i in range(1,23):
    print("*",end=" ")



