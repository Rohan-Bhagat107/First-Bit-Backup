#Write a function to which we pass a parameter and print the factors of a given number.

def factors(no):
    print("Factors of given number are: ")
    for i in range(1,n+1):
        if no%i==0:
            print(i)
    

n=int(input("Enter a number: "))
factors(n)