class CustomError(Exception):
    def __str__(Self):
        return f"You have enterd negative number"
class indexerror(Exception):
    def __str__(Self):
        return f"You have enterd a wrong index number. It should be within the length of list"