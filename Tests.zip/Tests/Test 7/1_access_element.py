# Create a Python program that defines a list and attempts to access an
# element at an index provided by the user. Implement exception
# handling to catch the IndexError if the index provided is out of
# range and print a suitable error message
from errors import *
data=[]
n=int(input("Enter how many elements you want to add in list: "))
for i in range(n):
    
         element=(input("Enter element: "))
         data.append(element)
print(data)
try:
    index_num=int(input("Enter index number of which you want to access the element: "))
    if index_num>len(data):
        raise indexerror
except indexerror as i:
    print(i)

     
else:
    print(f"The element at {index_num} index is: {data[index_num]}")

