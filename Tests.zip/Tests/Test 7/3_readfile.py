# . Write a Python program that reads a text file provided by the user
# and counts the total number of words in the file. Output the word
# count to the console

text=input("Enter any text/string: ")
with open("word_count.txt","w") as fp:
    fp.write(text + "\n")
    print("Data Saved!")

with open("word_count.txt","r") as fp:
    data=fp.read()
    word_count=1
    for i in data:
        if i==" ":
            word_count+=1
            
        else:
            continue
print("Total Number of words in your string is: ",word_count)
        
        



