# Write a Python program that defines a custom exception class called
# CustomError. Implement exception handling to raise custom
# exception when user enters a negative number and handle it
# appropriately

from errors import *
try:
    num=int(input("Enter any number: "))
    if num<0:
        raise CustomError
except CustomError as c:
    print(c)
finally:
    print("Thank you!")

