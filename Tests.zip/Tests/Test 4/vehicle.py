from abc import ABC,abstractmethod

class vehicle(ABC):
    def __init__(self,no_of_passengers):
        self.no_of_passengers=no_of_passengers
    
    @abstractmethod
    def toll_calculator(self):
        pass