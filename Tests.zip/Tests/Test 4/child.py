from vehicle import vehicle
class Two_wheeler(vehicle):
        
    #self.no_of_passengers = int(input("How many passengers are there"))
    def toll_calculator(self):
        basic_toll = 20
        charge_per_person =10
        if self.no_of_passengers<=2:
            extra_charge=0
        else:
            extra_charge=(self.no_of_passengers-2)*10
        return basic_toll+extra_charge
        
class Three_wheeler(vehicle):
    # def init(self, no_of_passengers):
    #     self.no_of_passengers = int(input("How many passengers are there"))
    def toll_calculator(self):
        basic_toll = 30
        if self.no_of_passengers<=3:
            extra_charge=0
        else:
             extra_charge= (self.no_of_passengers - 3) * 20
        return basic_toll + extra_charge
        

class Four_wheeler(vehicle):
    # def init(self, no_of_passengers):
    #     self.no_of_passengers = int(input("How many passengers are there"))
    def toll_calculator(self):
        basic_toll = 40
        if self.no_of_passengers<=4:
            extra_charge=0

        else:
          extra_charge = (self.no_of_passengers - 4) * 40
        return basic_toll + extra_charge
        


class Heavyvehicle(vehicle):
    
    # def init(self, no_of_passengers):
    #     self.no_of_passengers = int(input("How many passengers are there"))
    def toll_calculator(self):
        basic_toll = 100
        if self.no_of_passengers<=6:
            extra_charge=0
        else:

            extra_charge= (self.no_of_passengers - 6) * 100
        return basic_toll + extra_charge