# Write a program which calculates toll calculation on some location following is data provided: 

# Many vehicles goes through the toll every vehicle has to pay the basic toll + extra charges if any. 
# two wheelers have to pay basic toll Rs 20 three wheelers have to pay 30 and four wheelers have to pay 40 
# heavy veheicles i.e. Vehicles having wheels more than four, have to pay 60 Rs as basic toll 

# extra charges : 
# for two wheelers if no. of persons are more than two extra charge =10/person 
# for three wheelers if no. of persons are more than 3 extra charge =20/person 
# for four wheelers if no. of persons are more than 4 extra charge =40/person 
# for heavy vehicle if no. of person are more than 6 extra charges =100/person. 
# Show polymorphic behaviour in main. Main module should be designed in such way that toll should easily operate it through interactive menu driven program . 

# Object of vehicle class should not be possible.
from abc import ABC,abstractmethod

class vehicle(ABC):
    def __init__(self,no_of_passengers):
        self.no_of_passengers=no_of_passengers
    
    @abstractmethod
    def toll_calculator(self):
        pass
    
class Two_wheeler(vehicle):
        
    #self.no_of_passengers = int(input("How many passengers are there"))
    def toll_calculator(self):
        basic_toll = 20
        charge_per_person =10
        if self.no_of_passengers<=2:
            extra_charge=0
        else:
            extra_charge=(self.no_of_passengers-2)*10
        return basic_toll+extra_charge
        
class Three_wheeler(vehicle):
    # def init(self, no_of_passengers):
    #     self.no_of_passengers = int(input("How many passengers are there"))
    def toll_calculator(self):
        basic_toll = 30
        if self.no_of_passengers<=3:
            extra_charge=0
        else:
             extra_charge= (self.no_of_passengers - 3) * 20
        return basic_toll + extra_charge
        

class Four_wheeler(vehicle):
    # def init(self, no_of_passengers):
    #     self.no_of_passengers = int(input("How many passengers are there"))
    def toll_calculator(self):
        basic_toll = 40
        if self.no_of_passengers<=4:
            extra_charge=0

        else:
          extra_charge = (self.no_of_passengers - 4) * 40
        return basic_toll + extra_charge
        


class Heavyvehicle(vehicle):
    
    # def init(self, no_of_passengers):
    #     self.no_of_passengers = int(input("How many passengers are there"))
    def toll_calculator(self):
        basic_toll = 100
        if self.no_of_passengers<=6:
            extra_charge=0
        else:

            extra_charge= (self.no_of_passengers - 6) * 100
        return basic_toll + extra_charge
       

def main():
    while True:
        print('''Please Stop!
            What type of vehicle you have please select from below given menu-
            1)Two wheeler
            2)Three Wheeler
            3)Four Wheeler
            4)Heavy vehicle
            5)exit
           ''')
        choice=int(input("Enter your choice: "))
        if choice==5:
            break
        if choice <1 or choice >4:
            print("Invalid choice.pleas choose a valid option")
            continue
        num_person=int(input("Enter number of person on vehicle."))
        if choice==1:
            v=Two_wheeler(num_person)
        
        elif choice==2:
            v=Three_wheeler(num_person)
        
        elif choice==3:
            v=Four_wheeler(num_person)

        else:
            v=Heavyvehicle(num_person)
        

        toll=v.toll_calculator()
        print(toll)

if __name__=="__main__":
    main()
    
