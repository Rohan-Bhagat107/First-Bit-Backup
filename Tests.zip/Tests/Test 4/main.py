from child import *
def main():
    while True:
        print('''Please Stop!
            What type of vehicle you have please select from below given menu-
            1)Two wheeler
            2)Three Wheeler
            3)Four Wheeler
            4)Heavy vehicle
            5)exit
           ''')
        choice=int(input("Enter your choice: "))
        if choice==5:
            break
        if choice <1 or choice >4:
            print("Invalid choice.pleas choose a valid option")
            continue
        num_person=int(input("Enter number of person on vehicle."))
        if choice==1:
            v=Two_wheeler(num_person)
        
        elif choice==2:
            v=Three_wheeler(num_person)
        
        elif choice==3:
            v=Four_wheeler(num_person)

        else:
            v=Heavyvehicle(num_person)
        

        toll=v.toll_calculator()
        print(toll)

if __name__=="__main__":
    main()
    
