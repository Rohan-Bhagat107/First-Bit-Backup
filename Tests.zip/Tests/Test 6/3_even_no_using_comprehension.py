# Write a Python program that generates a list of numbers from 1 to 50 using list comprehension and filters out the even numbers

even_num=[x for x in range(1,51) if x%2==0]
print("List of even number is: ")

print(even_num)