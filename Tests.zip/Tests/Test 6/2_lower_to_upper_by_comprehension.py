# Write a Python program that takes a list of strings as input and
# returns a new list containing the uppercase versions of the strings
# using list comprehension.

lower_data=["apple","head","crow","hi"]
upper_data=[x.upper() for x in lower_data  ]
print(upper_data)




