class Book():
    def __init__(self,id,name,price,author):
        self.id=id
        self.name=name
        self.price=price
        self.author=author
    
    def __str__(self):
        return f"id={self.id} | Name={self.name} | Price={self.price} | Author: {self.author}"