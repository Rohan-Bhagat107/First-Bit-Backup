# Using Modules concept
# Create a class to store book details (bid, name, price and author).
# Write a menu driven program with following options:
# a. Add Book
# b. Delete book by id
# c. Display all books
# d. Search book by id
# Use dictionary to store all information.
from book import Book
class Book_Details():
    def __init__(self):
        self.book={}
    
    def add_book(self,b):

        self.book[b.id]=(b)
        
    
    def display_all_books(self):
        for i,j in self.book.items():
            print(j)
    
    def search_book_by_id(self,id):
        for i,j in self.book.items():
            if i==(id):
                print("Book found.")
                print(j)
                break
        else:
            print(f"No book associated with {id} ID.")
    
    
    def delete_book_by_id(self,id):
         #index = self.get_index(id)
        if id in self.book:
            del self.book[id]
            print("Book deleted..")
            
        else:
            print("No Book associated with {id}")
    
        
                
if __name__=="__main__":

    BD=Book_Details()

    while True:
        print('''What do you want to do?
                1)Add book
                2)Display all books
                3)Search book by id
                4)Delete book by id
                5)Exit''')
        choice=int(input("Enter your choice: "))
        if choice==1:
            id=int(input("Enter book ID: "))
            name=input("Enter book name: ")
            price=int(input("Enter book price: "))
            author=input("Enter author name: ")
            b=Book(id,name,price,author)
            BD.add_book(b)
        
        if choice==2:
            BD.display_all_books()
        
        if choice==3:
            id=int(input("Enter ID of book that you want to search: "))
            BD.search_book_by_id(id)
        
        if choice==4:
            id=int(input("Enter ID of book that you want to delete: "))
            BD.delete_book_by_id(id)
        
        if choice==5:
            print("Thank you!")
            break