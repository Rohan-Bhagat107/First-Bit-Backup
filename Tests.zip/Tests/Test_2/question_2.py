#WAP to calculate sum of the following series
#1/1!+2/2!+3/3!+..........+n/n!

n=int(input("Enter a number upto which you want sum: "))
sum=0
for i in range(1,n+1):
    fact=1
    for j in range(2,i+1):
        fact*=j
    sum+=i/fact
print("Sum of series is:",sum)