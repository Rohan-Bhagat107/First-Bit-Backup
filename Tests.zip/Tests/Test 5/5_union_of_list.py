#Python Program to Find the Union of two Lists withoutusing set concept.
list1=[]
list2=[]
merged_list=[]
union_list=[]
n1=int(input("Enter how many elements you want to add in 1st list:  "))
for i in range(n1):
    element=int(input("Enter the element: "))
    list1.append(element)
    merged_list.append(element)

n2=int(input("How many elements you want to add in list 2: "))
for j in range(n2):
    element=int(input("Enter the element: "))
    list2.append(element)
    merged_list.append(element)

for k in merged_list:
    if k not in union_list:
        union_list.append(k)
print("1st list is : ")
print(list1)
print("2nd list is: ")
print(list2)
print("Union list is: ")
print(union_list)