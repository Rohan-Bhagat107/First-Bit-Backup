# . There is a list with some numbers. Create a newdictionary using this list in such a way that key is
# number and value is frequency of occurrence of thatnumber in list.
# [1,3,4,1,2,3,6,7,1,2,4]
# {1:3,3:2,2:2,}

data=[]
data2=[]
dict1={}
n=int(input("How many elements you want to add in a list: "))
for i in range(n):
    element=int(input("Enter the element: "))
    data.append(element)
    if element not in data2:
        data2.append(element)

for i in data:
    count=0
    for j in data:
        if i==j:
            count+=1
    dict1[i]=count
print(dict1)
