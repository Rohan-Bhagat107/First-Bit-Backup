# A list contains the denominations as follows :
# D = [2000, 500, 200, 100 , 50, 20, 10, 5]
# Accept an amount from user and calculate how many
# minimum number of notes will be needed for that
# amount.

D = [2000, 500, 200, 100 , 50, 20, 10, 5]
amt=int(input("Enter amount :"))
print("To represent your amount you need following number of notes: ")
count=0
for i in D:

    n=amt//i
    amt=amt%i
    count+=n
    print(i,"->",n)
print("Total notes that you need to represent your amount is: ",count)



    # n1=amt//500
    # amt=amt%500
