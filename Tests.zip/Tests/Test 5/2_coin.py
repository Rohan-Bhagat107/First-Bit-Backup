# A teacher came to class with a large box tokens hasseveral coins. Each coin has a number printed on it.
# Before coming to class, she ensured that All the numbersoccur an Even number of times. However, while comingto the class, one coin fell down and got lost. She wants tofind out the number on the missing coin.
# Inputs:
# The original number of coins and the actual
# number on each of the coins, separated by spaces.
# Output: The number on the missing coin
# Sample Input: 8
# 5 7 2 7 5 2 5
# Sample Output: 5

data=[]
data2=[]
data3=[]
initial_coin_count=int(input("How many coins are there in the container initially : "))

for i in range(initial_coin_count):
    initial_coin=int(input("Enter coin number that is present initially: "))
    data.append(initial_coin)
for j in range(initial_coin_count-1):
    coins_present=int(input("Enter coin number that are present after loosing one coin: "))
    # if coins_present not in data2:
    data2.append(coins_present)
    if coins_present not in data3:
        data3.append(coins_present)


for k in data3:
    count=0
    for l in data2:
        if k==l:
            count+=1
    if count%2==1:
        print("Coin number that you lost/felt-down/missing is:",k)







# for i in data:
#     if i not in data2:
#         data2.append(i)
# print(data2)
# for i in data2:
#     count=0
#     for j in data:
#         if i==j:
#             count+=1
#     if count%2==1:
#         print()
#         print(i)
